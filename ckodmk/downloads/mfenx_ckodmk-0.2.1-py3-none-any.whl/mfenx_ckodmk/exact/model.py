"""Normative Python-side model handling for the untrusted CKODMK generator.

The separately built Rust checker deliberately reimplements this functionality.
No checker code imports this module.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import re
from collections.abc import Iterable
from fractions import Fraction
from typing import Any

MODEL_SCHEMA = "mfenx/ckodmk-model/v2"
SEMANTICS = "ckodmk/q-relu-affine/v2"
CERTIFICATE_SCHEMA = "mfenx/ckodmk-certificate/v2"
NORMALIZER = "ckodmk-normalizer/v2"
CANONICAL_PROFILE = "ckodmk/ascii-json-c14n/v1"

MAX_JSON_BYTES = 8_000_000
MAX_CERTIFICATE_BYTES = 16_000_000
MAX_INPUTS = 512
MAX_HIDDEN = 4_096
MAX_OUTPUTS = 512
MAX_SCALAR_SLOTS = 1_000_000
MAX_COEFFICIENT_BITS = 4_096
MAX_INTERMEDIATE_BITS = 16_384
MAX_DECIMAL_DIGITS = 1_300
MAX_STRUCTURAL_INTEGER_DIGITS = 10
MAX_EXHAUSTIVE_CASES = 100_000

_SIGNED_DECIMAL = re.compile(r"(?:0|-[1-9][0-9]*|[1-9][0-9]*)\Z")
_POSITIVE_DECIMAL = re.compile(r"[1-9][0-9]*\Z")


class CKODMKError(ValueError):
    """Base class for deterministic input, compilation, and limit failures."""


class ParseError(CKODMKError):
    pass


class ModelError(CKODMKError):
    pass


class ResourceLimitError(CKODMKError):
    pass


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ParseError(f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def _bounded_structural_int(token: str) -> int:
    unsigned = token.removeprefix("-")
    if len(unsigned) > MAX_STRUCTURAL_INTEGER_DIGITS:
        raise ParseError("JSON structural integer exceeds decimal limit")
    return int(token)


def _reject_float(_: str) -> Any:
    raise ParseError("JSON floating-point numbers are forbidden")


def _reject_constant(value: str) -> Any:
    raise ParseError(f"JSON constant {value!r} is forbidden")


def load_json_bytes(raw: bytes, *, max_bytes: int = MAX_JSON_BYTES) -> Any:
    """Load the deliberately restricted JSON profile and reject ambiguity."""

    if len(raw) > max_bytes:
        raise ResourceLimitError(f"JSON exceeds {max_bytes} bytes")
    try:
        text = raw.decode("utf-8", errors="strict")
        return json.loads(
            text,
            object_pairs_hook=_no_duplicates,
            parse_int=_bounded_structural_int,
            parse_float=_reject_float,
            parse_constant=_reject_constant,
        )
    except CKODMKError:
        raise
    except (UnicodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
        raise ParseError(f"invalid restricted JSON: {exc}") from exc


def load_json_file(path: str, *, max_bytes: int = MAX_JSON_BYTES) -> Any:
    with open(path, "rb") as handle:
        return load_json_bytes(handle.read(max_bytes + 1), max_bytes=max_bytes)


def _require_ascii(value: str, label: str) -> None:
    if not value.isascii():
        raise ModelError(f"{label} must contain ASCII only")


def _check_canonical_value(value: Any, path: str = "$") -> None:
    if value is None:
        return
    if type(value) is int:
        if abs(value) > 9_007_199_254_740_991:
            raise ModelError(
                f"{path} structural integer is outside the canonical profile"
            )
        return
    if type(value) is str:
        _require_ascii(value, path)
        return
    if type(value) is list:
        for index, item in enumerate(value):
            _check_canonical_value(item, f"{path}[{index}]")
        return
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                raise ModelError(f"{path} contains a non-string key")
            _require_ascii(key, f"{path} key")
            _check_canonical_value(item, f"{path}.{key}")
        return
    raise ModelError(
        f"{path} contains unsupported canonical type {type(value).__name__}"
    )


def canonical_bytes(value: Any) -> bytes:
    """Canonical encoding for the ASCII-only, no-float CKODMK profile."""

    _check_canonical_value(value)
    try:
        return json.dumps(
            value,
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("ascii")
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise ModelError(f"cannot canonicalize value: {exc}") from exc


def digest(value: Any, domain: str) -> str:
    _require_ascii(domain, "digest domain")
    payload = domain.encode("ascii") + b"\0" + canonical_bytes(value)
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _bits(value: int) -> int:
    return abs(value).bit_length()


def ensure_fraction_limit(
    value: Fraction,
    *,
    limit: int = MAX_COEFFICIENT_BITS,
    label: str = "coefficient",
) -> Fraction:
    if _bits(value.numerator) > limit or value.denominator.bit_length() > limit:
        raise ResourceLimitError(f"{label} exceeds {limit}-bit rational limit")
    return value


def _ensure_arithmetic_intermediates(values: Iterable[int], label: str) -> None:
    if any(_bits(value) > MAX_INTERMEDIATE_BITS for value in values):
        raise ResourceLimitError(f"{label} arithmetic intermediate exceeds limit")


def checked_add(
    left: Fraction,
    right: Fraction,
    *,
    limit: int,
    label: str,
) -> Fraction:
    """Add with the same pre-reduction resource rule as the Rust checker."""

    left_numerator = left.numerator * right.denominator
    right_numerator = right.numerator * left.denominator
    denominator = left.denominator * right.denominator
    _ensure_arithmetic_intermediates(
        (left_numerator, right_numerator, denominator), label
    )
    return ensure_fraction_limit(
        Fraction(left_numerator + right_numerator, denominator),
        limit=limit,
        label=label,
    )


def checked_multiply(
    left: Fraction,
    right: Fraction,
    *,
    limit: int,
    label: str,
) -> Fraction:
    """Multiply with the same pre-reduction resource rule as the Rust checker."""

    numerator = left.numerator * right.numerator
    denominator = left.denominator * right.denominator
    _ensure_arithmetic_intermediates((numerator, denominator), label)
    return ensure_fraction_limit(
        Fraction(numerator, denominator), limit=limit, label=label
    )


def checked_divide(
    left: Fraction,
    right: Fraction,
    *,
    limit: int,
    label: str,
) -> Fraction:
    """Divide with the same pre-reduction resource rule as the Rust checker."""

    if right == 0:
        raise ModelError(f"{label} divides by zero")
    numerator = left.numerator * right.denominator
    denominator = left.denominator * right.numerator
    if denominator < 0:
        numerator = -numerator
        denominator = -denominator
    _ensure_arithmetic_intermediates((numerator, denominator), label)
    return ensure_fraction_limit(
        Fraction(numerator, denominator), limit=limit, label=label
    )


def parse_rational(value: Any, label: str = "coefficient") -> Fraction:
    if type(value) is not dict or set(value) != {"n", "d"}:
        raise ModelError(f"{label} must be a canonical rational object")
    numerator_text, denominator_text = value["n"], value["d"]
    if type(numerator_text) is not str or type(denominator_text) is not str:
        raise ModelError(f"{label} numerator and denominator must be decimal strings")
    if (
        len(numerator_text) > MAX_DECIMAL_DIGITS + 1
        or len(denominator_text) > MAX_DECIMAL_DIGITS
    ):
        raise ResourceLimitError(f"{label} decimal representation exceeds limit")
    if not _SIGNED_DECIMAL.fullmatch(numerator_text):
        raise ModelError(f"{label} numerator is not canonical decimal")
    if not _POSITIVE_DECIMAL.fullmatch(denominator_text):
        raise ModelError(f"{label} denominator is not canonical positive decimal")
    try:
        numerator, denominator = int(numerator_text), int(denominator_text)
    except ValueError as exc:
        raise ModelError(f"{label} contains an invalid decimal integer") from exc
    result = ensure_fraction_limit(Fraction(numerator, denominator), label=label)
    if encode_rational(result) != value:
        raise ModelError(f"{label} rational is not reduced canonical form")
    return result


def encode_rational(value: Fraction | int) -> dict[str, str]:
    rational = Fraction(value)
    return {"n": str(rational.numerator), "d": str(rational.denominator)}


def _vector(values: Any, length: int, label: str) -> list[Fraction]:
    if type(values) is not list or len(values) != length:
        raise ModelError(f"{label} must contain exactly {length} rational coefficients")
    return [
        parse_rational(value, f"{label}[{index}]") for index, value in enumerate(values)
    ]


def _require_exact_fields(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise ModelError(f"{label} must be an object")
    actual = set(value)
    if actual != fields:
        missing, extra = sorted(fields - actual), sorted(actual - fields)
        raise ModelError(f"{label} fields differ; missing={missing}, extra={extra}")
    return value


def validate_model(model: Any) -> dict[str, Any]:
    fields = {
        "schema",
        "semantics",
        "input_size",
        "hidden",
        "output_weight",
        "input_weight",
        "bias",
    }
    raw = _require_exact_fields(model, fields, "model")
    if raw["schema"] != MODEL_SCHEMA or raw["semantics"] != SEMANTICS:
        raise ModelError("unsupported model schema or semantics")
    input_size = raw["input_size"]
    if type(input_size) is not int or not 1 <= input_size <= MAX_INPUTS:
        raise ModelError("input_size is outside the supported range")
    hidden_raw = raw["hidden"]
    if type(hidden_raw) is not list or len(hidden_raw) > MAX_HIDDEN:
        raise ModelError("hidden must be a bounded list")
    output_weight_raw = raw["output_weight"]
    if (
        type(output_weight_raw) is not list
        or not output_weight_raw
        or len(output_weight_raw) > MAX_OUTPUTS
    ):
        raise ModelError("output_weight must be a nonempty bounded matrix")
    hidden_size, output_size = len(hidden_raw), len(output_weight_raw)
    slots = (
        hidden_size * (input_size + 1)
        + output_size * hidden_size
        + output_size * input_size
        + output_size
    )
    if slots > MAX_SCALAR_SLOTS:
        raise ResourceLimitError(
            f"model has {slots} scalar slots, above {MAX_SCALAR_SLOTS}"
        )

    hidden: list[dict[str, Any]] = []
    for index, neuron_value in enumerate(hidden_raw):
        neuron = _require_exact_fields(
            neuron_value, {"weight", "bias"}, f"hidden[{index}]"
        )
        hidden.append(
            {
                "weight": _vector(
                    neuron["weight"], input_size, f"hidden[{index}].weight"
                ),
                "bias": parse_rational(neuron["bias"], f"hidden[{index}].bias"),
            }
        )
    output_weight = [
        _vector(row, hidden_size, f"output_weight[{index}]")
        for index, row in enumerate(output_weight_raw)
    ]
    input_weight_raw = raw["input_weight"]
    if type(input_weight_raw) is not list or len(input_weight_raw) != output_size:
        raise ModelError("input_weight has the wrong output dimension")
    input_weight = [
        _vector(row, input_size, f"input_weight[{index}]")
        for index, row in enumerate(input_weight_raw)
    ]
    bias = _vector(raw["bias"], output_size, "bias")
    return {
        "input_size": input_size,
        "hidden": hidden,
        "output_weight": output_weight,
        "input_weight": input_weight,
        "bias": bias,
    }


def serialize_model(model: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": MODEL_SCHEMA,
        "semantics": SEMANTICS,
        "input_size": model["input_size"],
        "hidden": [
            {
                "weight": [encode_rational(value) for value in neuron["weight"]],
                "bias": encode_rational(neuron["bias"]),
            }
            for neuron in model["hidden"]
        ],
        "output_weight": [
            [encode_rational(value) for value in row] for row in model["output_weight"]
        ],
        "input_weight": [
            [encode_rational(value) for value in row] for row in model["input_weight"]
        ],
        "bias": [encode_rational(value) for value in model["bias"]],
    }


def parse_domain(value: Any, input_size: int) -> list[tuple[Fraction, Fraction]] | None:
    if value is None:
        return None
    if type(value) is not list or len(value) != input_size:
        raise ModelError("domain must contain one bound object per input")
    result: list[tuple[Fraction, Fraction]] = []
    for index, raw_bound in enumerate(value):
        bound = _require_exact_fields(raw_bound, {"lower", "upper"}, f"domain[{index}]")
        lower = parse_rational(bound["lower"], f"domain[{index}].lower")
        upper = parse_rational(bound["upper"], f"domain[{index}].upper")
        if lower > upper:
            raise ModelError(f"domain[{index}] is reversed")
        result.append((lower, upper))
    return result


def serialize_domain(domain: list[tuple[Fraction, Fraction]] | None) -> Any:
    if domain is None:
        return None
    return [
        {"lower": encode_rational(lower), "upper": encode_rational(upper)}
        for lower, upper in domain
    ]


def affine_bounds(
    weight: list[Fraction],
    bias: Fraction,
    domain: list[tuple[Fraction, Fraction]],
) -> tuple[Fraction, Fraction]:
    lower = upper = bias
    for coefficient, (minimum, maximum) in zip(weight, domain):
        if coefficient >= 0:
            lower_term = checked_multiply(
                coefficient,
                minimum,
                limit=MAX_INTERMEDIATE_BITS,
                label="bound intermediate",
            )
            upper_term = checked_multiply(
                coefficient,
                maximum,
                limit=MAX_INTERMEDIATE_BITS,
                label="bound intermediate",
            )
        else:
            lower_term = checked_multiply(
                coefficient,
                maximum,
                limit=MAX_INTERMEDIATE_BITS,
                label="bound intermediate",
            )
            upper_term = checked_multiply(
                coefficient,
                minimum,
                limit=MAX_INTERMEDIATE_BITS,
                label="bound intermediate",
            )
        lower = checked_add(
            lower,
            lower_term,
            limit=MAX_INTERMEDIATE_BITS,
            label="bound intermediate",
        )
        upper = checked_add(
            upper,
            upper_term,
            limit=MAX_INTERMEDIATE_BITS,
            label="bound intermediate",
        )
    return lower, upper


def evaluate(model: dict[str, Any], inputs: Iterable[int | Fraction]) -> list[Fraction]:
    vector = [Fraction(value) for value in inputs]
    if len(vector) != model["input_size"]:
        raise ModelError("wrong input dimension")
    activations: list[Fraction] = []
    for neuron in model["hidden"]:
        value = neuron["bias"] + sum(
            (coefficient * item for coefficient, item in zip(neuron["weight"], vector)),
            Fraction(),
        )
        activations.append(max(Fraction(), value))
    outputs: list[Fraction] = []
    for output_index, bias in enumerate(model["bias"]):
        value = bias
        value += sum(
            (
                coefficient * activation
                for coefficient, activation in zip(
                    model["output_weight"][output_index], activations
                )
            ),
            Fraction(),
        )
        value += sum(
            (
                coefficient * item
                for coefficient, item in zip(
                    model["input_weight"][output_index], vector
                )
            ),
            Fraction(),
        )
        outputs.append(value)
    return outputs


def dense_scalar_slots(model: dict[str, Any]) -> int:
    hidden_size = len(model["hidden"])
    output_size = len(model["bias"])
    input_size = model["input_size"]
    return (
        hidden_size * (input_size + 1)
        + output_size * hidden_size
        + output_size * input_size
        + output_size
    )


def model_metrics(model: dict[str, Any]) -> dict[str, int]:
    serialized = serialize_model(model)
    return {
        "dense_rational_scalar_slots": dense_scalar_slots(model),
        "canonical_model_bytes": len(canonical_bytes(serialized)),
        "hidden_neurons": len(model["hidden"]),
    }


def integer_domain_points(
    domain: list[tuple[Fraction, Fraction]],
    limit: int = MAX_EXHAUSTIVE_CASES,
) -> tuple[str, Iterable[tuple[int, ...]] | None, int]:
    ranges: list[range] = []
    total = 1
    for lower, upper in domain:
        if lower.denominator != 1 or upper.denominator != 1:
            return "SKIPPED_NONINTEGRAL", None, 0
        current = range(lower.numerator, upper.numerator + 1)
        total *= len(current)
        if total > limit:
            return "SKIPPED_LIMIT", None, total
        ranges.append(current)
    return "COMPLETED", itertools.product(*ranges), total
