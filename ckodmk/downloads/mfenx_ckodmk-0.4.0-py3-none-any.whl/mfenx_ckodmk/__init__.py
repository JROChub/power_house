"""CKODMK v0.2 research prototype.

The Python package is an untrusted candidate generator. Semantic authority lives
in the separately built Rust checker.
"""

from .exact.compiler import compile_exact

__all__ = ["compile_exact"]
__version__ = "0.4.0"
