"""CKODMK deployment-assurance gate."""

from .runner import run_onnx_gate

__all__ = ["run_onnx_gate"]
