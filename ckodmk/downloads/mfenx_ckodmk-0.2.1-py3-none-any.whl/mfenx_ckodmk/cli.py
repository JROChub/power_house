"""CKODMK command line entry point."""

from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from .exact.compiler import compile_exact
from .exact.model import (
    MAX_CERTIFICATE_BYTES,
    MAX_JSON_BYTES,
    CKODMKError,
    canonical_bytes,
    load_json_file,
    serialize_model,
    validate_model,
)
from .gate.contract import ContractError
from .gate.runner import run_onnx_gate

MAX_CHECKER_BYTES = 128_000_000
MAX_CHECKER_REPORT_BYTES = 2_000_000
MAX_ONNX_MODEL_BYTES = 64 * 1024 * 1024
MAX_CALIBRATION_FILE_BYTES = 256 * 1024 * 1024
EXPECTED_CHECKER_VERSION = "ckodmk-check 0.2.0"
EXPECTED_CHECKER_REPORT_ID = "ckodmk-check/0.2.0-rust"
_AT_FDCWD = -100
_RENAME_NOREPLACE = 1
_BUNDLE_MEMBER_LIMITS = {
    "bundle-manifest.json": MAX_CHECKER_REPORT_BYTES,
    "certificate.json": MAX_CERTIFICATE_BYTES,
    "checker-report.json": MAX_CHECKER_REPORT_BYTES,
    "ckodmk-check": MAX_CHECKER_BYTES,
    "requested-domain.json": MAX_JSON_BYTES,
    "source.json": MAX_JSON_BYTES,
    "target.json": MAX_JSON_BYTES,
}


def _sha256_argument(value: str) -> str:
    if (
        len(value) != 71
        or not value.startswith("sha256:")
        or any(character not in "0123456789abcdef" for character in value[7:])
    ):
        raise argparse.ArgumentTypeError(
            "expected sha256:<64 lowercase hexadecimal characters>"
        )
    return value


def _durable_write(path: Path, payload: bytes, *, mode: int | None = None) -> None:
    with path.open("xb") as handle:
        handle.write(payload)
        if mode is not None:
            os.fchmod(handle.fileno(), mode)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        parent_descriptor = os.open(
            path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(parent_descriptor)
        finally:
            os.close(parent_descriptor)
    except OSError:
        path.unlink(missing_ok=True)
        raise


def _read_checker_binary(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file() or not os.access(path, os.X_OK):
        raise CKODMKError(
            f"checker must be an executable regular non-symlink file: {path}"
        )
    if path.stat().st_size > MAX_CHECKER_BYTES:
        raise CKODMKError("checker binary exceeds size limit")
    with path.open("rb") as handle:
        payload = handle.read(MAX_CHECKER_BYTES + 1)
    if len(payload) > MAX_CHECKER_BYTES:
        raise CKODMKError("checker binary grew beyond size limit")
    return payload


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _read_bounded_regular(path: Path, maximum: int, label: str) -> bytes:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise CKODMKError(f"cannot open {label} safely: {path}") from exc
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or not 0 < metadata.st_size <= maximum:
            raise CKODMKError(f"{label} is not a bounded regular file")
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(descriptor, min(1024 * 1024, maximum + 1 - observed))
            if not chunk:
                break
            observed += len(chunk)
            if observed > maximum:
                raise CKODMKError(f"{label} grew beyond its byte limit")
            chunks.append(chunk)
        if observed != metadata.st_size:
            raise CKODMKError(f"{label} changed while it was being read")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def _manifest_entry(path: Path) -> dict[str, Any]:
    return {"sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _copy_bundle_member(
    directory_descriptor: int,
    name: str,
    destination: Path,
    maximum: int,
) -> None:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = os.open(name, flags, dir_fd=directory_descriptor)
    except OSError as exc:
        raise CKODMKError(f"cannot snapshot bundle member safely: {name!r}") from exc
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > maximum:
            raise CKODMKError(f"bundle member is not a bounded regular file: {name!r}")
        with (
            os.fdopen(descriptor, "rb", closefd=False) as input_handle,
            destination.open("xb") as output_handle,
        ):
            copied = 0
            while True:
                chunk = input_handle.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > maximum:
                    raise CKODMKError(f"bundle member grew beyond its limit: {name!r}")
                output_handle.write(chunk)
            output_handle.flush()
            os.fsync(output_handle.fileno())
    finally:
        os.close(descriptor)


def _snapshot_bundle(bundle_path: Path, destination: Path) -> None:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_DIRECTORY", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = os.open(bundle_path, flags)
    except OSError as exc:
        raise CKODMKError(
            f"bundle must be a regular non-symlink directory: {bundle_path}"
        ) from exc
    try:
        if not stat.S_ISDIR(os.fstat(descriptor).st_mode):
            raise CKODMKError(
                f"bundle must be a regular non-symlink directory: {bundle_path}"
            )
        try:
            names = os.listdir(descriptor)
        except OSError as exc:
            raise CKODMKError("cannot enumerate bundle safely") from exc
        if len(names) > len(_BUNDLE_MEMBER_LIMITS) or not set(names) <= set(
            _BUNDLE_MEMBER_LIMITS
        ):
            raise CKODMKError("bundle contains an unsupported member")
        destination.mkdir(mode=0o700)
        for name in sorted(names):
            _copy_bundle_member(
                descriptor,
                name,
                destination / name,
                _BUNDLE_MEMBER_LIMITS[name],
            )
        destination_descriptor = os.open(
            destination, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(destination_descriptor)
        finally:
            os.close(destination_descriptor)
    finally:
        os.close(descriptor)


def _publish_directory_noreplace(source: Path, destination: Path) -> None:
    if sys.platform != "linux":
        raise CKODMKError(
            "atomic no-replace directory publication is unavailable on this platform"
        )
    library = ctypes.CDLL(None, use_errno=True)
    try:
        renameat2 = library.renameat2
    except AttributeError as exc:
        raise CKODMKError(
            "atomic no-replace directory publication is unavailable"
        ) from exc
    renameat2.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_uint,
    ]
    renameat2.restype = ctypes.c_int
    ctypes.set_errno(0)
    result = renameat2(
        _AT_FDCWD,
        os.fsencode(source),
        _AT_FDCWD,
        os.fsencode(destination),
        _RENAME_NOREPLACE,
    )
    if result == 0:
        return
    error = ctypes.get_errno()
    if error in {errno.EEXIST, errno.ENOTEMPTY}:
        raise CKODMKError(f"bundle path already exists: {destination}")
    if error in {errno.EINVAL, errno.ENOSYS, errno.EOPNOTSUPP}:
        raise CKODMKError("atomic no-replace directory publication is unavailable")
    raise OSError(error, os.strerror(error), destination)


def _run_checker(
    checker: Path,
    source: Path,
    target: Path,
    certificate: Path,
    report: Path,
) -> dict[str, Any]:
    if not checker.is_file() or not os.access(checker, os.X_OK):
        raise CKODMKError(f"checker is not an executable file: {checker}")
    version = subprocess.run(
        [str(checker), "--version"],
        check=False,
        capture_output=True,
        text=True,
        timeout=10,
    )
    if version.returncode != 0 or version.stdout.strip() != EXPECTED_CHECKER_VERSION:
        raise CKODMKError("checker version handshake failed")
    completed = subprocess.run(
        [
            str(checker),
            "verify",
            "--source",
            str(source),
            "--target",
            str(target),
            "--certificate",
            str(certificate),
            "--report",
            str(report),
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if completed.returncode != 0:
        detail = (
            completed.stderr.strip()
            or completed.stdout.strip()
            or "checker rejected candidate"
        )
        raise CKODMKError(f"checker rejected staged candidate: {detail}")
    try:
        decision = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise CKODMKError("checker returned malformed decision JSON") from exc
    if (
        type(decision) is not dict
        or set(decision) != {"checker", "decision", "report"}
        or decision.get("decision") != "VERIFIED"
        or decision.get("checker") != EXPECTED_CHECKER_REPORT_ID
        or decision.get("report") != str(report)
    ):
        raise CKODMKError("checker did not return an authoritative VERIFIED decision")
    if not report.is_file():
        raise CKODMKError("checker did not create the required report")
    report_value = load_json_file(str(report), max_bytes=MAX_CHECKER_REPORT_BYTES)
    expected_fields = {
        "authority_boundary",
        "checker",
        "decision",
        "diagnostic_exhaustive",
        "schema",
        "source_digest",
        "source_metrics",
        "statement",
        "target_digest",
        "target_metrics",
    }
    if type(report_value) is not dict or set(report_value) != expected_fields:
        raise CKODMKError("checker report has an unsupported shape")
    if (
        report_value["schema"] != "mfenx/ckodmk-checker-report/v1"
        or report_value["decision"] != "VERIFIED"
        or report_value["checker"] != EXPECTED_CHECKER_REPORT_ID
    ):
        raise CKODMKError("checker report identity or decision is invalid")
    return {
        "decision": decision,
        "report": report_value,
        "version": version.stdout.strip(),
    }


def compile_bundle(
    source_path: Path,
    bundle_path: Path,
    checker_path: Path,
    domain_path: Path | None = None,
) -> dict[str, Any]:
    if bundle_path.exists():
        raise CKODMKError(f"bundle path already exists: {bundle_path}")
    if not bundle_path.parent.is_dir():
        raise CKODMKError(f"bundle parent does not exist: {bundle_path.parent}")

    checker_payload = _read_checker_binary(checker_path)
    source_raw = load_json_file(str(source_path), max_bytes=MAX_JSON_BYTES)
    source = validate_model(source_raw)
    normalized_source = serialize_model(source)
    domain_raw = load_json_file(str(domain_path)) if domain_path is not None else None
    target, certificate = compile_exact(normalized_source, domain_raw)

    staging = Path(
        tempfile.mkdtemp(
            prefix=f".{bundle_path.name}.staging-",
            dir=str(bundle_path.parent),
        )
    )
    published = False
    try:
        source_file = staging / "source.json"
        target_file = staging / "target.json"
        certificate_file = staging / "certificate.json"
        report_file = staging / "checker-report.json"
        checker_file = staging / "ckodmk-check"
        _durable_write(source_file, canonical_bytes(normalized_source) + b"\n")
        _durable_write(target_file, canonical_bytes(target) + b"\n")
        _durable_write(certificate_file, canonical_bytes(certificate) + b"\n")
        _durable_write(checker_file, checker_payload, mode=0o555)
        if domain_raw is not None:
            _durable_write(
                staging / "requested-domain.json", canonical_bytes(domain_raw) + b"\n"
            )

        checked = _run_checker(
            checker_file.resolve(),
            source_file.resolve(),
            target_file.resolve(),
            certificate_file.resolve(),
            report_file.resolve(),
        )
        report = checked["report"]
        if (
            report["source_digest"] != certificate["source_digest"]
            or report["target_digest"] != certificate["target_digest"]
            or report["statement"] != certificate["statement"]
        ):
            raise CKODMKError("checker report is not bound to the staged certificate")
        entries = {
            path.name: _manifest_entry(path)
            for path in sorted(staging.iterdir(), key=lambda item: item.name)
            if path.is_file()
        }
        manifest = {
            "schema": "mfenx/ckodmk-bundle-manifest/v1",
            "bundle_format": "ckodmk-directory-bundle/v1",
            "decision": "VERIFIED",
            "authentication": "none",
            "authentication_note": "Hashes provide integrity only; this research bundle is unsigned.",
            "checker": {
                "path": "ckodmk-check",
                "version": checked["version"],
                "sha256": entries["ckodmk-check"]["sha256"],
                "bytes": entries["ckodmk-check"]["bytes"],
                "trust": "content-bound caller-supplied checker; not publisher-authenticated",
            },
            "entries": entries,
        }
        _durable_write(
            staging / "bundle-manifest.json", canonical_bytes(manifest) + b"\n"
        )

        directory_fd = os.open(staging, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        _publish_directory_noreplace(staging, bundle_path)
        published = True
        parent_fd = os.open(
            bundle_path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
        return {
            "decision": checked["decision"]["decision"],
            "bundle": str(bundle_path),
            "source_digest": certificate["source_digest"],
            "target_digest": certificate["target_digest"],
            "checker_sha256": entries["ckodmk-check"]["sha256"],
        }
    finally:
        if not published and staging.exists():
            shutil.rmtree(staging)


def _validate_bundle_manifest(bundle_path: Path) -> tuple[dict[str, Any], str]:
    if bundle_path.is_symlink() or not bundle_path.is_dir():
        raise CKODMKError(
            f"bundle must be a regular non-symlink directory: {bundle_path}"
        )
    manifest_path = bundle_path / "bundle-manifest.json"
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise CKODMKError("bundle manifest must be a regular non-symlink file")
    manifest = load_json_file(str(manifest_path), max_bytes=MAX_CHECKER_REPORT_BYTES)
    required_fields = {
        "authentication",
        "authentication_note",
        "bundle_format",
        "checker",
        "decision",
        "entries",
        "schema",
    }
    if type(manifest) is not dict or set(manifest) != required_fields:
        raise CKODMKError("bundle manifest has an unsupported shape")
    if (
        manifest["schema"] != "mfenx/ckodmk-bundle-manifest/v1"
        or manifest["bundle_format"] != "ckodmk-directory-bundle/v1"
        or manifest["decision"] != "VERIFIED"
        or manifest["authentication"] != "none"
    ):
        raise CKODMKError("bundle manifest protocol or decision is invalid")
    entries = manifest["entries"]
    required_entries = {
        "certificate.json",
        "checker-report.json",
        "ckodmk-check",
        "source.json",
        "target.json",
    }
    if type(entries) is not dict or not required_entries <= set(entries):
        raise CKODMKError("bundle manifest lacks required entries")
    allowed_entries = required_entries | {"requested-domain.json"}
    if not set(entries) <= allowed_entries:
        raise CKODMKError("bundle manifest contains an unsupported entry")
    actual_names = {
        path.name
        for path in bundle_path.iterdir()
        if path.name != "bundle-manifest.json"
    }
    if actual_names != set(entries):
        raise CKODMKError("bundle files do not exactly match the manifest")
    for name, expected in entries.items():
        if type(expected) is not dict or set(expected) != {"bytes", "sha256"}:
            raise CKODMKError(f"manifest entry {name!r} has an unsupported shape")
        path = bundle_path / name
        if path.is_symlink() or not path.is_file():
            raise CKODMKError(f"manifest entry {name!r} is not a regular file")
        if (
            type(expected["bytes"]) is not int
            or expected["bytes"] != path.stat().st_size
        ):
            raise CKODMKError(f"manifest byte count mismatch for {name!r}")
        if type(expected["sha256"]) is not str or expected["sha256"] != _sha256_file(
            path
        ):
            raise CKODMKError(f"manifest digest mismatch for {name!r}")
    checker_record = manifest["checker"]
    if (
        type(checker_record) is not dict
        or set(checker_record) != {"bytes", "path", "sha256", "trust", "version"}
        or checker_record["path"] != "ckodmk-check"
        or checker_record["version"] != EXPECTED_CHECKER_VERSION
        or checker_record["sha256"] != entries["ckodmk-check"]["sha256"]
        or checker_record["bytes"] != entries["ckodmk-check"]["bytes"]
    ):
        raise CKODMKError("bundle checker record is inconsistent")
    return manifest, _sha256_file(manifest_path)


def verify_bundle(bundle_path: Path, trusted_checker_path: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="ckodmk-recheck-") as temporary:
        temporary_path = Path(temporary)
        frozen_bundle = temporary_path / "bundle"
        _snapshot_bundle(bundle_path, frozen_bundle)
        manifest, manifest_digest = _validate_bundle_manifest(frozen_bundle)
        trusted_checker_payload = _read_checker_binary(trusted_checker_path)
        trusted_checker_digest = (
            "sha256:" + hashlib.sha256(trusted_checker_payload).hexdigest()
        )
        certificate = load_json_file(
            str(frozen_bundle / "certificate.json"),
            max_bytes=MAX_CERTIFICATE_BYTES,
        )
        report_path = temporary_path / "trusted-checker-report.json"
        frozen_checker = temporary_path / "trusted-ckodmk-check"
        _durable_write(frozen_checker, trusted_checker_payload, mode=0o555)
        checked = _run_checker(
            frozen_checker,
            frozen_bundle / "source.json",
            frozen_bundle / "target.json",
            frozen_bundle / "certificate.json",
            report_path,
        )
        report = checked["report"]
        if (
            type(certificate) is not dict
            or report["source_digest"] != certificate.get("source_digest")
            or report["target_digest"] != certificate.get("target_digest")
            or report["statement"] != certificate.get("statement")
        ):
            raise CKODMKError(
                "trusted checker report is not bound to the bundle certificate"
            )
        return {
            "decision": "VERIFIED",
            "bundle": str(bundle_path),
            "manifest_sha256": manifest_digest,
            "trusted_checker_sha256": trusted_checker_digest,
            "bundled_checker_sha256": manifest["checker"]["sha256"],
            "checker_bytes_match_bundle": trusted_checker_digest
            == manifest["checker"]["sha256"],
            "authentication": "none",
        }


def optimize_onnx_int8(
    source_path: Path,
    calibration_path: Path,
    bundle_path: Path,
) -> dict[str, Any]:
    """Publish a static-INT8 candidate bundle after deterministic production checks."""

    if bundle_path.exists():
        raise CKODMKError(f"bundle path already exists: {bundle_path}")
    if not bundle_path.parent.is_dir():
        raise CKODMKError(f"bundle parent does not exist: {bundle_path.parent}")
    source_payload = _read_bounded_regular(
        source_path, MAX_ONNX_MODEL_BYTES, "source model"
    )
    calibration_payload = _read_bounded_regular(
        calibration_path, MAX_CALIBRATION_FILE_BYTES, "calibration array"
    )
    try:
        import numpy as np

        from .toolchains.ort_static_int8 import QuantizationError, quantize
    except ImportError as exc:
        raise CKODMKError(
            "optimization dependencies are unavailable; install mfenx-ckodmk[optimization]"
        ) from exc

    with tempfile.TemporaryDirectory(prefix="ckodmk-calibration-") as temporary:
        frozen_calibration = Path(temporary) / "calibration.npy"
        _durable_write(frozen_calibration, calibration_payload)
        try:
            calibration = np.load(frozen_calibration, allow_pickle=False)
        except (OSError, ValueError) as exc:
            raise CKODMKError("calibration input is not a valid NumPy NPY array") from exc
        try:
            candidate_payload, report = quantize(source_payload, calibration)
        except QuantizationError as exc:
            raise CKODMKError(str(exc)) from exc

    report["calibration"]["file_sha256"] = (
        "sha256:" + hashlib.sha256(calibration_payload).hexdigest()
    )
    report_payload = (
        json.dumps(report, allow_nan=False, indent=2, sort_keys=True).encode("utf-8")
        + b"\n"
    )
    staging = Path(
        tempfile.mkdtemp(prefix=f".{bundle_path.name}.staging-", dir=bundle_path.parent)
    )
    published = False
    try:
        _durable_write(staging / "source.onnx", source_payload)
        _durable_write(staging / "candidate.onnx", candidate_payload)
        _durable_write(staging / "optimization-report.json", report_payload)
        entries = {
            name: _manifest_entry(staging / name)
            for name in ("candidate.onnx", "optimization-report.json", "source.onnx")
        }
        manifest = {
            "schema": "mfenx/ckodmk-optimization-bundle/v1",
            "decision": "CANDIDATE_PRODUCED",
            "preservation": "not evaluated",
            "entries": entries,
        }
        _durable_write(staging / "MANIFEST.json", canonical_bytes(manifest) + b"\n")
        descriptor = os.open(staging, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        _publish_directory_noreplace(staging, bundle_path)
        published = True
        parent = os.open(
            bundle_path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(parent)
        finally:
            os.close(parent)
    finally:
        if not published and staging.exists():
            shutil.rmtree(staging)
    return {
        "decision": "CANDIDATE_PRODUCED",
        "bundle": str(bundle_path),
        "source_sha256": report["source"]["sha256"],
        "candidate_sha256": report["candidate"]["sha256"],
        "preservation": "not evaluated; run verify-onnx on a held-out dataset",
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ckodmk",
        description="CKODMK ONNX optimization and model comparison toolkit",
    )
    parser.add_argument("--version", action="version", version="ckodmk 0.2.1")
    commands = parser.add_subparsers(dest="command", required=True)
    compile_command = commands.add_parser(
        "compile-exact",
        help="stage an exact-rational candidate and publish only after Rust verification",
    )
    compile_command.add_argument("source", type=Path)
    compile_command.add_argument("--domain", type=Path)
    compile_command.add_argument("--bundle", required=True, type=Path)
    compile_command.add_argument("--checker", required=True, type=Path)
    verify_bundle_command = commands.add_parser(
        "verify-bundle",
        help="recheck a bundle with an independently selected trusted checker binary",
    )
    verify_bundle_command.add_argument("bundle", type=Path)
    verify_bundle_command.add_argument("--checker", required=True, type=Path)
    gate_command = commands.add_parser(
        "verify-onnx",
        help="evaluate a source/candidate ONNX pair against a typed release contract",
    )
    gate_command.add_argument("--contract", required=True, type=Path)
    gate_command.add_argument(
        "--contract-sha256",
        required=True,
        type=_sha256_argument,
    )
    gate_command.add_argument("--source", required=True, type=Path)
    gate_command.add_argument("--candidate", required=True, type=Path)
    gate_command.add_argument("--dataset", required=True, type=Path)
    gate_command.add_argument("--report", required=True, type=Path)
    optimize_command = commands.add_parser(
        "optimize-onnx-int8",
        help="produce a deterministic static-INT8 ONNX candidate from calibration inputs",
    )
    optimize_command.add_argument("source", type=Path)
    optimize_command.add_argument(
        "--calibration",
        required=True,
        type=Path,
        help="Float32 NPY array shaped [samples, ...source input dimensions after batch]",
    )
    optimize_command.add_argument("--bundle", required=True, type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "compile-exact":
            result = compile_bundle(args.source, args.bundle, args.checker, args.domain)
            print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            return 0
        if args.command == "verify-onnx":
            if args.report.exists():
                raise CKODMKError(f"report path already exists: {args.report}")
            report = run_onnx_gate(
                args.contract,
                args.source,
                args.candidate,
                args.dataset,
                args.contract_sha256,
            )
            payload = (
                json.dumps(
                    report,
                    allow_nan=False,
                    indent=2,
                    sort_keys=True,
                ).encode("utf-8")
                + b"\n"
            )
            _durable_write(args.report, payload)
            print(
                json.dumps(
                    {
                        "decision": report["decision"],
                        "report": str(args.report),
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
            return {"PASS": 0, "BLOCK": 3, "INCONCLUSIVE": 4}[report["decision"]]
        if args.command == "verify-bundle":
            result = verify_bundle(args.bundle, args.checker)
            print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            return 0
        if args.command == "optimize-onnx-int8":
            result = optimize_onnx_int8(
                args.source, args.calibration, args.bundle
            )
            print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            return 0
        parser.error("unsupported command")
    except (CKODMKError, ContractError, OSError, subprocess.SubprocessError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
