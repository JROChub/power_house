"""Strict, typed CKODMK release-contract validation."""

from __future__ import annotations

import json
import re
from decimal import Decimal, InvalidOperation
from typing import Any

CONTRACT_SCHEMA = "mfenx/ckodmk-release-contract/v1"
POLICY_PROFILE = "ckodmk/cpu-f32-batch1-classification/v1"
MAX_CONTRACT_BYTES = 1_000_000
MAX_DATASET_ELEMENTS = 64_000_000
MAX_SAMPLES = 25_000
# The full report carries two exact Float32 output-bit arrays. Keep the Python
# producer and the separately implemented Rust adjudicator on one bounded
# profile that fits the 16 MB report envelope.
MAX_OUTPUT_ELEMENTS = 250_000
_ID = re.compile(r"[a-z0-9][a-z0-9._/-]{0,127}\Z")
_SHA256 = re.compile(r"sha256:[0-9a-f]{64}\Z")
_DECIMAL = re.compile(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]*[1-9])?\Z")


class ContractError(ValueError):
    pass


def _duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ContractError(f"duplicate contract key: {key!r}")
        result[key] = value
    return result


def _int(token: str) -> int:
    if token == "-0" or len(token.lstrip("-")) > 10:
        raise ContractError("contract integer is noncanonical or exceeds decimal limit")
    return int(token)


def _float(_: str) -> Any:
    raise ContractError("contract JSON floats are forbidden; use decimal strings")


def load_contract_bytes(raw: bytes) -> dict[str, Any]:
    if len(raw) > MAX_CONTRACT_BYTES:
        raise ContractError("contract exceeds byte limit")
    try:
        parsed = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_duplicates,
            parse_int=_int,
            parse_float=_float,
            parse_constant=_float,
        )
    except ContractError:
        raise
    except (UnicodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
        raise ContractError(f"invalid contract JSON: {exc}") from exc
    return validate_contract(parsed)


def load_contract(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        return load_contract_bytes(handle.read(MAX_CONTRACT_BYTES + 1))


def _object(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if type(value) is not dict or set(value) != fields:
        actual = sorted(value) if type(value) is dict else type(value).__name__
        raise ContractError(f"{label} must have exactly {sorted(fields)}; got {actual}")
    return value


def _string(value: Any, label: str) -> str:
    if type(value) is not str or not value.isascii():
        raise ContractError(f"{label} must be an ASCII string")
    return value


def _identifier(value: Any, label: str) -> str:
    result = _string(value, label)
    if not _ID.fullmatch(result):
        raise ContractError(f"{label} is not a canonical identifier")
    return result


def _decimal(value: Any, label: str) -> Decimal:
    text = _string(value, label)
    if len(text) > 64 or not _DECIMAL.fullmatch(text) or text == "-0":
        raise ContractError(f"{label} must be a canonical non-exponent decimal")
    try:
        result = Decimal(text)
    except InvalidOperation as exc:
        raise ContractError(f"{label} is not a decimal") from exc
    if not result.is_finite():
        raise ContractError(f"{label} must be a finite canonical decimal string")
    return result


def _positive_int(
    value: Any, maximum: int, label: str, *, allow_zero: bool = False
) -> int:
    minimum = 0 if allow_zero else 1
    if type(value) is not int or not minimum <= value <= maximum:
        raise ContractError(f"{label} must be an integer in [{minimum}, {maximum}]")
    return value


def _artifact(value: Any, label: str) -> dict[str, Any]:
    artifact = _object(value, {"format", "sha256"}, label)
    if _string(artifact["format"], f"{label}.format") != "onnx":
        raise ContractError(f"{label}.format must be onnx")
    if not _SHA256.fullmatch(_string(artifact["sha256"], f"{label}.sha256")):
        raise ContractError(f"{label}.sha256 is invalid")
    return artifact


def _claim(value: Any, index: int) -> dict[str, Any]:
    label = f"claims[{index}]"
    claim = _object(
        value,
        {
            "boundary",
            "criticality",
            "evidence_required",
            "id",
            "parameters",
            "relation",
        },
        label,
    )
    _identifier(claim["id"], f"{label}.id")
    criticality = _string(claim["criticality"], f"{label}.criticality")
    boundary = _string(claim["boundary"], f"{label}.boundary")
    if criticality not in {"required", "advisory"}:
        raise ContractError(f"{label}.criticality is unsupported")
    if boundary not in {"artifact", "onnxruntime-cpu-observation"}:
        raise ContractError(f"{label}.boundary is unsupported")
    relation = _string(claim["relation"], f"{label}.relation")
    evidence = _string(claim["evidence_required"], f"{label}.evidence_required")
    parameters = claim["parameters"]
    if relation == "artifact_identity":
        if boundary != "artifact":
            raise ContractError(
                f"{label} artifact identity requires the artifact boundary"
            )
        _object(parameters, set(), f"{label}.parameters")
        if evidence != "digest":
            raise ContractError(f"{label} artifact identity requires digest evidence")
    elif relation == "decision_invariant":
        if boundary != "onnxruntime-cpu-observation":
            raise ContractError(
                f"{label} decision invariance requires the runtime boundary"
            )
        _object(parameters, set(), f"{label}.parameters")
        if evidence != "finite-dataset-exhaustive":
            raise ContractError(
                f"{label} decision invariance requires finite-dataset-exhaustive"
            )
    elif relation == "bounded_deviation":
        if boundary != "onnxruntime-cpu-observation":
            raise ContractError(
                f"{label} bounded deviation requires the runtime boundary"
            )
        parameters = _object(parameters, {"maximum", "metric"}, f"{label}.parameters")
        if parameters["metric"] != "linf":
            raise ContractError(f"{label} only supports linf")
        if _decimal(parameters["maximum"], f"{label}.parameters.maximum") < 0:
            raise ContractError(f"{label} maximum cannot be negative")
        if evidence != "finite-dataset-exhaustive":
            raise ContractError(f"{label} requires finite-dataset-exhaustive")
    elif relation == "finite_set_accuracy_delta":
        if boundary != "onnxruntime-cpu-observation":
            raise ContractError(
                f"{label} finite-set accuracy requires the runtime boundary"
            )
        parameters = _object(
            parameters,
            {"metric", "minimum"},
            f"{label}.parameters",
        )
        if parameters["metric"] != "accuracy":
            raise ContractError(f"{label} only supports accuracy")
        minimum = _decimal(parameters["minimum"], f"{label}.parameters.minimum")
        if not Decimal("-0.05") <= minimum <= Decimal(0):
            raise ContractError(
                f"{label} minimum must be in [-0.05, 0] for the strict profile"
            )
        if evidence != "finite-dataset-exhaustive":
            raise ContractError(f"{label} requires finite-dataset-exhaustive")
    elif relation == "finite_run_latency":
        if boundary != "onnxruntime-cpu-observation":
            raise ContractError(
                f"{label} latency observation requires runtime boundary"
            )
        parameters = _object(
            parameters,
            {"maximum", "measured_runs", "metric", "warmup_runs"},
            f"{label}.parameters",
        )
        if parameters["metric"] != "sample_p95_latency_ms":
            raise ContractError(f"{label} only supports sample_p95_latency_ms")
        if _decimal(parameters["maximum"], f"{label}.parameters.maximum") <= 0:
            raise ContractError(f"{label} maximum must be positive")
        warmups = _positive_int(
            parameters["warmup_runs"], 1_000, f"{label}.warmup_runs"
        )
        measured = _positive_int(
            parameters["measured_runs"], 10_000, f"{label}.measured_runs"
        )
        if warmups < 10 or measured < 100:
            raise ContractError(
                f"{label} requires at least 10 warmups and 100 measured runs"
            )
        if evidence != "finite-run-device-observation":
            raise ContractError(f"{label} requires finite-run-device-observation")
    else:
        raise ContractError(f"{label}.relation {relation!r} is unsupported")
    return claim


def validate_contract(value: Any) -> dict[str, Any]:
    contract = _object(
        value,
        {
            "candidate",
            "claims",
            "contract_id",
            "dataset",
            "device",
            "output",
            "policy_profile",
            "schema",
            "source",
        },
        "contract",
    )
    if contract["schema"] != CONTRACT_SCHEMA:
        raise ContractError("unsupported release-contract schema")
    if _string(contract["policy_profile"], "contract.policy_profile") != POLICY_PROFILE:
        raise ContractError("unsupported release policy profile")
    _identifier(contract["contract_id"], "contract.contract_id")
    _artifact(contract["source"], "contract.source")
    _artifact(contract["candidate"], "contract.candidate")
    dataset = _object(
        contract["dataset"],
        {
            "batch_size",
            "format",
            "input_dtype",
            "input_key",
            "input_layout",
            "label_key",
            "sample_shape",
            "samples",
            "sha256",
        },
        "contract.dataset",
    )
    dataset_format = _string(dataset["format"], "contract.dataset.format")
    dataset_digest = _string(dataset["sha256"], "contract.dataset.sha256")
    if dataset_format != "numpy-npz-stored-canonical-v1" or not _SHA256.fullmatch(
        dataset_digest
    ):
        raise ContractError("contract.dataset format or digest is invalid")
    if (
        _identifier(dataset["input_key"], "contract.dataset.input_key") != "inputs"
        or _identifier(dataset["label_key"], "contract.dataset.label_key") != "labels"
    ):
        raise ContractError("strict stored-NPZ profile requires inputs/labels keys")
    samples = _positive_int(dataset["samples"], MAX_SAMPLES, "contract.dataset.samples")
    batch_size = _positive_int(dataset["batch_size"], 1, "contract.dataset.batch_size")
    if batch_size != 1:
        raise ContractError("strict v0.2 policy requires batch_size 1")
    if (
        _string(dataset["input_dtype"], "contract.dataset.input_dtype") != "float32"
        or _string(dataset["input_layout"], "contract.dataset.input_layout") != "NC"
    ):
        raise ContractError("strict v0.2 policy requires float32 NC inputs")
    sample_shape = dataset["sample_shape"]
    if type(sample_shape) is not list or not 1 <= len(sample_shape) <= 4:
        raise ContractError("contract.dataset.sample_shape must have 1 to 4 dimensions")
    sample_elements = 1
    for index, dimension in enumerate(sample_shape):
        sample_elements *= _positive_int(
            dimension, 65_536, f"contract.dataset.sample_shape[{index}]"
        )
        if sample_elements * samples > MAX_DATASET_ELEMENTS:
            raise ContractError("contract dataset element count exceeds strict profile")
    output = _object(
        contract["output"],
        {"class_count", "decision_rule", "dtype", "semantic_role"},
        "contract.output",
    )
    if (
        _string(output["dtype"], "contract.output.dtype") != "float32"
        or _string(output["decision_rule"], "contract.output.decision_rule")
        != "argmax-first"
        or _string(output["semantic_role"], "contract.output.semantic_role")
        != "classification-logits"
    ):
        raise ContractError("strict v0.2 policy requires Float32 classification logits")
    class_count = _positive_int(
        output["class_count"], 100_000, "contract.output.class_count"
    )
    if class_count * samples > MAX_OUTPUT_ELEMENTS:
        raise ContractError("contract output element count exceeds strict profile")
    device = _object(
        contract["device"],
        {
            "cpu_model",
            "cpu_microcode",
            "ckodmk_version",
            "cpu_governor",
            "cpu_logical_count",
            "intra_op_threads",
            "hardware_board",
            "hardware_product",
            "hardware_vendor",
            "kernel",
            "machine",
            "node_name",
            "numpy_version",
            "onnx_version",
            "profile_id",
            "python_version",
            "runtime",
            "system",
        },
        "contract.device",
    )
    for field in [
        "ckodmk_version",
        "cpu_model",
        "cpu_microcode",
        "cpu_governor",
        "hardware_board",
        "hardware_product",
        "hardware_vendor",
        "kernel",
        "machine",
        "node_name",
        "numpy_version",
        "onnx_version",
        "profile_id",
        "python_version",
        "runtime",
        "system",
    ]:
        _string(device[field], f"contract.device.{field}")
    _identifier(device["profile_id"], "contract.device.profile_id")
    _positive_int(
        device["cpu_logical_count"], 4_096, "contract.device.cpu_logical_count"
    )
    _positive_int(device["intra_op_threads"], 256, "contract.device.intra_op_threads")
    if type(contract["claims"]) is not list or not 2 <= len(contract["claims"]) <= 32:
        raise ContractError("contract.claims must contain between 2 and 32 claims")
    ids = set()
    identity_claims = 0
    required_semantic_claims = 0
    latency_schedule: tuple[int, int] | None = None
    for index, claim in enumerate(contract["claims"]):
        parsed = _claim(claim, index)
        if parsed["id"] in ids:
            raise ContractError(f"duplicate claim id: {parsed['id']}")
        ids.add(parsed["id"])
        if parsed["relation"] == "artifact_identity":
            identity_claims += 1
            if parsed["criticality"] != "required":
                raise ContractError("artifact identity must be a required claim")
        if parsed["criticality"] == "required" and parsed["relation"] in {
            "decision_invariant",
            "bounded_deviation",
            "finite_set_accuracy_delta",
        }:
            required_semantic_claims += 1
        if parsed["relation"] == "finite_run_latency":
            parameters = parsed["parameters"]
            schedule = (parameters["warmup_runs"], parameters["measured_runs"])
            if latency_schedule is not None and latency_schedule != schedule:
                raise ContractError(
                    "all latency claims must use the same warmup and measurement schedule"
                )
            latency_schedule = schedule
    if identity_claims != 1:
        raise ContractError("contract must contain exactly one artifact identity claim")
    if required_semantic_claims == 0:
        raise ContractError(
            "strict release policy requires at least one required semantic claim"
        )
    return contract
