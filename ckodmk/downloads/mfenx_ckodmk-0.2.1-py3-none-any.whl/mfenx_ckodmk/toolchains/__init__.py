"""Untrusted external transformation-toolchain adapters."""

from typing import Any

__all__ = ["TransformError", "transform"]


def __getattr__(name: str) -> Any:
    if name in __all__:
        from .onnxscript_gemm import TransformError, transform

        return {"TransformError": TransformError, "transform": transform}[name]
    raise AttributeError(name)

__all__ = ["TransformError", "transform"]
