"""Signed, integrity-only envelopes for large external artifact trees."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
from typing import Any, Iterable

from .pcm import (
    MAX_KEY_BYTES, PCMError, SIGNATURE_ALGORITHM, _P256_ORDER, _b64,
    _crypto, _decode_b64, _domain_hash, _load_private_key, _load_public_key,
    _sha256, _timestamp, canonical_bytes, read_bounded,
)

ENVELOPE_SCHEMA = "mfenx/ckodmk-external-artifact-envelope/v1"
STATEMENT_SCHEMA = "mfenx/ckodmk-external-artifact-statement/v1"
EVIDENCE_TYPE = "integrity/v1"
MAX_ENVELOPE_BYTES = 8 * 1024 * 1024
MAX_FILES = 100_000
MAX_TOTAL_BYTES = 16 * 1024**4
_TOKEN = re.compile(r"[a-z0-9][a-z0-9._-]{0,127}\Z")
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")


class ExternalEnvelopeError(PCMError):
    """An external artifact envelope failed structural or integrity checks."""


@dataclass(frozen=True)
class ArtifactInput:
    path: str
    role: str
    media_type: str


@dataclass(frozen=True)
class VerifiedExternalEnvelope:
    serial: str
    issuer_key_id: str
    statement_root_id: str
    artifact_count: int
    total_bytes: int
    expires_at: str


def _safe_path(value: Any) -> str:
    if type(value) is not str or not value.isascii() or not 1 <= len(value) <= 1024:
        raise ExternalEnvelopeError("artifact path must be bounded ASCII")
    if "\\" in value or value.startswith("/") or value.endswith("/"):
        raise ExternalEnvelopeError("artifact path is not canonical relative POSIX")
    parts = PurePosixPath(value).parts
    if not parts or any(part in {"", ".", ".."} for part in parts):
        raise ExternalEnvelopeError("artifact path contains an unsafe component")
    return value


def _token(value: Any, label: str) -> str:
    if type(value) is not str or not _TOKEN.fullmatch(value):
        raise ExternalEnvelopeError(f"{label} is not canonical")
    return value


def _media(value: Any) -> str:
    if type(value) is not str or not value.isascii() or not 1 <= len(value) <= 128:
        raise ExternalEnvelopeError("media type must be bounded ASCII")
    return value


def _strict_json(raw: bytes) -> dict[str, Any]:
    if not 0 < len(raw) <= MAX_ENVELOPE_BYTES:
        raise ExternalEnvelopeError("external envelope exceeds its byte limit or is empty")
    def pairs(values: list[tuple[str, Any]]) -> dict[str, Any]:
        result = {}
        for key, value in values:
            if key in result:
                raise ExternalEnvelopeError(f"duplicate external envelope key: {key!r}")
            result[key] = value
        return result
    def reject(_: str) -> Any:
        raise ExternalEnvelopeError("external envelope floating-point values are forbidden")
    try:
        value = json.loads(raw.decode("ascii"), object_pairs_hook=pairs,
                           parse_float=reject, parse_constant=reject)
    except ExternalEnvelopeError:
        raise
    except (UnicodeError, json.JSONDecodeError, ValueError, RecursionError) as exc:
        raise ExternalEnvelopeError(f"invalid external envelope JSON: {exc}") from exc
    if type(value) is not dict:
        raise ExternalEnvelopeError("external envelope root must be an object")
    return value


def _snapshot(root: Path, relative: str) -> tuple[int, str]:
    directory_flags = (os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) |
                       getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_DIRECTORY", 0))
    file_flags = (os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) |
                  getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    descriptors = []
    try:
        descriptor = os.open(root, directory_flags); descriptors.append(descriptor)
        parts = PurePosixPath(relative).parts
        for component in parts[:-1]:
            descriptor = os.open(component, directory_flags, dir_fd=descriptor)
            descriptors.append(descriptor)
        descriptor = os.open(parts[-1], file_flags, dir_fd=descriptor)
        descriptors.append(descriptor)
    except OSError as exc:
        for opened in reversed(descriptors): os.close(opened)
        raise ExternalEnvelopeError(f"cannot safely open artifact: {relative}") from exc
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_size < 0:
            raise ExternalEnvelopeError(f"artifact is not a regular file: {relative}")
        digest = hashlib.sha256(); observed = 0
        while True:
            chunk = os.read(descriptor, 8 * 1024 * 1024)
            if not chunk:
                break
            observed += len(chunk); digest.update(chunk)
            if observed > MAX_TOTAL_BYTES:
                raise ExternalEnvelopeError("artifact exceeds total-byte limit")
        after = os.fstat(descriptor)
        identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        if observed != before.st_size or identity(before) != identity(after):
            raise ExternalEnvelopeError(f"artifact changed while being read: {relative}")
        return observed, "sha256:" + digest.hexdigest()
    finally:
        for opened in reversed(descriptors): os.close(opened)


def _tree_paths(root: Path) -> list[str]:
    paths = []
    for directory, names, files in os.walk(root, topdown=True, followlinks=False):
        base = Path(directory)
        for name in names:
            path = base / name
            if path.is_symlink() or not path.is_dir():
                raise ExternalEnvelopeError(f"release tree contains a special object: {path}")
        for name in files:
            path = base / name
            if path.is_symlink() or not path.is_file():
                raise ExternalEnvelopeError(f"release tree contains a special object: {path}")
            paths.append(path.relative_to(root).as_posix())
    return sorted(paths)


def _rootprint(statement: dict[str, Any]) -> dict[str, Any]:
    artifact = {
        "embedded_proof": {
            "proof": {"evidence_types": [EVIDENCE_TYPE]},
            "protocol": STATEMENT_SCHEMA,
            "public_inputs": {"statement_sha256": _sha256(canonical_bytes(statement))},
        },
        "phx_fingerprint": "",
        "provenance": {"producer": "mfenx-ckodmk", "serial": statement["serial"]},
        "schema": "power-house/pha/v1",
    }
    projection = {key: artifact[key] for key in ("embedded_proof", "provenance", "schema")}
    artifact["phx_fingerprint"] = _domain_hash(b"power-house:pha:v1:phx-fingerprint\0", projection)
    label = "external-artifact-statement"
    branch_id = _domain_hash(b"power-house:rootprint:v1:branch-id\0", {
        "artifact_phx_fingerprint": artifact["phx_fingerprint"], "label": label, "parents": [],
    })
    return {"branches": {branch_id: {"artifact": artifact, "id": branch_id, "label": label,
                                      "parents": [], "sequence": 0}},
            "root_branch": branch_id, "schema": "power-house/rootprint/v1"}


def _protected(bundle: dict[str, Any]) -> dict[str, Any]:
    return {key: bundle[key] for key in ("issuer", "rootprint", "schema", "statement", "statement_root_id")}


def issue_external_envelope(*, root: Path, artifacts: Iterable[ArtifactInput],
                            private_key_pem: bytes, issuer_name: str, serial: str,
                            issued_at: str, expires_at: str, release_kind: str,
                            subject: str) -> bytes:
    root = root.resolve()
    if not root.is_dir():
        raise ExternalEnvelopeError("release root is not a directory")
    _token(serial, "serial"); _token(release_kind, "release kind"); _token(subject, "subject")
    if not issuer_name.isascii() or not 1 <= len(issuer_name) <= 128:
        raise ExternalEnvelopeError("issuer name must be bounded ASCII")
    issued, expires = _timestamp(issued_at, "issued_at"), _timestamp(expires_at, "expires_at")
    if expires <= issued:
        raise ExternalEnvelopeError("expires_at must be after issued_at")
    inputs = list(artifacts)
    if not 1 <= len(inputs) <= MAX_FILES:
        raise ExternalEnvelopeError("artifact count is outside the supported range")
    records = []; total = 0; seen = set()
    for item in sorted(inputs, key=lambda value: value.path):
        relative = _safe_path(item.path)
        if relative in seen:
            raise ExternalEnvelopeError("duplicate artifact path")
        seen.add(relative); role = _token(item.role, "artifact role"); media = _media(item.media_type)
        size, checksum = _snapshot(root, relative); total += size
        if total > MAX_TOTAL_BYTES:
            raise ExternalEnvelopeError("release exceeds total-byte limit")
        records.append({"bytes": size, "media_type": media, "path": relative,
                        "role": role, "sha256": checksum})
    statement = {
        "artifacts": records,
        "assurance": {"behavioral_admission": "NOT_EVALUATED",
                      "capability_admission": "NOT_EVALUATED", "evidence_type": EVIDENCE_TYPE},
        "expires_at": expires_at, "issued_at": issued_at, "release_kind": release_kind,
        "schema": STATEMENT_SCHEMA, "serial": serial, "subject": subject,
    }
    private_key = _load_private_key(private_key_pem)
    _, serialization, ec, decode_dss_signature, _ = _crypto()
    public_der = private_key.public_key().public_bytes(serialization.Encoding.DER,
                                                       serialization.PublicFormat.SubjectPublicKeyInfo)
    issuer = {"algorithm": SIGNATURE_ALGORITHM, "key_id": _sha256(public_der), "name": issuer_name,
              "public_key_spki_der_base64": _b64(public_der)}
    rootprint = _rootprint(statement)
    bundle = {"issuer": issuer, "rootprint": rootprint, "schema": ENVELOPE_SCHEMA,
              "signature": {"algorithm": SIGNATURE_ALGORITHM, "value_base64": ""},
              "statement": statement, "statement_root_id": rootprint["root_branch"]}
    hashes, _, _, _, _ = _crypto()
    r, s = decode_dss_signature(private_key.sign(canonical_bytes(_protected(bundle)), ec.ECDSA(hashes.SHA256())))
    if s > _P256_ORDER // 2:
        s = _P256_ORDER - s
    bundle["signature"]["value_base64"] = _b64(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
    return canonical_bytes(bundle) + b"\n"


def verify_external_envelope(raw: bytes, *, root: Path, trusted_public_key_der: bytes,
                             now: datetime | None = None) -> VerifiedExternalEnvelope:
    bundle = _strict_json(raw)
    if set(bundle) != {"issuer", "rootprint", "schema", "signature", "statement", "statement_root_id"} \
            or bundle.get("schema") != ENVELOPE_SCHEMA:
        raise ExternalEnvelopeError("unsupported external artifact envelope")
    statement = bundle["statement"]
    if type(statement) is not dict or set(statement) != {"artifacts", "assurance", "expires_at", "issued_at",
                                                         "release_kind", "schema", "serial", "subject"} \
            or statement.get("schema") != STATEMENT_SCHEMA:
        raise ExternalEnvelopeError("unsupported external artifact statement")
    _token(statement.get("serial"), "serial"); _token(statement.get("release_kind"), "release kind")
    _token(statement.get("subject"), "subject")
    if statement.get("assurance") != {"behavioral_admission": "NOT_EVALUATED",
                                       "capability_admission": "NOT_EVALUATED", "evidence_type": EVIDENCE_TYPE}:
        raise ExternalEnvelopeError("external envelope attempts claim escalation")
    issued, expires = _timestamp(statement["issued_at"], "issued_at"), _timestamp(statement["expires_at"], "expires_at")
    observed = now or datetime.now(UTC)
    if observed.tzinfo is None or issued > observed or expires <= observed or expires <= issued:
        raise ExternalEnvelopeError("external envelope is not currently valid")
    expected_root = _rootprint(statement)
    if bundle.get("rootprint") != expected_root or bundle.get("statement_root_id") != expected_root["root_branch"]:
        raise ExternalEnvelopeError("external envelope Rootprint binding mismatch")
    issuer = bundle["issuer"]
    if type(issuer) is not dict or set(issuer) != {"algorithm", "key_id", "name", "public_key_spki_der_base64"} \
            or issuer.get("algorithm") != SIGNATURE_ALGORITHM \
            or type(issuer.get("name")) is not str or not issuer["name"].isascii() \
            or not 1 <= len(issuer["name"]) <= 128:
        raise ExternalEnvelopeError("unsupported external envelope issuer")
    key = _load_public_key(trusted_public_key_der)
    _, serialization, ec, _, encode_dss_signature = _crypto()
    trusted = key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    if _decode_b64(issuer.get("public_key_spki_der_base64"), "issuer public key", MAX_KEY_BYTES) != trusted \
            or issuer.get("key_id") != _sha256(trusted):
        raise ExternalEnvelopeError("external envelope issuer is not the trusted key")
    signature = bundle["signature"]
    if type(signature) is not dict or set(signature) != {"algorithm", "value_base64"} \
            or signature.get("algorithm") != SIGNATURE_ALGORITHM:
        raise ExternalEnvelopeError("unsupported external envelope signature")
    raw_signature = _decode_b64(signature.get("value_base64"), "signature", 64)
    if len(raw_signature) != 64:
        raise ExternalEnvelopeError("external envelope signature must be 64 bytes")
    r, s = int.from_bytes(raw_signature[:32], "big"), int.from_bytes(raw_signature[32:], "big")
    if not 1 <= r < _P256_ORDER or not 1 <= s <= _P256_ORDER // 2:
        raise ExternalEnvelopeError("external envelope signature is not canonical low-S")
    hashes, _, _, _, _ = _crypto()
    try:
        key.verify(encode_dss_signature(r, s), canonical_bytes(_protected(bundle)), ec.ECDSA(hashes.SHA256()))
    except Exception as exc:
        raise ExternalEnvelopeError("external envelope signature verification failed") from exc
    records = statement["artifacts"]
    if type(records) is not list or not 1 <= len(records) <= MAX_FILES:
        raise ExternalEnvelopeError("external envelope artifact list is invalid")
    expected_paths = []; total = 0
    for record in records:
        if type(record) is not dict or set(record) != {"bytes", "media_type", "path", "role", "sha256"}:
            raise ExternalEnvelopeError("external envelope artifact record is invalid")
        relative = _safe_path(record["path"]); _token(record["role"], "artifact role"); _media(record["media_type"])
        size, checksum = _snapshot(root.resolve(), relative); total += size
        if type(record["bytes"]) is not int or record["bytes"] != size or not _DIGEST.fullmatch(record.get("sha256", "")) \
                or record["sha256"] != checksum:
            raise ExternalEnvelopeError(f"external artifact identity mismatch: {relative}")
        expected_paths.append(relative)
    if expected_paths != sorted(set(expected_paths)) or total > MAX_TOTAL_BYTES:
        raise ExternalEnvelopeError("external artifact paths or total bytes are invalid")
    actual = _tree_paths(root.resolve())
    if actual != expected_paths:
        raise ExternalEnvelopeError("release tree path set differs from signed statement")
    return VerifiedExternalEnvelope(statement["serial"], issuer["key_id"], bundle["statement_root_id"],
                                    len(records), total, statement["expires_at"])
