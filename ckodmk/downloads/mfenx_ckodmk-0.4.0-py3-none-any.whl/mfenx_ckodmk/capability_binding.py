"""Claim-neutral bindings for externally evaluated capability evidence."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from typing import Any, Iterable

_DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")
SCHEMA = "mfenx/ckodmk-capability-evidence-binding/v1"


class CapabilityBindingError(ValueError): pass


def parse_capability_binding(raw: bytes) -> dict[str, Any]:
    if not 0 < len(raw) <= 8 * 1024 * 1024:
        raise CapabilityBindingError("capability binding is empty or oversized")
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result: raise CapabilityBindingError("duplicate capability binding key")
            result[key] = value
        return result
    def reject(_): raise CapabilityBindingError("capability binding floats are forbidden")
    try:
        value = json.loads(raw.decode("ascii"), object_pairs_hook=pairs, parse_float=reject, parse_constant=reject)
    except CapabilityBindingError: raise
    except Exception as exc: raise CapabilityBindingError(f"invalid capability binding: {exc}") from exc
    return verify_capability_binding(value)


def _sha(path: Path) -> tuple[int, str]:
    if path.is_symlink() or not path.is_file():
        raise CapabilityBindingError(f"evidence must be a regular non-symlink file: {path}")
    digest = hashlib.sha256(); size = 0
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            size += len(chunk); digest.update(chunk)
            if size > 1024 * 1024 * 1024: raise CapabilityBindingError("evidence file exceeds 1 GiB")
    return size, "sha256:" + digest.hexdigest()


def create_capability_binding(*, evaluation_protocol: str, evaluation_scope: str,
                              reported_decision: str, evidence: Iterable[tuple[str, Path]]) -> dict[str, Any]:
    strings = (evaluation_protocol, evaluation_scope, reported_decision)
    if any(type(value) is not str or not value.isascii() or not 1 <= len(value) <= 256 for value in strings):
        raise CapabilityBindingError("capability metadata must be bounded ASCII")
    records = []
    for role, path in sorted(evidence, key=lambda item: item[0]):
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,127}", role):
            raise CapabilityBindingError("evidence role is not canonical")
        size, checksum = _sha(path)
        records.append({"bytes": size, "role": role, "sha256": checksum})
    if not records or len({item["role"] for item in records}) != len(records):
        raise CapabilityBindingError("capability evidence roles are empty or duplicated")
    value = {
        "schema": SCHEMA, "evaluation_protocol": evaluation_protocol,
        "evaluation_scope": evaluation_scope, "reported_decision": reported_decision,
        "evidence": records,
        "ckodmk_adjudication": "NOT_EVALUATED",
        "behavioral_admission": "NOT_EVALUATED",
        "production_admission": "NOT_EVALUATED",
        "qualification": "artifact identity binding only; reported capability decision is not promoted",
    }
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    value["binding_digest"] = "sha256:" + hashlib.sha256(b"mfenx:ckodmk:capability-binding:v1\0" + payload).hexdigest()
    return value


def verify_capability_binding(value: dict[str, Any]) -> dict[str, Any]:
    if type(value) is not dict or set(value) != {"behavioral_admission", "binding_digest", "ckodmk_adjudication",
                                                  "evaluation_protocol", "evaluation_scope", "evidence",
                                                  "production_admission", "qualification", "reported_decision", "schema"} \
            or value.get("schema") != SCHEMA:
        raise CapabilityBindingError("unsupported capability binding")
    if any(value.get(key) != "NOT_EVALUATED" for key in
           ("behavioral_admission", "ckodmk_adjudication", "production_admission")):
        raise CapabilityBindingError("capability binding attempts claim escalation")
    for key in ("evaluation_protocol", "evaluation_scope", "reported_decision", "qualification"):
        if type(value.get(key)) is not str or not value[key].isascii() or not 1 <= len(value[key]) <= 256:
            raise CapabilityBindingError("capability metadata is invalid")
    unsigned = dict(value); recorded = unsigned.pop("binding_digest")
    payload = json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode()
    expected = "sha256:" + hashlib.sha256(b"mfenx:ckodmk:capability-binding:v1\0" + payload).hexdigest()
    if not _DIGEST.fullmatch(recorded or "") or recorded != expected:
        raise CapabilityBindingError("capability binding digest mismatch")
    records = value["evidence"]
    if type(records) is not list or not records or len({record.get("role") for record in records if type(record) is dict}) != len(records):
        raise CapabilityBindingError("capability evidence records are invalid")
    for record in records:
        if type(record) is not dict or set(record) != {"bytes", "role", "sha256"} \
                or type(record["bytes"]) is not int or record["bytes"] < 0 \
                or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,127}", record.get("role", "")) \
                or not _DIGEST.fullmatch(record.get("sha256", "")):
            raise CapabilityBindingError("capability evidence record is invalid")
    return value
