"""Pinned ONNX Runtime static-INT8 candidate producer.

This module deliberately produces candidates; it does not certify preservation.
The source/candidate pair must still pass CKODMK Gate on a held-out dataset.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import onnx
from onnx import external_data_helper
from onnxruntime.quantization import (
    CalibrationDataReader,
    CalibrationMethod,
    QuantFormat,
    QuantType,
    quantize_static,
)


MAX_MODEL_BYTES = 64 * 1024 * 1024
MAX_CALIBRATION_SAMPLES = 10_000
MAX_CALIBRATION_ELEMENTS = 64_000_000
PINNED_VERSIONS = {
    "numpy": "2.3.5",
    "onnx": "1.22.0",
    "onnxruntime": "1.28.0",
}


class QuantizationError(RuntimeError):
    """Raised when the pinned quantization profile cannot produce a candidate."""


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _versions() -> dict[str, str]:
    try:
        observed = {
            name: importlib.metadata.version(name) for name in PINNED_VERSIONS
        }
    except importlib.metadata.PackageNotFoundError as error:
        raise QuantizationError("a pinned optimization dependency is missing") from error
    if observed != PINNED_VERSIONS:
        raise QuantizationError(
            f"toolchain versions differ from the pinned profile: {observed!r}"
        )
    return observed


def _parse(payload: bytes, label: str) -> onnx.ModelProto:
    if not 0 < len(payload) <= MAX_MODEL_BYTES:
        raise QuantizationError(f"{label} violates the model byte limit")
    try:
        model = onnx.load_model_from_string(payload)
        onnx.checker.check_model(model, full_check=True)
    except Exception as error:
        raise QuantizationError(f"{label} is not a valid ONNX model") from error
    for initializer in model.graph.initializer:
        if external_data_helper.uses_external_data(initializer):
            raise QuantizationError(f"{label} uses unbound external tensor data")
    return model


def _node_counts(model: onnx.ModelProto) -> dict[str, int]:
    return dict(sorted(Counter(node.op_type for node in model.graph.node).items()))


def _input_profile(model: onnx.ModelProto) -> tuple[str, tuple[int, ...]]:
    initializer_names = {item.name for item in model.graph.initializer}
    inputs = [item for item in model.graph.input if item.name not in initializer_names]
    if len(inputs) != 1:
        raise QuantizationError("static-INT8 profile requires exactly one model input")
    value = inputs[0]
    tensor = value.type.tensor_type
    if tensor.elem_type != onnx.TensorProto.FLOAT:
        raise QuantizationError("static-INT8 profile requires a Float32 input")
    dimensions: list[int] = []
    for dimension in tensor.shape.dim:
        if not dimension.HasField("dim_value") or dimension.dim_value <= 0:
            raise QuantizationError("static-INT8 profile requires fixed input dimensions")
        dimensions.append(dimension.dim_value)
    if not dimensions or dimensions[0] != 1:
        raise QuantizationError("static-INT8 profile requires source batch dimension 1")
    return value.name, tuple(dimensions)


def _calibration_array(array: np.ndarray, input_shape: tuple[int, ...]) -> np.ndarray:
    if type(array) is not np.ndarray or array.dtype != np.dtype("float32"):
        raise QuantizationError("calibration inputs must be a Float32 NumPy array")
    if array.ndim != len(input_shape) or tuple(array.shape[1:]) != input_shape[1:]:
        raise QuantizationError(
            "calibration input dimensions do not match the model input"
        )
    if not 1 <= array.shape[0] <= MAX_CALIBRATION_SAMPLES:
        raise QuantizationError("calibration sample count violates the profile")
    if array.size > MAX_CALIBRATION_ELEMENTS:
        raise QuantizationError("calibration input exceeds the element limit")
    if not array.flags.c_contiguous:
        array = np.ascontiguousarray(array)
    if not np.isfinite(array).all():
        raise QuantizationError("calibration input contains a non-finite value")
    return array


class _Reader(CalibrationDataReader):
    def __init__(self, name: str, inputs: np.ndarray):
        self._name = name
        self._inputs = inputs
        self._index = 0

    def get_next(self) -> dict[str, np.ndarray] | None:
        if self._index >= self._inputs.shape[0]:
            return None
        sample = self._inputs[self._index : self._index + 1]
        self._index += 1
        return {self._name: sample}


def _quantize(source: bytes, input_name: str, inputs: np.ndarray) -> bytes:
    with tempfile.TemporaryDirectory(prefix="ckodmk-ort-int8-") as temporary:
        root = Path(temporary)
        source_path = root / "source.onnx"
        candidate_path = root / "candidate.onnx"
        source_path.write_bytes(source)
        try:
            quantize_static(
                str(source_path),
                str(candidate_path),
                _Reader(input_name, inputs),
                quant_format=QuantFormat.QOperator,
                activation_type=QuantType.QUInt8,
                weight_type=QuantType.QInt8,
                per_channel=False,
                calibrate_method=CalibrationMethod.MinMax,
            )
        except Exception as error:
            raise QuantizationError("ONNX Runtime static quantization failed") from error
        try:
            return candidate_path.read_bytes()
        except OSError as error:
            raise QuantizationError("quantizer did not emit a candidate") from error


def quantize(
    source_payload: bytes,
    calibration_inputs: np.ndarray,
) -> tuple[bytes, dict[str, Any]]:
    """Produce a deterministic QOperator U8/S8 candidate and provenance report."""

    versions = _versions()
    source = _parse(source_payload, "source model")
    input_name, input_shape = _input_profile(source)
    inputs = _calibration_array(calibration_inputs, input_shape)
    candidate_payload = _quantize(source_payload, input_name, inputs)
    candidate = _parse(candidate_payload, "candidate model")
    if candidate_payload == source_payload:
        raise QuantizationError("static quantization did not change the model")
    if len(candidate_payload) >= len(source_payload):
        raise QuantizationError("static quantization did not reduce model bytes")
    quantized_ops = sum(
        1
        for node in candidate.graph.node
        if node.op_type.startswith("QLinear") or node.op_type == "MatMulInteger"
    )
    if quantized_ops == 0:
        raise QuantizationError("candidate contains no quantized compute operation")

    repeated = _quantize(source_payload, input_name, inputs)
    if repeated != candidate_payload:
        raise QuantizationError("static quantization output is not byte-deterministic")

    calibration_bytes = inputs.tobytes(order="C")
    return candidate_payload, {
        "schema": "mfenx/ckodmk-ort-static-int8-transform/v1",
        "authority": "untrusted candidate producer",
        "preservation": "not evaluated; validate on a held-out dataset",
        "toolchain": {
            "name": "ONNX Runtime static quantization",
            "versions": versions,
            "quant_format": "QOperator",
            "activation_type": "QUInt8",
            "weight_type": "QInt8",
            "per_channel": False,
            "calibration_method": "MinMax",
        },
        "input": {"name": input_name, "source_shape": list(input_shape)},
        "calibration": {
            "samples": int(inputs.shape[0]),
            "shape": list(inputs.shape),
            "dtype": "float32",
            "tensor_sha256": _digest(calibration_bytes),
        },
        "source": {
            "bytes": len(source_payload),
            "sha256": _digest(source_payload),
            "node_counts": _node_counts(source),
        },
        "candidate": {
            "bytes": len(candidate_payload),
            "sha256": _digest(candidate_payload),
            "node_counts": _node_counts(candidate),
            "quantized_compute_ops": quantized_ops,
        },
        "byte_reduction": len(source_payload) - len(candidate_payload),
        "size_ratio_source_over_candidate": len(source_payload)
        / len(candidate_payload),
        "deterministic_reproduction": True,
    }
