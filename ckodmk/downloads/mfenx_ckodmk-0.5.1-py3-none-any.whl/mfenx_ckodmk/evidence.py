"""Closed, signed evidence-set verification for PCM release decisions."""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

EVIDENCE_SCHEMA = "mfenx/release-evidence-set/v1"
MAX_EVIDENCE_BYTES = 8 * 1024 * 1024


class EvidenceError(ValueError):
    """A release evidence set is incomplete, ambiguous, or invalid."""


@dataclass(frozen=True)
class VerifiedEvidence:
    all_digests: frozenset[str]
    result_digests: frozenset[str]
    qualifications: dict[str, dict[str, int]]


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _strict_json(payload: bytes) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in items:
            if key in result:
                raise EvidenceError("duplicate evidence JSON key")
            result[key] = value
        return result

    def decimal(value: str) -> Decimal:
        try:
            return Decimal(value)
        except Exception as exc:
            raise EvidenceError("invalid evidence JSON decimal") from exc

    def reject(_: str) -> Any:
        raise EvidenceError("non-finite evidence JSON number")

    try:
        value = json.loads(
            payload.decode("utf-8", "strict"),
            object_pairs_hook=pairs,
            parse_float=decimal,
            parse_constant=reject,
        )
    except EvidenceError:
        raise
    except Exception as exc:
        raise EvidenceError("invalid evidence JSON") from exc
    if type(value) is not dict:
        raise EvidenceError("evidence JSON root must be an object")
    return value


def _decode(value: Any) -> bytes:
    if (
        type(value) is not str
        or not value.isascii()
        or len(value) > MAX_EVIDENCE_BYTES * 4 // 3 + 8
    ):
        raise EvidenceError("evidence payload is not bounded base64")
    try:
        payload = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise EvidenceError("evidence payload is invalid base64") from exc
    if (
        not payload
        or len(payload) > MAX_EVIDENCE_BYTES
        or base64.b64encode(payload).decode("ascii") != value
    ):
        raise EvidenceError("evidence payload is empty, oversized, or noncanonical")
    return payload


def _verify_training_record(document: dict[str, Any], known: set[str]) -> None:
    if document.get("schema") != "mfenx/ckodmk-optdigits-cnn-training/v1":
        raise EvidenceError("unsupported training record")
    artifacts = document.get("artifacts")
    result = document.get("result")
    training = document.get("training")
    if (
        type(artifacts) is not dict
        or type(result) is not dict
        or type(training) is not dict
    ):
        raise EvidenceError("training record sections are missing")
    for name in (
        "candidate_sha256",
        "contract_sha256",
        "dataset_sha256",
        "source_sha256",
    ):
        if artifacts.get(name) not in known:
            raise EvidenceError("training record references an unsigned artifact")
    samples = result.get("samples")
    source_correct = result.get("source_correct")
    candidate_correct = result.get("candidate_correct")
    if (
        any(
            type(value) is not int
            for value in (samples, source_correct, candidate_correct)
        )
        or not 1 <= source_correct <= samples
        or not 1 <= candidate_correct <= samples
    ):
        raise EvidenceError("training result counters are invalid")
    history = training.get("history")
    if (
        type(history) is not list
        or not history
        or history[-1].get("epoch") != training.get("epochs")
    ):
        raise EvidenceError("training did not reach its declared final epoch")


def _verify_behavior_report(
    document: dict[str, Any], known: set[str]
) -> dict[str, int]:
    if document.get("schema") != "mfenx/ckodmk-web-evidence/v1":
        raise EvidenceError("unsupported behavior report")
    result = document.get("cnn_demo")
    if type(result) is not dict:
        raise EvidenceError("behavior report result is missing")
    for name in (
        "candidate_sha256",
        "contract_sha256",
        "dataset_sha256",
        "source_sha256",
        "training_record_sha256",
    ):
        if result.get(name) not in known:
            raise EvidenceError("behavior report references an unsigned artifact")
    samples = result.get("samples")
    if type(samples) is not int or samples < 1:
        raise EvidenceError("behavior report sample count is invalid")
    for name in ("source_correct", "candidate_correct", "decision_changes"):
        if type(result.get(name)) is not int or not 0 <= result[name] <= samples:
            raise EvidenceError("behavior report counter is invalid")
    return {
        "capability_accuracy_ppm": result["candidate_correct"] * 1_000_000 // samples,
        "comparative_delta_ppm": (
            result["candidate_correct"] - result["source_correct"]
        )
        * 1_000_000
        // samples,
        "evaluation_samples": samples,
    }


def _verify_production_evaluation(
    document: dict[str, Any], known: set[str]
) -> dict[str, int]:
    if (
        type(document) is not dict
        or set(document) != {"artifacts", "metrics", "schema"}
        or document["schema"] != "mfenx/production-evaluation/v1"
    ):
        raise EvidenceError("unsupported production evaluation")
    artifacts = document["artifacts"]
    metrics = document["metrics"]
    if (
        type(artifacts) is not dict
        or not artifacts
        or any(value not in known for value in artifacts.values())
    ):
        raise EvidenceError("production evaluation references an unsigned artifact")
    expected = {
        "candidate_correct",
        "evaluation_samples",
        "reference_correct",
        "reliability_successes",
        "reliability_trials",
        "safety_critical_failures",
    }
    if (
        type(metrics) is not dict
        or set(metrics) != expected
        or any(type(value) is not int for value in metrics.values())
    ):
        raise EvidenceError("production evaluation metrics are invalid")
    samples = metrics["evaluation_samples"]
    trials = metrics["reliability_trials"]
    if (
        samples < 1
        or trials < 1
        or not 0 <= metrics["candidate_correct"] <= samples
        or not 0 <= metrics["reference_correct"] <= samples
        or not 0 <= metrics["reliability_successes"] <= trials
        or metrics["safety_critical_failures"] < 0
    ):
        raise EvidenceError("production evaluation counters are invalid")
    return {
        "capability_accuracy_ppm": metrics["candidate_correct"] * 1_000_000 // samples,
        "comparative_delta_ppm": (
            metrics["candidate_correct"] - metrics["reference_correct"]
        )
        * 1_000_000
        // samples,
        "evaluation_samples": samples,
        "reliability_success_ppm": metrics["reliability_successes"]
        * 1_000_000
        // trials,
        "safety_critical_failures": metrics["safety_critical_failures"],
    }


def validate_evidence_set(
    document: Any, *, artifact_digests: set[str]
) -> VerifiedEvidence:
    if (
        type(document) is not dict
        or set(document) != {"records", "schema"}
        or document["schema"] != EVIDENCE_SCHEMA
    ):
        raise EvidenceError("unsupported release evidence set")
    records = document["records"]
    if type(records) is not list or not 1 <= len(records) <= 64:
        raise EvidenceError("release evidence records are invalid")
    decoded: list[tuple[str, str, bytes]] = []
    seen = set(artifact_digests)
    for record in records:
        if type(record) is not dict or set(record) != {
            "payload_base64",
            "sha256",
            "verification_profile",
        }:
            raise EvidenceError("release evidence record fields are unsupported")
        payload = _decode(record["payload_base64"])
        digest = _sha256(payload)
        if record["sha256"] != digest or digest in seen:
            raise EvidenceError("release evidence digest mismatch or duplicate")
        profile = record["verification_profile"]
        if profile not in {
            "artifact-only/v1",
            "training-record/v1",
            "behavior-report/v1",
            "production-evaluation/v1",
        }:
            raise EvidenceError("unsupported evidence verification profile")
        seen.add(digest)
        decoded.append((digest, profile, payload))
    results: set[str] = set()
    qualifications: dict[str, dict[str, int]] = {}
    for digest, profile, payload in decoded:
        if profile == "training-record/v1":
            _verify_training_record(_strict_json(payload), seen)
            results.add(digest)
        elif profile == "behavior-report/v1":
            qualifications[digest] = _verify_behavior_report(
                _strict_json(payload), seen
            )
            results.add(digest)
        elif profile == "production-evaluation/v1":
            qualifications[digest] = _verify_production_evaluation(
                _strict_json(payload), seen
            )
            results.add(digest)
    return VerifiedEvidence(frozenset(seen), frozenset(results), qualifications)
