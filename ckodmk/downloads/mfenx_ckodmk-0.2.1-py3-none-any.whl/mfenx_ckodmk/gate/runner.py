"""ONNX Runtime deployment-assurance runner for a frozen CPU profile."""

from __future__ import annotations

import hashlib
import io
import json
import multiprocessing
import os
import platform
import stat
import statistics
import struct
import tempfile
import time
import zipfile
from decimal import Decimal
from pathlib import Path
from typing import Any

from mfenx_ckodmk import __version__

from .contract import ContractError, load_contract

MAX_ARTIFACT_BYTES = 64_000_000
MAX_DATASET_BYTES = 256_000_000
MAX_DATASET_EXPANDED_BYTES = 256_000_000
MAX_DATASET_MEMBERS = 4
MAX_CONTRACT_BYTES = 1_000_000
MAX_GATE_RESULT_BYTES = 16_000_000
GATE_WALL_TIMEOUT_SECONDS = 180
GATE_CPU_LIMIT_SECONDS = 120
GATE_ADDRESS_SPACE_BYTES = 3_000_000_000


def _contract_binding(
    path: Path, observed_digest: str, expected_digest: str, policy_profile: str
) -> dict[str, Any]:
    return {
        "sha256": observed_digest,
        "expected_sha256": expected_digest,
        "matched": observed_digest == expected_digest,
        "bytes": path.stat().st_size,
        "policy_profile": policy_profile,
        "trust": "caller-supplied expected digest; authorization is external to CKODMK",
    }


def _sha256(path: Path, maximum: int) -> str:
    if path.is_symlink() or not path.is_file():
        raise ContractError(f"artifact is not a regular, non-symlink file: {path}")
    if path.stat().st_size > maximum:
        raise ContractError(f"artifact exceeds byte limit: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _snapshot_file(source: Path, destination: Path, maximum: int) -> None:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise ContractError(f"cannot open artifact safely: {source}") from exc
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > maximum:
            raise ContractError(f"artifact is not a bounded regular file: {source}")
        with (
            os.fdopen(descriptor, "rb", closefd=False) as input_handle,
            destination.open("xb") as output_handle,
        ):
            copied = 0
            while True:
                chunk = input_handle.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > maximum:
                    raise ContractError(f"artifact grew beyond size limit: {source}")
                output_handle.write(chunk)
            output_handle.flush()
            os.fsync(output_handle.fileno())
    finally:
        os.close(descriptor)


def _check_npz_container(
    path: Path,
    np: Any,
    input_key: str,
    label_key: str,
    samples: int,
) -> None:
    try:
        raw = path.read_bytes()
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members = archive.infolist()
            expected_members = [f"{input_key}.npy", f"{label_key}.npy"]
            actual_members = [member.filename for member in members]
            if (
                len(members) != len(expected_members)
                or len(members) > MAX_DATASET_MEMBERS
                or actual_members != expected_members
                or archive.comment
            ):
                raise ContractError(
                    "dataset archive must be the canonical declared input/label sequence"
                )
            if any(
                member.is_dir()
                or "/" in member.filename
                or "\\" in member.filename
                or member.file_size > MAX_DATASET_EXPANDED_BYTES
                or member.compress_type != zipfile.ZIP_STORED
                or member.flag_bits != 0
                or member.comment
                or member.extra
                for member in members
            ):
                raise ContractError("dataset archive is not canonical stored NPZ")
            if sum(member.file_size for member in members) > MAX_DATASET_EXPANDED_BYTES:
                raise ContractError("dataset expanded size exceeds limit")
            with np.load(io.BytesIO(raw), allow_pickle=False) as arrays:
                inputs = arrays[input_key]
                labels = arrays[label_key]
            if (
                inputs.dtype.str != "<f4"
                or labels.dtype.str != "<i8"
                or not inputs.flags.c_contiguous
                or not labels.flags.c_contiguous
                or inputs.ndim < 2
                or inputs.shape[0] != samples
                or labels.shape != (samples,)
            ):
                raise ContractError(
                    "dataset arrays violate canonical Float32/int64 C-order profile"
                )
            canonical = io.BytesIO()
            np.savez(canonical, **{input_key: inputs, label_key: labels})
            if canonical.getvalue() != raw:
                raise ContractError("dataset bytes are not canonical NumPy stored NPZ")
    except ContractError:
        raise
    except (KeyError, ValueError, zipfile.BadZipFile) as exc:
        raise ContractError("dataset is not a valid NumPy NPZ container") from exc


def _onnx_tensors(graph: Any) -> Any:
    import onnx

    yield from graph.initializer
    for sparse in graph.sparse_initializer:
        yield sparse.values
        yield sparse.indices
    for node in graph.node:
        for attribute in node.attribute:
            if attribute.type == onnx.AttributeProto.TENSOR:
                yield attribute.t
            elif attribute.type == onnx.AttributeProto.TENSORS:
                yield from attribute.tensors
            elif attribute.type == onnx.AttributeProto.GRAPH:
                yield from _onnx_tensors(attribute.g)
            elif attribute.type == onnx.AttributeProto.GRAPHS:
                for nested in attribute.graphs:
                    yield from _onnx_tensors(nested)


def _load_self_contained_onnx(path: Path, onnx: Any) -> Any:
    try:
        model = onnx.load(str(path), load_external_data=False)
        all_tensors = list(_onnx_tensors(model.graph))
        for function in model.functions:
            synthetic_graph = onnx.GraphProto()
            synthetic_graph.node.extend(function.node)
            all_tensors.extend(_onnx_tensors(synthetic_graph))
        if any(
            onnx.external_data_helper.uses_external_data(tensor)
            for tensor in all_tensors
        ):
            raise ContractError(
                "external ONNX tensor data is unsupported because the contract binds one file"
            )
        onnx.checker.check_model(model, full_check=True)
        return model
    except ContractError:
        raise
    except Exception as exc:
        raise ContractError(
            f"ONNX artifact validation rejected {path.name}: {type(exc).__name__}"
        ) from exc


def _load_npz_dataset(
    path: Path,
    np: Any,
    input_key: str,
    label_key: str,
) -> tuple[Any, Any]:
    try:
        with np.load(path, allow_pickle=False) as dataset:
            input_values = np.asarray(dataset[input_key])
            labels = np.asarray(dataset[label_key])
        if input_values.dtype != np.dtype("float32") or labels.dtype != np.dtype(
            "int64"
        ):
            raise ContractError(
                "dataset arrays must already be float32 inputs and int64 labels"
            )
        input_values = np.ascontiguousarray(input_values)
        labels = np.ascontiguousarray(labels)
        return input_values, labels
    except ContractError:
        raise
    except Exception as exc:
        raise ContractError(f"dataset decoding failed: {type(exc).__name__}") from exc


def _create_session(ort: Any, path: Path, options: Any) -> Any:
    try:
        return ort.InferenceSession(
            str(path), options, providers=["CPUExecutionProvider"]
        )
    except Exception as exc:
        raise ContractError(
            f"ONNX Runtime rejected {path.name}: {type(exc).__name__}"
        ) from exc


def _execute(session: Any, input_name: str, values: Any) -> Any:
    try:
        return session.run(None, {input_name: values})
    except Exception as exc:
        raise ContractError(
            f"ONNX Runtime execution failed: {type(exc).__name__}"
        ) from exc


def _validate_session_profile(
    session: Any, contract: dict[str, Any], label: str
) -> tuple[str, str, dict[str, Any]]:
    inputs = session.get_inputs()
    outputs = session.get_outputs()
    if len(inputs) != 1 or len(outputs) != 1:
        raise ContractError(f"{label} must expose exactly one input and one output")
    input_meta = inputs[0]
    output_meta = outputs[0]
    sample_shape = contract["dataset"]["sample_shape"]
    class_count = contract["output"]["class_count"]
    expected_input_shape = [1, *sample_shape]
    expected_output_shape = [1, class_count]
    if input_meta.type != "tensor(float)" or output_meta.type != "tensor(float)":
        raise ContractError(f"{label} must use Float32 input and output tensors")
    if len(input_meta.shape) != len(expected_input_shape):
        raise ContractError(f"{label} input rank differs from the contract")
    if len(output_meta.shape) != len(expected_output_shape):
        raise ContractError(f"{label} output rank differs from the contract")
    for actual, expected in zip(input_meta.shape, expected_input_shape):
        if type(actual) is int and actual != expected:
            raise ContractError(
                f"{label} input shape rejects the declared batch-one shape"
            )
    for actual, expected in zip(output_meta.shape, expected_output_shape):
        if type(actual) is int and actual != expected:
            raise ContractError(
                f"{label} output shape rejects the declared logits shape"
            )
    return (
        input_meta.name,
        output_meta.name,
        {
            "input": {
                "name": input_meta.name,
                "runtime_shape": input_meta.shape,
                "invocation_shape": expected_input_shape,
                "dtype": input_meta.type,
                "layout": contract["dataset"]["input_layout"],
            },
            "output": {
                "name": output_meta.name,
                "runtime_shape": output_meta.shape,
                "invocation_shape": expected_output_shape,
                "dtype": output_meta.type,
                "semantic_role": contract["output"]["semantic_role"],
                "decision_rule": contract["output"]["decision_rule"],
            },
        },
    )


def _execute_batch_one(
    session: Any,
    input_name: str,
    input_values: Any,
    class_count: int,
    np: Any,
    label: str,
) -> Any:
    outputs = np.empty((len(input_values), class_count), dtype=np.float32)
    for index in range(len(input_values)):
        batch = input_values[index : index + 1]
        value = np.asarray(_execute(session, input_name, batch)[0])
        if value.dtype != np.dtype("float32") or value.shape != (1, class_count):
            raise ContractError(
                f"{label} output at sample {index} violates Float32 batch-one profile"
            )
        if not np.isfinite(value).all():
            raise ContractError(f"{label} output contains non-finite values")
        outputs[index] = value[0]
    return outputs


def _cpu_field(field: str) -> str:
    try:
        for line in Path("/proc/cpuinfo").read_text(encoding="utf-8").splitlines():
            if line.lower().startswith(field.lower()):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return "unknown"


def _system_text(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8").strip() or "unknown"
    except OSError:
        return "unknown"


def _cpu_governor() -> str:
    governors = {
        path.read_text(encoding="utf-8").strip()
        for path in Path("/sys/devices/system/cpu").glob(
            "cpu[0-9]*/cpufreq/scaling_governor"
        )
        if path.is_file()
    }
    return ",".join(sorted(governors)) if governors else "unknown"


def observed_device(
    runtime_version: str,
    numpy_version: str,
    onnx_version: str,
) -> dict[str, Any]:
    return {
        "ckodmk_version": __version__,
        "cpu_model": _cpu_field("model name") or platform.processor() or "unknown",
        "cpu_microcode": _cpu_field("microcode"),
        "cpu_governor": _cpu_governor(),
        "cpu_logical_count": os.cpu_count() or 0,
        "hardware_vendor": _system_text("/sys/class/dmi/id/sys_vendor"),
        "hardware_product": _system_text("/sys/class/dmi/id/product_name"),
        "hardware_board": _system_text("/sys/class/dmi/id/board_name"),
        "machine": platform.machine(),
        "node_name": platform.node(),
        "system": platform.system(),
        "kernel": platform.release(),
        "python_version": platform.python_version(),
        "numpy_version": numpy_version,
        "onnx_version": onnx_version,
        "runtime": f"onnxruntime-cpu/{runtime_version}",
    }


def _device_matches(
    expected: dict[str, Any], observed: dict[str, Any]
) -> tuple[bool, list[str]]:
    differences = []
    for field in [
        "ckodmk_version",
        "cpu_model",
        "cpu_microcode",
        "cpu_governor",
        "cpu_logical_count",
        "hardware_vendor",
        "hardware_product",
        "hardware_board",
        "machine",
        "node_name",
        "system",
        "kernel",
        "python_version",
        "numpy_version",
        "onnx_version",
        "runtime",
    ]:
        if expected[field] != observed[field]:
            differences.append(
                f"{field}: expected={expected[field]!r}, observed={observed[field]!r}"
            )
    return not differences, differences


def _percentile_higher(values: list[int], percentile: float) -> int:
    ordered = sorted(values)
    index = min(len(ordered) - 1, int((len(ordered) - 1) * percentile + 0.999999999))
    return ordered[index]


def _claim_result(
    claim: dict[str, Any],
    metrics: dict[str, Any],
    device_match: bool,
) -> dict[str, Any]:
    relation = claim["relation"]
    result: dict[str, Any] = {
        "id": claim["id"],
        "criticality": claim["criticality"],
        "relation": relation,
        "boundary": claim["boundary"],
        "evidence": claim["evidence_required"],
    }
    if relation == "artifact_identity":
        result.update({"result": "PASS", "observed": metrics["artifact_identity"]})
        return result
    if claim["boundary"] == "onnxruntime-cpu-observation" and not device_match:
        result.update({"result": "INCONCLUSIVE", "reason": "device profile mismatch"})
        return result
    if relation == "decision_invariant":
        mismatches = metrics["decision_mismatches"]
        result.update(
            {
                "result": "PASS" if mismatches == 0 else "FAIL",
                "observed": {"mismatches": mismatches, "samples": metrics["samples"]},
            }
        )
    elif relation == "bounded_deviation":
        maximum_text = claim["parameters"]["maximum"]
        maximum = Decimal(maximum_text)
        observed = metrics["maximum_absolute_output_deviation"]
        result.update(
            {
                "result": (
                    "PASS" if Decimal.from_float(observed) <= maximum else "FAIL"
                ),
                "observed": {
                    "linf": observed,
                    "linf_exact_binary64_decimal": str(Decimal.from_float(observed)),
                    "maximum_policy_decimal": maximum_text,
                    "samples": metrics["samples"],
                },
            }
        )
    elif relation == "finite_set_accuracy_delta":
        minimum_text = claim["parameters"]["minimum"]
        minimum = Decimal(minimum_text)
        minimum_numerator, minimum_denominator = minimum.as_integer_ratio()
        numerator = metrics["candidate_correct_count"] - metrics["source_correct_count"]
        denominator = metrics["samples"]
        passes = numerator * minimum_denominator >= minimum_numerator * denominator
        result.update(
            {
                "result": "PASS" if passes else "FAIL",
                "observed": {
                    "accuracy_delta": numerator / denominator,
                    "accuracy_delta_fraction": {
                        "numerator": numerator,
                        "denominator": denominator,
                    },
                    "minimum_policy_decimal": minimum_text,
                    "scope": "complete declared finite dataset; no population inference",
                },
            }
        )
    elif relation == "finite_run_latency":
        maximum_text = claim["parameters"]["maximum"]
        maximum = Decimal(maximum_text)
        maximum_numerator, maximum_denominator = maximum.as_integer_ratio()
        observed_ns = metrics["candidate_p95_latency_ns"]
        observed = metrics["candidate_p95_latency_ms"]
        passes = observed_ns * maximum_denominator <= maximum_numerator * 1_000_000
        result.update(
            {
                "result": "PASS" if passes else "FAIL",
                "observed": {
                    "sample_p95_latency_ms": observed,
                    "sample_p95_latency_ns": observed_ns,
                    "maximum_policy_decimal": maximum_text,
                    "measured_runs": metrics["measured_latency_runs"],
                    "scope": "recorded finite run; no population-tail guarantee",
                },
            }
        )
    else:
        result.update({"result": "INCONCLUSIVE", "reason": "unsupported relation"})
    return result


def _run_onnx_gate(
    contract_path: Path,
    source_path: Path,
    candidate_path: Path,
    dataset_path: Path,
    contract: dict[str, Any],
    contract_digest: str,
    expected_contract_digest: str,
) -> dict[str, Any]:
    try:
        import numpy as np
        import onnx
        import onnxruntime as ort
    except ImportError as exc:
        raise ContractError(
            "real-model lab requires numpy, onnx, and onnxruntime"
        ) from exc

    observed_before = observed_device(ort.__version__, np.__version__, onnx.__version__)
    before_match, before_differences = _device_matches(
        contract["device"], observed_before
    )

    source_digest = _sha256(source_path, MAX_ARTIFACT_BYTES)
    candidate_digest = _sha256(candidate_path, MAX_ARTIFACT_BYTES)
    dataset_digest = _sha256(dataset_path, MAX_DATASET_BYTES)
    identity = {
        "source": source_digest == contract["source"]["sha256"],
        "candidate": candidate_digest == contract["candidate"]["sha256"],
        "dataset": dataset_digest == contract["dataset"]["sha256"],
    }
    if not all(identity.values()):
        return {
            "schema": "mfenx/ckodmk-gate-report/v1",
            "decision": "BLOCK",
            "contract_id": contract["contract_id"],
            "contract": _contract_binding(
                contract_path,
                contract_digest,
                expected_contract_digest,
                contract["policy_profile"],
            ),
            "reason": "artifact identity mismatch",
            "artifact_identity": identity,
            "authentication": "none",
        }

    _load_self_contained_onnx(source_path, onnx)
    _load_self_contained_onnx(candidate_path, onnx)
    _check_npz_container(
        dataset_path,
        np,
        contract["dataset"]["input_key"],
        contract["dataset"]["label_key"],
        contract["dataset"]["samples"],
    )
    input_values, labels = _load_npz_dataset(
        dataset_path,
        np,
        contract["dataset"]["input_key"],
        contract["dataset"]["label_key"],
    )
    expected_dataset_shape = (
        contract["dataset"]["samples"],
        *contract["dataset"]["sample_shape"],
    )
    if input_values.shape != expected_dataset_shape or labels.shape != (
        len(input_values),
    ):
        raise ContractError("dataset shape or declared sample count mismatch")
    if not np.isfinite(input_values).all():
        raise ContractError("dataset contains non-finite values")

    options = ort.SessionOptions()
    options.intra_op_num_threads = contract["device"]["intra_op_threads"]
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    source_session = _create_session(ort, source_path, options)
    candidate_session = _create_session(ort, candidate_path, options)
    if source_session.get_providers() != [
        "CPUExecutionProvider"
    ] or candidate_session.get_providers() != ["CPUExecutionProvider"]:
        raise ContractError("runtime provider selection differs from the CPU contract")
    source_name, _, source_interface = _validate_session_profile(
        source_session, contract, "source model"
    )
    candidate_name, _, candidate_interface = _validate_session_profile(
        candidate_session, contract, "candidate model"
    )
    class_count = contract["output"]["class_count"]
    source_output = _execute_batch_one(
        source_session,
        source_name,
        input_values,
        class_count,
        np,
        "source model",
    )
    candidate_output = _execute_batch_one(
        candidate_session,
        candidate_name,
        input_values,
        class_count,
        np,
        "candidate model",
    )
    source_replay = _execute_batch_one(
        source_session,
        source_name,
        input_values,
        class_count,
        np,
        "source model deterministic replay",
    )
    candidate_replay = _execute_batch_one(
        candidate_session,
        candidate_name,
        input_values,
        class_count,
        np,
        "candidate model deterministic replay",
    )
    if not np.array_equal(
        source_output.view(np.uint32), source_replay.view(np.uint32)
    ) or not np.array_equal(
        candidate_output.view(np.uint32), candidate_replay.view(np.uint32)
    ):
        raise ContractError(
            "source or candidate is not bitwise deterministic under repeated batch-one execution"
        )
    if not np.logical_and(labels >= 0, labels < class_count).all():
        raise ContractError("dataset labels are outside the model output range")
    source_decisions = source_output.argmax(axis=1)
    candidate_decisions = candidate_output.argmax(axis=1)
    source_correct = source_decisions == labels
    candidate_correct = candidate_decisions == labels
    with np.errstate(over="ignore", invalid="ignore"):
        output_difference = source_output.astype(np.float64) - candidate_output.astype(
            np.float64
        )
    if not np.isfinite(output_difference).all():
        raise ContractError("output deviation cannot be represented as finite float64")

    latency_claims = [
        claim
        for claim in contract["claims"]
        if claim["relation"] == "finite_run_latency"
    ]
    warmups = max(
        (claim["parameters"]["warmup_runs"] for claim in latency_claims), default=10
    )
    measured = max(
        (claim["parameters"]["measured_runs"] for claim in latency_claims), default=100
    )
    latency_indices = [
        (index * len(input_values)) // measured
        if measured <= len(input_values)
        else index % len(input_values)
        for index in range(measured)
    ]
    for index in range(warmups):
        sample_index = latency_indices[index % len(latency_indices)]
        item = input_values[sample_index : sample_index + 1]
        sessions = (
            (
                (source_session, source_name),
                (candidate_session, candidate_name),
            )
            if index % 2 == 0
            else (
                (candidate_session, candidate_name),
                (source_session, source_name),
            )
        )
        for session, name in sessions:
            _execute(session, name, item)
    source_timings_ns = []
    candidate_timings_ns = []
    for index, sample_index in enumerate(latency_indices):
        item = input_values[sample_index : sample_index + 1]
        sessions = (
            (
                ("source", source_session, source_name),
                ("candidate", candidate_session, candidate_name),
            )
            if index % 2 == 0
            else (
                ("candidate", candidate_session, candidate_name),
                ("source", source_session, source_name),
            )
        )
        for label, session, name in sessions:
            started = time.perf_counter_ns()
            _execute(session, name, item)
            elapsed = time.perf_counter_ns() - started
            if label == "source":
                source_timings_ns.append(elapsed)
            else:
                candidate_timings_ns.append(elapsed)
    source_timings = [value / 1_000_000.0 for value in source_timings_ns]
    candidate_timings = [value / 1_000_000.0 for value in candidate_timings_ns]

    observed_after = observed_device(ort.__version__, np.__version__, onnx.__version__)
    after_match, after_differences = _device_matches(contract["device"], observed_after)
    device_match = before_match and after_match
    device_differences = [
        *(f"before: {difference}" for difference in before_differences),
        *(f"after: {difference}" for difference in after_differences),
    ]
    absolute_difference = np.abs(output_difference)
    per_sample_linf = np.max(absolute_difference, axis=1)
    maximum_index = tuple(
        int(value)
        for value in np.unravel_index(
            int(np.argmax(absolute_difference)), absolute_difference.shape
        )
    )
    mismatch_indices = np.flatnonzero(source_decisions != candidate_decisions)
    gained_indices = np.flatnonzero(np.logical_and(~source_correct, candidate_correct))
    lost_indices = np.flatnonzero(np.logical_and(source_correct, ~candidate_correct))
    source_correct_count = int(np.count_nonzero(source_correct))
    candidate_correct_count = int(np.count_nonzero(candidate_correct))
    metrics = {
        "artifact_identity": identity,
        "samples": len(input_values),
        "maximum_absolute_output_deviation": float(absolute_difference[maximum_index]),
        "decision_mismatches": len(mismatch_indices),
        "source_correct_count": source_correct_count,
        "candidate_correct_count": candidate_correct_count,
        "source_accuracy": source_correct_count / len(labels),
        "candidate_accuracy": candidate_correct_count / len(labels),
        "source_median_latency_ms": statistics.median(source_timings),
        "source_p95_latency_ns": _percentile_higher(source_timings_ns, 0.95),
        "source_p95_latency_ms": _percentile_higher(source_timings_ns, 0.95)
        / 1_000_000.0,
        "candidate_median_latency_ms": statistics.median(candidate_timings),
        "candidate_p95_latency_ns": _percentile_higher(candidate_timings_ns, 0.95),
        "candidate_p95_latency_ms": _percentile_higher(candidate_timings_ns, 0.95)
        / 1_000_000.0,
        "measured_latency_runs": measured,
    }
    claims = [
        _claim_result(claim, metrics, device_match) for claim in contract["claims"]
    ]
    required = [claim for claim in claims if claim["criticality"] == "required"]
    decision = (
        "BLOCK"
        if any(claim["result"] == "FAIL" for claim in required)
        else "INCONCLUSIVE"
        if any(claim["result"] == "INCONCLUSIVE" for claim in required)
        else "PASS"
    )
    return {
        "schema": "mfenx/ckodmk-gate-report/v1",
        "decision": decision,
        "contract_id": contract["contract_id"],
        "contract": _contract_binding(
            contract_path,
            contract_digest,
            expected_contract_digest,
            contract["policy_profile"],
        ),
        "artifacts": {
            "source": {"sha256": source_digest, "bytes": source_path.stat().st_size},
            "candidate": {
                "sha256": candidate_digest,
                "bytes": candidate_path.stat().st_size,
            },
            "dataset": {"sha256": dataset_digest, "bytes": dataset_path.stat().st_size},
        },
        "device": {
            "expected": contract["device"],
            "observed_before": observed_before,
            "observed_after": observed_after,
            "matched": device_match,
            "differences": device_differences,
            "expected_profile_id": contract["device"]["profile_id"],
            "profile_id_role": "out-of-band policy label; not inferred from hardware",
        },
        "interfaces": {
            "source": source_interface,
            "candidate": candidate_interface,
        },
        "claims": claims,
        "measurements": {
            "samples": metrics["samples"],
            "maximum_absolute_output_deviation": metrics[
                "maximum_absolute_output_deviation"
            ],
            "decision_mismatches": metrics["decision_mismatches"],
            "source_accuracy": metrics["source_accuracy"],
            "candidate_accuracy": metrics["candidate_accuracy"],
            "source_median_latency_ms": metrics["source_median_latency_ms"],
            "source_p95_latency_ns": metrics["source_p95_latency_ns"],
            "source_p95_latency_ms": metrics["source_p95_latency_ms"],
            "candidate_median_latency_ms": metrics["candidate_median_latency_ms"],
            "candidate_p95_latency_ns": metrics["candidate_p95_latency_ns"],
            "candidate_p95_latency_ms": metrics["candidate_p95_latency_ms"],
            "measured_latency_runs": measured,
        },
        "raw_observation_evidence": {
            "output_shape": [len(input_values), class_count],
            "layout": "row-major",
            "source_outputs_float32_hex": [
                f"{int(value):08x}"
                for value in source_output.view(np.uint32).reshape(-1)
            ],
            "candidate_outputs_float32_hex": [
                f"{int(value):08x}"
                for value in candidate_output.view(np.uint32).reshape(-1)
            ],
            "labels": labels.tolist(),
            "source_decisions": source_decisions.tolist(),
            "candidate_decisions": candidate_decisions.tolist(),
            "source_correct": source_correct.astype(np.uint8).tolist(),
            "candidate_correct": candidate_correct.astype(np.uint8).tolist(),
            "decision_mismatch_indices": mismatch_indices.tolist(),
            "candidate_gain_indices": gained_indices.tolist(),
            "candidate_loss_indices": lost_indices.tolist(),
            "per_sample_linf": per_sample_linf.tolist(),
            "per_sample_linf_binary64_bits_hex": [
                struct.pack(">d", float(value)).hex() for value in per_sample_linf
            ],
            "maximum_deviation_witness": {
                "sample_index": maximum_index[0],
                "class_index": maximum_index[1],
                "source_float32_hex": float(source_output[maximum_index]).hex(),
                "candidate_float32_hex": float(candidate_output[maximum_index]).hex(),
                "absolute_difference_binary64_hex": float(
                    absolute_difference[maximum_index]
                ).hex(),
            },
            "source_latency_ns": source_timings_ns,
            "candidate_latency_ns": candidate_timings_ns,
            "candidate_latency_sample_indices": latency_indices,
            "bitwise_deterministic_replay": True,
            "authority": (
                "raw observations emitted by the Python runner; independently "
                "adjudicable but not independently re-executed"
            ),
        },
        "evidence_boundary": {
            "kind": "device-observation",
            "universal_equivalence": "NOT_ESTABLISHED",
            "opaque_components": [
                "ONNX Runtime kernels",
                "operating system",
                "CPU hardware",
            ],
        },
        "evaluation_semantics": {
            "dataset_input_dtype": "float32",
            "dataset_label_dtype": "int64",
            "batch_size": 1,
            "sample_shape": contract["dataset"]["sample_shape"],
            "output_dtype": "float32",
            "output_class_count": class_count,
            "decision": "numpy.argmax(axis=1), first maximum wins ties",
            "output_selection": "the sole model output",
            "execution_provider": "CPUExecutionProvider",
            "execution_mode": "ORT_SEQUENTIAL",
            "graph_optimization_during_gate": "ORT_DISABLE_ALL",
            "inter_op_threads": 1,
            "intra_op_threads": contract["device"]["intra_op_threads"],
            "latency_clock": "time.perf_counter_ns",
            "latency_pairing": (
                "source and candidate use identical sample indices; execution order "
                "alternates each measured pair"
            ),
            "sample_p95_rule": "sorted index ceil(0.95 * (n - 1)), zero-based",
        },
        "authentication": "none",
    }


def _sandbox_worker(
    contract_path: str,
    source_path: str,
    candidate_path: str,
    dataset_path: str,
    contract: dict[str, Any],
    contract_digest: str,
    expected_contract_digest: str,
    result_path: str,
) -> None:
    """Execute native model parsing and inference behind process resource limits."""

    try:
        import resource

        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(
            resource.RLIMIT_CPU,
            (GATE_CPU_LIMIT_SECONDS, GATE_CPU_LIMIT_SECONDS + 1),
        )
        resource.setrlimit(
            resource.RLIMIT_AS,
            (GATE_ADDRESS_SPACE_BYTES, GATE_ADDRESS_SPACE_BYTES),
        )
        resource.setrlimit(
            resource.RLIMIT_FSIZE,
            (MAX_GATE_RESULT_BYTES, MAX_GATE_RESULT_BYTES),
        )
        report = _run_onnx_gate(
            Path(contract_path),
            Path(source_path),
            Path(candidate_path),
            Path(dataset_path),
            contract,
            contract_digest,
            expected_contract_digest,
        )
        envelope: dict[str, Any] = {"status": "OK", "report": report}
    except ContractError as exc:
        envelope = {
            "status": "REJECTED",
            "kind": "FAIL_CLOSED_VALIDATION",
            "message": str(exc)[:512],
        }
    except Exception as exc:  # noqa: BLE001 -- native worker must fail closed
        envelope = {
            "status": "REJECTED",
            "kind": "SANDBOX_WORKER_ERROR",
            "message": type(exc).__name__,
        }
    payload = json.dumps(
        envelope, allow_nan=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    if len(payload) + 1 > MAX_GATE_RESULT_BYTES:
        raise RuntimeError("sandbox result exceeds byte limit")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
    descriptor = os.open(result_path, flags, 0o600)
    try:
        with os.fdopen(descriptor, "wb", closefd=False) as handle:
            handle.write(payload + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        os.close(descriptor)


def _sandbox_block(
    contract_path: Path,
    contract: dict[str, Any],
    contract_digest: str,
    expected_contract_digest: str,
    kind: str,
    message: str,
) -> dict[str, Any]:
    return {
        "schema": "mfenx/ckodmk-gate-report/v1",
        "decision": "BLOCK",
        "contract_id": contract["contract_id"],
        "contract": _contract_binding(
            contract_path,
            contract_digest,
            expected_contract_digest,
            contract["policy_profile"],
        ),
        "reason": "artifact or evaluation evidence rejected",
        "diagnostic": {"kind": kind, "message": message[:512]},
        "sandbox": {
            "process_isolation": True,
            "wall_timeout_seconds": GATE_WALL_TIMEOUT_SECONDS,
            "cpu_limit_seconds": GATE_CPU_LIMIT_SECONDS,
            "address_space_bytes": GATE_ADDRESS_SPACE_BYTES,
            "syscall_isolation": False,
        },
        "authentication": "none",
    }


def _run_sandboxed(
    contract_path: Path,
    source_path: Path,
    candidate_path: Path,
    dataset_path: Path,
    contract: dict[str, Any],
    contract_digest: str,
    expected_contract_digest: str,
    result_path: Path,
) -> dict[str, Any]:
    context = multiprocessing.get_context("spawn")
    process = context.Process(
        target=_sandbox_worker,
        args=(
            str(contract_path),
            str(source_path),
            str(candidate_path),
            str(dataset_path),
            contract,
            contract_digest,
            expected_contract_digest,
            str(result_path),
        ),
        name="ckodmk-onnx-gate-worker",
    )
    try:
        process.start()
        process.join(GATE_WALL_TIMEOUT_SECONDS)
    except (OSError, RuntimeError) as exc:
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_START_FAILURE",
            type(exc).__name__,
        )
    if process.is_alive():
        process.terminate()
        process.join(5)
        if process.is_alive():
            process.kill()
            process.join(5)
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_TIMEOUT",
            "native model evaluation exceeded the wall-clock limit",
        )
    if process.exitcode != 0 or not result_path.is_file():
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_PROCESS_FAILURE",
            f"native model worker exited without a result (exit={process.exitcode})",
        )
    with result_path.open("rb") as handle:
        raw = handle.read(MAX_GATE_RESULT_BYTES + 1)
    if len(raw) > MAX_GATE_RESULT_BYTES:
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_RESULT_REJECTED",
            "native model worker result exceeded the byte limit",
        )
    try:
        envelope = json.loads(raw.decode("utf-8", errors="strict"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_RESULT_REJECTED",
            type(exc).__name__,
        )
    if type(envelope) is not dict or envelope.get("status") != "OK":
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            str(envelope.get("kind", "SANDBOX_RESULT_REJECTED"))[:64]
            if type(envelope) is dict
            else "SANDBOX_RESULT_REJECTED",
            str(envelope.get("message", "worker rejected evidence"))
            if type(envelope) is dict
            else "worker returned a malformed result",
        )
    report = envelope.get("report")
    if (
        type(report) is not dict
        or report.get("schema") != "mfenx/ckodmk-gate-report/v1"
        or report.get("decision") not in {"PASS", "BLOCK", "INCONCLUSIVE"}
        or report.get("contract", {}).get("sha256") != contract_digest
        or report.get("contract", {}).get("expected_sha256") != expected_contract_digest
    ):
        return _sandbox_block(
            contract_path,
            contract,
            contract_digest,
            expected_contract_digest,
            "SANDBOX_RESULT_REJECTED",
            "worker report is not bound to the frozen policy",
        )
    report["sandbox"] = {
        "process_isolation": True,
        "wall_timeout_seconds": GATE_WALL_TIMEOUT_SECONDS,
        "cpu_limit_seconds": GATE_CPU_LIMIT_SECONDS,
        "address_space_bytes": GATE_ADDRESS_SPACE_BYTES,
        "syscall_isolation": False,
    }
    report["implementation"] = {
        "ckodmk_version": __version__,
        "runner_source_sha256": _sha256(Path(__file__), 1_000_000),
        "contract_parser_source_sha256": _sha256(
            Path(load_contract.__code__.co_filename), 1_000_000
        ),
        "authority": (
            "contextual source-file binding only; no signature, loaded-code attestation, "
            "or independent ONNX execution"
        ),
    }
    return report


def run_onnx_gate(
    contract_path: Path,
    source_path: Path,
    candidate_path: Path,
    dataset_path: Path,
    expected_contract_digest: str,
) -> dict[str, Any]:
    """Run the gate and turn evidence/artifact rejection into a BLOCK report.

    A malformed release contract or a missing lab dependency remains a command
    error because no valid policy exists from which a release decision can be
    derived. Once a contract is valid, candidate/data/runtime validation fails
    closed with a machine-readable report.
    """

    if (
        type(expected_contract_digest) is not str
        or len(expected_contract_digest) != 71
        or not expected_contract_digest.startswith("sha256:")
        or any(
            character not in "0123456789abcdef"
            for character in expected_contract_digest.removeprefix("sha256:")
        )
    ):
        raise ContractError("expected contract digest must be canonical SHA-256")
    try:
        bytes.fromhex(expected_contract_digest.removeprefix("sha256:"))
    except ValueError as exc:
        raise ContractError(
            "expected contract digest must be canonical SHA-256"
        ) from exc
    with tempfile.TemporaryDirectory(prefix="ckodmk-gate-snapshot-") as temporary:
        directory = Path(temporary)
        frozen_contract = directory / "contract.json"
        frozen_source = directory / "source.onnx"
        frozen_candidate = directory / "candidate.onnx"
        frozen_dataset = directory / "dataset.npz"
        sandbox_result = directory / "sandbox-result.json"
        _snapshot_file(contract_path, frozen_contract, MAX_CONTRACT_BYTES)
        contract = load_contract(str(frozen_contract))
        contract_digest = _sha256(frozen_contract, MAX_CONTRACT_BYTES)
        if contract_digest != expected_contract_digest:
            return {
                "schema": "mfenx/ckodmk-gate-report/v1",
                "decision": "BLOCK",
                "contract_id": contract["contract_id"],
                "contract": _contract_binding(
                    frozen_contract,
                    contract_digest,
                    expected_contract_digest,
                    contract["policy_profile"],
                ),
                "reason": "release-authority contract digest mismatch",
                "authentication": "none",
            }
        try:
            _snapshot_file(source_path, frozen_source, MAX_ARTIFACT_BYTES)
            _snapshot_file(candidate_path, frozen_candidate, MAX_ARTIFACT_BYTES)
            _snapshot_file(dataset_path, frozen_dataset, MAX_DATASET_BYTES)
            return _run_sandboxed(
                frozen_contract,
                frozen_source,
                frozen_candidate,
                frozen_dataset,
                contract,
                contract_digest,
                expected_contract_digest,
                sandbox_result,
            )
        except ContractError as exc:
            return _sandbox_block(
                frozen_contract,
                contract,
                contract_digest,
                expected_contract_digest,
                "FAIL_CLOSED_VALIDATION",
                str(exc),
            )
