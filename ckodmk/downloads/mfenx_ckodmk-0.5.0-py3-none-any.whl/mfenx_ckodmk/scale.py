"""Independent ONNX tensor inventory and model-scale-v1 verification."""

from __future__ import annotations

import hashlib
import json
import math
import os
import stat
import struct
from itertools import pairwise
from pathlib import Path
from typing import Any

SCALE_SCHEMA = "mfenx/model-scale/v1"
SCALE_DECISION = "SCALE_RECORDED"


class ScaleError(ValueError):
    """A scale attestation is malformed or disagrees with its bound models."""


_PARAMETER_SLOTS = {
    "Conv": (1, 2),
    "Gemm": (1, 2),
    "MatMul": (1,),
    "QLinearConv": (3, 8),
    "QGemm": (3, 6),
}
_NONPARAMETER_SLOTS = {
    "DequantizeLinear": (1, 2),
    "QGemm": (1, 2, 4, 5, 7, 8),
    "QLinearConv": (1, 2, 4, 5, 6, 7),
    "QuantizeLinear": (1, 2),
    "ReduceSum": (1,),
    "Reshape": (1,),
    "Squeeze": (1,),
    "Unsqueeze": (1,),
}


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _exact(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if type(value) is not dict or set(value) != keys:
        raise ScaleError(f"{label} fields are unsupported")
    return value


def _onnx_manifest(payload: bytes) -> dict[str, Any]:
    if not 0 < len(payload) <= 64 * 1024 * 1024:
        raise ScaleError("scale model is empty or exceeds its byte limit")
    try:
        import numpy as np
        import onnx
        from onnx import numpy_helper
    except ImportError as exc:
        raise ScaleError(
            "model-scale verification requires the production dependencies"
        ) from exc
    try:
        model = onnx.load_model_from_string(payload)
        onnx.checker.check_model(model, full_check=True)
    except Exception as exc:
        raise ScaleError(
            "scale model is not a valid self-contained ONNX model"
        ) from exc
    initializers = list(model.graph.initializer)
    if len(initializers) > 10_000:
        raise ScaleError("model tensor count exceeds the supported profile")
    names = [tensor.name for tensor in initializers]
    if (
        not initializers
        or any(not name for name in names)
        or len(set(names)) != len(names)
    ):
        raise ScaleError("model tensors are empty, unnamed, or duplicated")
    referenced = {name for node in model.graph.node for name in node.input if name}
    if any(name not in referenced for name in names):
        raise ScaleError("model contains an unexpected unreferenced tensor")
    parameter_names: set[str] = set()
    for node in model.graph.node:
        for index in _PARAMETER_SLOTS.get(node.op_type, ()):
            if index < len(node.input) and node.input[index] in names:
                parameter_names.add(node.input[index])
    classified = set(parameter_names)
    for node in model.graph.node:
        for index in _NONPARAMETER_SLOTS.get(node.op_type, ()):
            if index < len(node.input) and node.input[index] in names:
                classified.add(node.input[index])
    if classified != set(names):
        raise ScaleError("model contains a tensor whose parameter role is unsupported")
    records: list[dict[str, Any]] = []
    total = 0
    parameter_count = 0
    parameter_bytes = 0
    for tensor in sorted(initializers, key=lambda item: item.name):
        if tensor.data_location == onnx.TensorProto.EXTERNAL or tensor.external_data:
            raise ScaleError("external tensor data is unsupported")
        if (
            any(dimension < 0 for dimension in tensor.dims)
            or math.prod(tensor.dims) > 16_000_000
        ):
            raise ScaleError("tensor shape exceeds the supported profile")
        try:
            array = np.ascontiguousarray(numpy_helper.to_array(tensor))
        except Exception as exc:
            raise ScaleError(f"tensor {tensor.name!r} cannot be decoded") from exc
        elements = int(array.size)
        if elements < 1 or elements > 2**63 - 1:
            raise ScaleError("tensor element count is invalid")
        raw = array.tobytes(order="C")
        is_parameter = tensor.name in parameter_names
        total += elements
        if is_parameter:
            parameter_count += elements
            parameter_bytes += len(raw)
        records.append(
            {
                "dtype": str(array.dtype),
                "elements": elements,
                "is_parameter": is_parameter,
                "name": tensor.name,
                "shape": list(array.shape),
                "value_bytes": len(raw),
                "value_sha256": _sha256(raw),
            }
        )
    return {
        "all_initializer_elements": total,
        "parameter_count": parameter_count,
        "parameter_value_bytes": parameter_bytes,
        "tensors": records,
    }


def _onnx_architecture(payload: bytes) -> dict[str, int | None]:
    try:
        import onnx
    except ImportError as exc:
        raise ScaleError(
            "model-scale verification requires the production dependencies"
        ) from exc
    model = onnx.load_model_from_string(payload)
    tensors = {
        tensor.name: tuple(int(item) for item in tensor.dims)
        for tensor in model.graph.initializer
    }
    parameterized = [
        node for node in model.graph.node if node.op_type in _PARAMETER_SLOTS
    ]
    if not parameterized:
        raise ScaleError("model architecture has no supported parameterized layer")
    first = parameterized[0]
    weight_index = _PARAMETER_SLOTS[first.op_type][0]
    if weight_index >= len(first.input) or first.input[weight_index] not in tensors:
        raise ScaleError("model architecture weight binding is invalid")
    shape = tensors[first.input[weight_index]]
    if not shape:
        raise ScaleError("model architecture weight shape is empty")
    hidden_width = shape[0] if first.op_type in {"Conv", "QLinearConv"} else shape[-1]
    return {
        "attention_heads": None,
        "context_length": None,
        "hidden_width": hidden_width,
        "layers": len(parameterized),
        "vocabulary_size": None,
    }


def reconstruct_scale(
    source: bytes, candidate: bytes
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Reconstruct complete tensor inventories without trusting an attestation."""

    return _onnx_manifest(source), _onnx_manifest(candidate)


def validate_scale(
    document: Any,
    *,
    source: bytes,
    candidate: bytes,
    lineage: dict[str, Any],
    lineage_sha256: str,
) -> dict[str, Any]:
    """Verify scale claims from model bytes and preserve derivative identity."""

    scale = _exact(
        document,
        {
            "architecture_dimensions",
            "checkpoint_bytes",
            "compression",
            "deployment",
            "inference_measurement",
            "lineage_sha256",
            "native_model",
            "scale_decision",
            "schema",
            "training_scale",
        },
        "model scale",
    )
    if scale["schema"] != SCALE_SCHEMA or scale["scale_decision"] != SCALE_DECISION:
        raise ScaleError("unsupported model scale decision")
    if scale["lineage_sha256"] != lineage_sha256:
        raise ScaleError("model scale does not bind the lineage artifact")
    architecture = _exact(
        scale["architecture_dimensions"],
        {
            "attention_heads",
            "context_length",
            "hidden_width",
            "layers",
            "vocabulary_size",
        },
        "architecture dimensions",
    )
    for name, value in architecture.items():
        if value is not None and (type(value) is not int or value < 1):
            raise ScaleError(f"architecture dimension {name} is invalid")
    if architecture != _onnx_architecture(source):
        raise ScaleError("claimed architecture does not match checkpoint tensors")
    native = _exact(
        scale["native_model"],
        {
            "model_sha256",
            "native_precision",
            "tensor_manifest",
            "theoretical_weight_bytes",
            "total_parameters",
            "trainable_parameters",
        },
        "native model scale",
    )
    deployment = _exact(
        scale["deployment"],
        {
            "artifact_bytes",
            "deployment_precision",
            "model_sha256",
            "original_parameter_count",
            "tensor_manifest",
        },
        "deployment scale",
    )
    source_manifest, candidate_manifest = reconstruct_scale(source, candidate)
    if (
        native["model_sha256"] != _sha256(source)
        or native["tensor_manifest"] != source_manifest
    ):
        raise ScaleError("native tensor inventory or identity mismatch")
    if (
        deployment["model_sha256"] != _sha256(candidate)
        or deployment["tensor_manifest"] != candidate_manifest
    ):
        raise ScaleError("deployment tensor inventory or identity mismatch")
    if (
        native["total_parameters"] != source_manifest["parameter_count"]
        or native["trainable_parameters"] != source_manifest["parameter_count"]
    ):
        raise ScaleError(
            "native parameter count was not reconstructed from tensor shapes"
        )
    if native["theoretical_weight_bytes"] != source_manifest["parameter_value_bytes"]:
        raise ScaleError("native theoretical weight bytes are invalid")
    if (
        deployment["artifact_bytes"] != len(candidate)
        or deployment["original_parameter_count"] != native["total_parameters"]
    ):
        raise ScaleError(
            "deployment conversion changed or obscured original parameter identity"
        )
    if lineage["final_model_sha256"] != deployment["model_sha256"]:
        raise ScaleError("deployment scale and lineage candidate disagree")
    checkpoint = _exact(
        scale["checkpoint_bytes"],
        {"model", "optimizer", "optimizer_status"},
        "checkpoint bytes",
    )
    if (
        checkpoint["model"] != len(source)
        or type(checkpoint["optimizer"]) is not int
        or checkpoint["optimizer"] < 0
    ):
        raise ScaleError("checkpoint byte accounting is invalid")
    if (
        checkpoint["optimizer_status"] not in {"NOT_RETAINED", "NOT_APPLICABLE"}
        or checkpoint["optimizer"] != 0
    ):
        raise ScaleError("optimizer-state accounting is contradictory")
    compression = _exact(
        scale["compression"],
        {"method", "ratio_denominator", "ratio_numerator"},
        "compression",
    )
    if (
        type(compression["method"]) is not str
        or not compression["method"].isascii()
        or not compression["method"]
    ):
        raise ScaleError("quantization method is invalid")
    if compression["ratio_numerator"] != len(source) or compression[
        "ratio_denominator"
    ] != len(candidate):
        raise ScaleError("compression ratio must be derived from bound artifact bytes")
    training = _exact(
        scale["training_scale"],
        {"tokens_per_parameter", "verified_training_tokens"},
        "training scale",
    )
    if (
        training["verified_training_tokens"]
        != lineage["total_independently_verified_tokens"]
    ):
        raise ScaleError("training token count disagrees with lineage")
    expected_ratio = (
        None
        if native["total_parameters"] == 0
        else {
            "denominator": native["total_parameters"],
            "numerator": training["verified_training_tokens"],
        }
    )
    if training["tokens_per_parameter"] != expected_ratio:
        raise ScaleError("tokens-per-parameter ratio is invalid")
    measurement = _exact(
        scale["inference_measurement"],
        {"peak_ram_bytes", "peak_vram_bytes", "samples_per_second", "status"},
        "inference measurement",
    )
    measured = [
        measurement[name]
        for name in ("peak_ram_bytes", "peak_vram_bytes", "samples_per_second")
    ]
    if measurement["status"] == "NOT_MEASURED":
        if any(value is not None for value in measured):
            raise ScaleError("unmeasured resource fields must be null")
    elif measurement["status"] == "MEASURED":
        if any(type(value) is not int or value < 0 for value in measured):
            raise ScaleError("measured resource fields are invalid")
    else:
        raise ScaleError("inference measurement status is invalid")
    return scale


_SAFE_DTYPES = {
    "BOOL": 1,
    "U8": 1,
    "I8": 1,
    "F8_E4M3": 1,
    "F8_E5M2": 1,
    "I16": 2,
    "U16": 2,
    "F16": 2,
    "BF16": 2,
    "I32": 4,
    "U32": 4,
    "F32": 4,
    "I64": 8,
    "U64": 8,
    "F64": 8,
}


def _regular(path: Path) -> tuple[int, os.stat_result]:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    metadata = os.fstat(descriptor)
    if (
        not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or metadata.st_size < 1
    ):
        os.close(descriptor)
        raise ScaleError("checkpoint member is not one nonempty regular file")
    return descriptor, metadata


def _hash_range(descriptor: int, offset: int, length: int) -> str:
    digest = hashlib.sha256()
    observed = 0
    while observed < length:
        chunk = os.pread(
            descriptor, min(8 * 1024 * 1024, length - observed), offset + observed
        )
        if not chunk:
            raise ScaleError("checkpoint tensor data is truncated")
        digest.update(chunk)
        observed += len(chunk)
    return "sha256:" + digest.hexdigest()


def _safetensors_file(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    descriptor, metadata = _regular(path)
    try:
        prefix = os.pread(descriptor, 8, 0)
        if len(prefix) != 8:
            raise ScaleError("Safetensors header is truncated")
        header_size = struct.unpack("<Q", prefix)[0]
        if (
            not 2 <= header_size <= 100 * 1024 * 1024
            or 8 + header_size > metadata.st_size
        ):
            raise ScaleError("Safetensors header size is invalid")
        header_raw = os.pread(descriptor, header_size, 8)
        if len(header_raw) != header_size:
            raise ScaleError("Safetensors header is truncated")

        def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
            result: dict[str, Any] = {}
            for key, value in items:
                if key in result:
                    raise ScaleError("duplicate Safetensors header key")
                result[key] = value
            return result

        header = json.loads(
            header_raw.decode("utf-8", "strict"), object_pairs_hook=pairs
        )
        if type(header) is not dict:
            raise ScaleError("Safetensors header root is invalid")
        tensors = []
        spans = []
        for name, record in header.items():
            if name == "__metadata__":
                if type(record) is not dict:
                    raise ScaleError("Safetensors metadata is invalid")
                continue
            if (
                type(name) is not str
                or not name
                or type(record) is not dict
                or set(record) != {"data_offsets", "dtype", "shape"}
            ):
                raise ScaleError("Safetensors tensor record is invalid")
            dtype, shape, offsets = (
                record["dtype"],
                record["shape"],
                record["data_offsets"],
            )
            if (
                dtype not in _SAFE_DTYPES
                or type(shape) is not list
                or any(type(item) is not int or item < 0 for item in shape)
            ):
                raise ScaleError("Safetensors dtype or shape is invalid")
            if (
                type(offsets) is not list
                or len(offsets) != 2
                or any(type(item) is not int for item in offsets)
                or not 0 <= offsets[0] <= offsets[1]
            ):
                raise ScaleError("Safetensors offsets are invalid")
            elements = math.prod(shape)
            size = offsets[1] - offsets[0]
            if elements > 2**63 - 1 or size != elements * _SAFE_DTYPES[dtype]:
                raise ScaleError("Safetensors shape and byte extent disagree")
            absolute = 8 + header_size + offsets[0]
            spans.append((offsets[0], offsets[1]))
            tensors.append(
                {
                    "dtype": dtype,
                    "elements": elements,
                    "is_parameter": True,
                    "name": name,
                    "shape": shape,
                    "value_bytes": size,
                    "value_sha256": _hash_range(descriptor, absolute, size),
                }
            )
        ordered = sorted(spans)
        if (
            not tensors
            or ordered[0][0] != 0
            or any(first[1] != second[0] for first, second in pairwise(ordered))
            or 8 + header_size + ordered[-1][1] != metadata.st_size
        ):
            raise ScaleError(
                "Safetensors data contains gaps, overlaps, or trailing bytes"
            )
        file_digest = _hash_range(descriptor, 0, metadata.st_size)
        return tensors, {
            "bytes": metadata.st_size,
            "path": path.name,
            "sha256": file_digest,
        }
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ScaleError("Safetensors header JSON is invalid") from exc
    finally:
        os.close(descriptor)


def _strict_index(path: Path) -> tuple[dict[str, str], dict[str, Any]]:
    descriptor, metadata = _regular(path)
    try:
        if metadata.st_size > 64 * 1024 * 1024:
            raise ScaleError("checkpoint index exceeds its byte limit")
        raw = os.read(descriptor, metadata.st_size)
    finally:
        os.close(descriptor)
    try:

        def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
            result: dict[str, Any] = {}
            for key, item in items:
                if key in result:
                    raise ScaleError("duplicate checkpoint index key")
                result[key] = item
            return result

        value = json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs)
    except ScaleError:
        raise
    except Exception as exc:
        raise ScaleError("checkpoint index JSON is invalid") from exc
    if type(value) is not dict or type(value.get("weight_map")) is not dict:
        raise ScaleError("checkpoint index weight map is missing")
    weight_map = value["weight_map"]
    if (
        not weight_map
        or len(weight_map) > 1_000_000
        or any(
            type(key) is not str or not key or type(item) is not str or not item
            for key, item in weight_map.items()
        )
    ):
        raise ScaleError("checkpoint index weight map is invalid")
    return weight_map, {
        "bytes": metadata.st_size,
        "path": path.name,
        "sha256": _sha256(raw),
    }


def inspect_checkpoint_tree(root: Path, *, checkpoint_format: str) -> dict[str, Any]:
    """Stream and inventory a model-only Safetensors or safe PyTorch tree."""

    if root.is_symlink():
        raise ScaleError("checkpoint root cannot be a symbolic link")
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ScaleError("checkpoint root is not a directory")
    if checkpoint_format == "safetensors":
        index_files = sorted(root.glob("*.safetensors.index.json"))
        if len(index_files) > 1:
            raise ScaleError("multiple Safetensors indexes are ambiguous")
        index = _strict_index(index_files[0]) if index_files else None
        weight_map = index[0] if index else None
        shard_names = (
            sorted(set(weight_map.values()))
            if weight_map
            else [path.name for path in sorted(root.glob("*.safetensors"))]
        )
        if not shard_names or len(shard_names) > 10_000:
            raise ScaleError("Safetensors shard set is empty or oversized")
        tensors: list[dict[str, Any]] = []
        files = [index[1]] if index else []
        for shard in shard_names:
            if Path(shard).name != shard or not shard.endswith(".safetensors"):
                raise ScaleError("Safetensors shard path is unsafe")
            shard_tensors, record = _safetensors_file(root / shard)
            for tensor in shard_tensors:
                tensor["shard"] = shard
            tensors.extend(shard_tensors)
            files.append(record)
        names = [record["name"] for record in tensors]
        if len(set(names)) != len(names):
            raise ScaleError("checkpoint contains duplicate tensor names")
        if weight_map is not None and (
            set(weight_map) != set(names)
            or any(weight_map[record["name"]] != record["shard"] for record in tensors)
        ):
            raise ScaleError(
                "Safetensors index is missing, duplicating, or misrouting tensors"
            )
    elif checkpoint_format == "pytorch":
        try:
            import torch
        except ImportError as exc:
            raise ScaleError(
                "safe PyTorch inspection requires torch with weights_only support"
            ) from exc
        index_files = sorted(root.glob("*.bin.index.json"))
        if len(index_files) > 1:
            raise ScaleError("multiple PyTorch indexes are ambiguous")
        index = _strict_index(index_files[0]) if index_files else None
        weight_map = index[0] if index else None
        if weight_map:
            shard_names = sorted(set(weight_map.values()))
            if any(
                Path(name).name != name or not name.endswith(".bin")
                for name in shard_names
            ):
                raise ScaleError("PyTorch shard path is unsafe")
            paths = [root / name for name in shard_names]
        else:
            paths = (
                sorted(root.glob("*.pt"))
                + sorted(root.glob("*.pth"))
                + sorted(root.glob("*.bin"))
            )
        if not paths or len(paths) > 10_000:
            raise ScaleError("PyTorch checkpoint set is empty or oversized")
        tensors, files = [], ([index[1]] if index else [])
        for path in paths:
            descriptor, metadata = _regular(path)
            os.close(descriptor)
            try:
                state = torch.load(
                    path, map_location="cpu", mmap=True, weights_only=True
                )
            except Exception as exc:
                raise ScaleError("safe PyTorch weights-only decoding failed") from exc
            if type(state) is not dict or not state:
                raise ScaleError("PyTorch checkpoint is not a plain state dictionary")
            for name, tensor in state.items():
                if (
                    type(name) is not str
                    or not name
                    or not isinstance(tensor, torch.Tensor)
                    or tensor.layout != torch.strided
                ):
                    raise ScaleError(
                        "PyTorch state dictionary contains a non-tensor entry"
                    )
                value = tensor.detach().cpu().contiguous()
                raw_view = memoryview(value.view(torch.uint8).numpy()).cast("B")
                tensors.append(
                    {
                        "dtype": str(value.dtype).removeprefix("torch."),
                        "elements": value.numel(),
                        "is_parameter": True,
                        "name": name,
                        "shape": list(value.shape),
                        "shard": path.name,
                        "value_bytes": raw_view.nbytes,
                        "value_sha256": "sha256:"
                        + hashlib.sha256(raw_view).hexdigest(),
                    }
                )
            descriptor, metadata = _regular(path)
            try:
                files.append(
                    {
                        "bytes": metadata.st_size,
                        "path": path.name,
                        "sha256": _hash_range(descriptor, 0, metadata.st_size),
                    }
                )
            finally:
                os.close(descriptor)
        names = [record["name"] for record in tensors]
        if len(set(names)) != len(names):
            raise ScaleError("PyTorch shards contain duplicate tensor names")
        if weight_map is not None and (
            set(weight_map) != set(names)
            or any(weight_map[record["name"]] != record["shard"] for record in tensors)
        ):
            raise ScaleError(
                "PyTorch index is missing, duplicating, or misrouting tensors"
            )
    else:
        raise ScaleError("unsupported checkpoint tree format")
    tensors.sort(key=lambda item: item["name"])
    files.sort(key=lambda item: item["path"])
    return {
        "artifact_files": files,
        "checkpoint_format": checkpoint_format,
        "parameter_count": sum(record["elements"] for record in tensors),
        "parameter_value_bytes": sum(record["value_bytes"] for record in tensors),
        "scale_decision": SCALE_DECISION,
        "schema": "mfenx/model-scale-tree/v1",
        "tensor_count": len(tensors),
        "tensors": tensors,
    }
