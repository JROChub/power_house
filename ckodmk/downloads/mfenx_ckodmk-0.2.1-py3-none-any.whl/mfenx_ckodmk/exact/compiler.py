"""Untrusted candidate generator for CKODMK's restricted exact fixture.

The compiler never grants semantic authority. A bundle is publishable only after
the separately implemented Rust checker independently reconstructs and accepts
the canonical normal form.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Any

from .model import (
    CANONICAL_PROFILE,
    CERTIFICATE_SCHEMA,
    MAX_CERTIFICATE_BYTES,
    MAX_COEFFICIENT_BITS,
    MAX_INTERMEDIATE_BITS,
    MAX_JSON_BYTES,
    NORMALIZER,
    SEMANTICS,
    ResourceLimitError,
    affine_bounds,
    canonical_bytes,
    checked_add,
    checked_divide,
    checked_multiply,
    digest,
    encode_rational,
    model_metrics,
    parse_domain,
    serialize_domain,
    serialize_model,
    validate_model,
)

SPECIFICATION = "ckodmk-exact-spec/v2"


def _checked_product(left: Fraction, right: Fraction, label: str) -> Fraction:
    return checked_multiply(
        left,
        right,
        limit=MAX_INTERMEDIATE_BITS,
        label=label,
    )


def _canonical_ray(
    neuron: dict[str, Any],
) -> tuple[tuple[Fraction, ...], Fraction] | None:
    vector = neuron["weight"] + [neuron["bias"]]
    pivot = next((value for value in vector if value), None)
    if pivot is None:
        return None
    scale = abs(pivot)
    ray = tuple(
        checked_divide(
            value,
            scale,
            limit=MAX_COEFFICIENT_BITS,
            label="normalized ray coefficient",
        )
        for value in vector
    )
    return ray, scale


def _ray_sort_key(ray: tuple[Fraction, ...]) -> bytes:
    return canonical_bytes([encode_rational(value) for value in ray])


def _trace_bound(lower: Fraction, upper: Fraction) -> dict[str, Any]:
    return {"lower": encode_rational(lower), "upper": encode_rational(upper)}


def compile_exact(
    source_raw: dict[str, Any], domain_raw: Any = None
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Create a deterministic candidate normal form and deductive trace.

    This function fails closed on coefficient growth. It does not publish files
    and its result has no authority until accepted by the Rust checker.
    """

    source = validate_model(source_raw)
    source_serialized = serialize_model(source)
    if len(canonical_bytes(source_serialized)) + 1 > MAX_JSON_BYTES:
        raise ResourceLimitError("source exceeds persisted JSON size limit")
    requested_domain = parse_domain(domain_raw, source["input_size"])
    input_size = source["input_size"]
    output_size = len(source["bias"])
    input_weight = [row[:] for row in source["input_weight"]]
    output_bias = source["bias"][:]
    eliminations: list[dict[str, Any]] = []
    survivors: list[int] = []
    domain_used = False

    for source_index, neuron in enumerate(source["hidden"]):
        outgoing = [
            source["output_weight"][k][source_index] for k in range(output_size)
        ]

        # Dead output columns are removed first, independent of neuron shape.
        if all(value == 0 for value in outgoing):
            eliminations.append({"source": source_index, "kind": "zero-outgoing"})
            continue

        # Constant ReLUs have a global exact reduction.
        if all(value == 0 for value in neuron["weight"]):
            if neuron["bias"] <= 0:
                eliminations.append(
                    {
                        "source": source_index,
                        "kind": "constant-inactive",
                        "value": encode_rational(neuron["bias"]),
                    }
                )
                continue
            for output_index, outgoing_value in enumerate(outgoing):
                contribution = _checked_product(
                    outgoing_value,
                    neuron["bias"],
                    f"constant neuron {source_index}",
                )
                output_bias[output_index] = checked_add(
                    output_bias[output_index],
                    contribution,
                    limit=MAX_COEFFICIENT_BITS,
                    label=f"output bias {output_index}",
                )
            eliminations.append(
                {
                    "source": source_index,
                    "kind": "constant-active",
                    "value": encode_rational(neuron["bias"]),
                }
            )
            continue

        if requested_domain is not None:
            lower, upper = affine_bounds(
                neuron["weight"], neuron["bias"], requested_domain
            )
            if upper <= 0:
                eliminations.append(
                    {
                        "source": source_index,
                        "kind": "box-inactive",
                        "bound": _trace_bound(lower, upper),
                    }
                )
                domain_used = True
                continue
            if lower >= 0:
                for output_index, outgoing_value in enumerate(outgoing):
                    bias_contribution = _checked_product(
                        outgoing_value,
                        neuron["bias"],
                        f"box-active neuron {source_index} bias",
                    )
                    output_bias[output_index] = checked_add(
                        output_bias[output_index],
                        bias_contribution,
                        limit=MAX_COEFFICIENT_BITS,
                        label=f"output bias {output_index}",
                    )
                    for input_index, neuron_weight in enumerate(neuron["weight"]):
                        contribution = _checked_product(
                            outgoing_value,
                            neuron_weight,
                            f"box-active neuron {source_index} weight",
                        )
                        input_weight[output_index][input_index] = checked_add(
                            input_weight[output_index][input_index],
                            contribution,
                            limit=MAX_COEFFICIENT_BITS,
                            label=f"input affine weight [{output_index}][{input_index}]",
                        )
                eliminations.append(
                    {
                        "source": source_index,
                        "kind": "box-active",
                        "bound": _trace_bound(lower, upper),
                    }
                )
                domain_used = True
                continue
        survivors.append(source_index)

    grouped: dict[tuple[Fraction, ...], list[tuple[int, Fraction]]] = {}
    for source_index in survivors:
        result = _canonical_ray(source["hidden"][source_index])
        if result is None:  # Constant neurons were handled above.
            raise AssertionError("zero affine neuron reached ray normalization")
        ray, scale = result
        grouped.setdefault(ray, []).append((source_index, scale))

    target_hidden: list[dict[str, Any]] = []
    target_columns: list[list[Fraction]] = []
    trace_groups: list[dict[str, Any]] = []

    for ray in sorted(grouped, key=_ray_sort_key):
        members = sorted(grouped[ray], key=lambda item: item[0])
        column = [Fraction() for _ in range(output_size)]
        for source_index, scale in members:
            for output_index in range(output_size):
                contribution = _checked_product(
                    scale,
                    source["output_weight"][output_index][source_index],
                    f"ray member {source_index}",
                )
                column[output_index] = checked_add(
                    column[output_index],
                    contribution,
                    limit=MAX_COEFFICIENT_BITS,
                    label=f"aggregated ray output {output_index}",
                )

        trace = {
            "ray": [encode_rational(value) for value in ray],
            "members": [
                {"source": source_index, "scale": encode_rational(scale)}
                for source_index, scale in members
            ],
        }
        if all(value == 0 for value in column):
            trace["outcome"] = {"kind": "cancelled"}
            trace_groups.append(trace)
            continue

        target_index = len(target_hidden)
        trace["outcome"] = {"kind": "target", "index": target_index}
        target_hidden.append(
            {
                "weight": list(ray[:-1]),
                "bias": ray[-1],
            }
        )
        target_columns.append(column)
        trace_groups.append(trace)

    target_internal = {
        "input_size": input_size,
        "hidden": target_hidden,
        "output_weight": [
            [
                target_columns[column_index][output_index]
                for column_index in range(len(target_columns))
            ]
            for output_index in range(output_size)
        ],
        "input_weight": input_weight,
        "bias": output_bias,
    }
    target_serialized = serialize_model(target_internal)

    if len(canonical_bytes(target_serialized)) + 1 > MAX_JSON_BYTES:
        raise ResourceLimitError("target exceeds persisted JSON size limit")

    # Mandatory postcondition: a candidate outside the persisted v2 profile is
    # never returned, let alone published.
    target_validated = validate_model(target_serialized)
    scope_domain = requested_domain if domain_used else None
    statement = {
        "predicate": "exact-output-vector-equality",
        "semantics": SEMANTICS,
        "scope": (
            {"kind": "global"}
            if scope_domain is None
            else {
                "kind": "closed-rational-box",
                "bounds": serialize_domain(scope_domain),
            }
        ),
    }
    certificate = {
        "schema": CERTIFICATE_SCHEMA,
        "canonical_profile": CANONICAL_PROFILE,
        "specification": SPECIFICATION,
        "source_digest": digest(source_serialized, "ckodmk-source-v2"),
        "target_digest": digest(target_serialized, "ckodmk-target-v2"),
        "statement": statement,
        "evidence": {
            "kind": "deductive-normalization",
            "system": NORMALIZER,
            "eliminations": sorted(eliminations, key=lambda item: item["source"]),
            "groups": trace_groups,
        },
    }
    if len(canonical_bytes(certificate)) + 1 > MAX_CERTIFICATE_BYTES:
        raise ResourceLimitError("certificate exceeds persisted size limit")

    # These calls make the intended measurement explicit without putting mutable
    # performance claims inside proof evidence. The authoritative checker report
    # recomputes them independently.
    model_metrics(source)
    model_metrics(target_validated)
    return target_serialized, certificate
