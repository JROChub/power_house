"""Strict Proof-Carrying Model packaging and cryptographic verification."""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import stat
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


PCM_SCHEMA = "mfenx/ckodmk-pcm/v1"
STATEMENT_SCHEMA = "mfenx/ckodmk-pcm-statement/v1"
SIGNATURE_ALGORITHM = "ecdsa-p256-sha256-p1363"
EVIDENCE_TYPE = "finite-replay/v1"
MAX_PCM_BYTES = 300 * 1024 * 1024
MAX_MODEL_BYTES = 64 * 1024 * 1024
MAX_DATASET_BYTES = 64 * 1024 * 1024
MAX_CONTRACT_BYTES = 1024 * 1024
MAX_KEY_BYTES = 64 * 1024
_SHA256 = re.compile(r"sha256:[0-9a-f]{64}\Z")
_ROOT_ID = re.compile(r"sha256:[0-9a-f]{64}\Z")
_SERIAL = re.compile(r"[a-z0-9][a-z0-9._-]{0,127}\Z")
_ARTIFACT_FILENAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_ARTIFACT_NAMES = ("candidate", "contract", "dataset", "source")
_ARTIFACT_LIMITS = {
    "candidate": MAX_MODEL_BYTES,
    "contract": MAX_CONTRACT_BYTES,
    "dataset": MAX_DATASET_BYTES,
    "source": MAX_MODEL_BYTES,
}
_MEDIA_TYPES = {
    "candidate": "application/onnx",
    "contract": "application/json",
    "dataset": "application/x-npz",
    "source": "application/onnx",
}
_P256_ORDER = int(
    "ffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551", 16
)


class PCMError(ValueError):
    """A PCM is malformed, untrusted, expired, or cryptographically invalid."""


def _duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PCMError(f"duplicate PCM key: {key!r}")
        result[key] = value
    return result


def _reject_float(_: str) -> Any:
    raise PCMError("PCM JSON floating-point values are forbidden")


def _parse_json(raw: bytes) -> dict[str, Any]:
    if not 0 < len(raw) <= MAX_PCM_BYTES:
        raise PCMError("PCM file exceeds its byte limit or is empty")
    try:
        value = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_duplicates,
            parse_float=_reject_float,
            parse_constant=_reject_float,
        )
    except PCMError:
        raise
    except (UnicodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
        raise PCMError(f"invalid PCM JSON: {exc}") from exc
    if type(value) is not dict:
        raise PCMError("PCM root must be an object")
    return value


def canonical_bytes(value: Any) -> bytes:
    """Encode the ASCII-only signed vocabulary deterministically."""

    def inspect(item: Any, depth: int = 0) -> None:
        if depth > 32:
            raise PCMError("PCM nesting exceeds limit")
        if item is None or type(item) in {bool, int}:
            return
        if type(item) is str:
            if not item.isascii():
                raise PCMError("signed PCM strings must be ASCII")
            return
        if type(item) is list:
            if len(item) > 64:
                raise PCMError("signed PCM array exceeds item limit")
            for child in item:
                inspect(child, depth + 1)
            return
        if type(item) is dict:
            if len(item) > 64:
                raise PCMError("signed PCM object exceeds member limit")
            for key, child in item.items():
                if type(key) is not str or not key.isascii():
                    raise PCMError("signed PCM keys must be ASCII")
                inspect(child, depth + 1)
            return
        raise PCMError(f"unsupported signed PCM value: {type(item).__name__}")

    inspect(value)
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("ascii")


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _domain_hash(domain: bytes, value: Any) -> str:
    return "sha256:" + hashlib.sha256(domain + canonical_bytes(value)).hexdigest()


def _rootprint(statement: dict[str, Any]) -> dict[str, Any]:
    """Create the Power House v1 root branch that carries this PCM statement."""

    artifact = {
        "embedded_proof": {
            "proof": {"evidence_types": [EVIDENCE_TYPE]},
            "protocol": "mfenx/ckodmk-pcm-statement/v1",
            "public_inputs": {
                "statement_sha256": _sha256(canonical_bytes(statement))
            },
        },
        "phx_fingerprint": "",
        "provenance": {
            "producer": "mfenx-ckodmk",
            "serial": statement["serial"],
        },
        "schema": "power-house/pha/v1",
    }
    projection = {
        "embedded_proof": artifact["embedded_proof"],
        "provenance": artifact["provenance"],
        "schema": artifact["schema"],
    }
    artifact["phx_fingerprint"] = _domain_hash(
        b"power-house:pha:v1:phx-fingerprint\0", projection
    )
    label = "pcm-statement"
    branch_id = _domain_hash(
        b"power-house:rootprint:v1:branch-id\0",
        {
            "artifact_phx_fingerprint": artifact["phx_fingerprint"],
            "label": label,
            "parents": [],
        },
    )
    return {
        "branches": {
            branch_id: {
                "artifact": artifact,
                "id": branch_id,
                "label": label,
                "parents": [],
                "sequence": 0,
            }
        },
        "root_branch": branch_id,
        "schema": "power-house/rootprint/v1",
    }


def _b64(payload: bytes) -> str:
    return base64.b64encode(payload).decode("ascii")


def _decode_b64(value: Any, label: str, maximum: int) -> bytes:
    if type(value) is not str or not value.isascii() or len(value) > (maximum * 4 // 3 + 8):
        raise PCMError(f"{label} is not bounded canonical base64")
    try:
        payload = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise PCMError(f"{label} is invalid base64") from exc
    if not payload or len(payload) > maximum or _b64(payload) != value:
        raise PCMError(f"{label} is not bounded canonical base64")
    return payload


def _timestamp(text: Any, label: str) -> datetime:
    if type(text) is not str or not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z", text
    ):
        raise PCMError(f"{label} must be a canonical UTC timestamp")
    try:
        result = datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    except ValueError as exc:
        raise PCMError(f"{label} is not a valid UTC timestamp") from exc
    return result


def _crypto() -> tuple[Any, Any, Any, Any, Any]:
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives.asymmetric.utils import (
            decode_dss_signature,
            encode_dss_signature,
        )
    except ImportError as exc:
        raise PCMError(
            "PCM cryptography is unavailable; install mfenx-ckodmk[pcm]"
        ) from exc
    return hashes, serialization, ec, decode_dss_signature, encode_dss_signature


def generate_key_pair() -> tuple[bytes, bytes, str]:
    """Create one ECDSA P-256 private/public key pair in standard encodings."""

    _, serialization, ec, _, _ = _crypto()
    private_key = ec.generate_private_key(ec.SECP256R1())
    private_pem = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_der = private_key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_der, _sha256(public_der)


def _load_private_key(raw: bytes) -> Any:
    _, serialization, ec, _, _ = _crypto()
    if not 0 < len(raw) <= MAX_KEY_BYTES:
        raise PCMError("private key is empty or exceeds its byte limit")
    try:
        key = serialization.load_pem_private_key(raw, password=None)
    except (TypeError, ValueError) as exc:
        raise PCMError("private key must be unencrypted PKCS8 PEM") from exc
    if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(
        key.curve, ec.SECP256R1
    ):
        raise PCMError("private key must use ECDSA P-256")
    return key


def _load_public_key(raw: bytes) -> Any:
    _, serialization, ec, _, _ = _crypto()
    if not 0 < len(raw) <= MAX_KEY_BYTES:
        raise PCMError("trusted public key is empty or exceeds its byte limit")
    try:
        key = serialization.load_der_public_key(raw)
    except (TypeError, ValueError) as exc:
        raise PCMError("trusted public key must be SPKI DER") from exc
    if not isinstance(key, ec.EllipticCurvePublicKey) or not isinstance(
        key.curve, ec.SECP256R1
    ):
        raise PCMError("trusted public key must use ECDSA P-256")
    return key


def _protected(bundle: dict[str, Any]) -> dict[str, Any]:
    return {
        "issuer": bundle["issuer"],
        "rootprint": bundle["rootprint"],
        "schema": bundle["schema"],
        "statement": bundle["statement"],
        "statement_root_id": bundle["statement_root_id"],
    }


@dataclass(frozen=True)
class VerifiedPCM:
    statement_root_id: str
    candidate: bytes
    contract: bytes
    dataset: bytes
    source: bytes
    issuer_key_id: str
    serial: str
    expires_at: str


def issue_pcm(
    *,
    source: bytes,
    candidate: bytes,
    dataset: bytes,
    contract: bytes,
    names: dict[str, str],
    private_key_pem: bytes,
    issuer_name: str,
    serial: str,
    issued_at: str,
    expires_at: str,
    runtime_profile: str,
) -> bytes:
    """Create a signed, replayable PCM. Behavioral admission still requires replay."""

    if not _SERIAL.fullmatch(serial):
        raise PCMError("PCM serial is not canonical")
    if not issuer_name.isascii() or not 1 <= len(issuer_name) <= 128:
        raise PCMError("issuer name must be 1-128 ASCII characters")
    if not runtime_profile.isascii() or not 1 <= len(runtime_profile) <= 128:
        raise PCMError("runtime profile must be 1-128 ASCII characters")
    issued = _timestamp(issued_at, "issued_at")
    expires = _timestamp(expires_at, "expires_at")
    if expires <= issued:
        raise PCMError("expires_at must be after issued_at")
    payload_values = {
        "candidate": candidate,
        "contract": contract,
        "dataset": dataset,
        "source": source,
    }
    if not 0 < len(contract) <= MAX_CONTRACT_BYTES:
        raise PCMError("contract artifact is empty or exceeds its byte limit")
    contract_document = _parse_json(contract)
    if (
        set(contract_document)
        != {
            "candidate",
            "claims",
            "contract_id",
            "dataset",
            "output",
            "policy_profile",
            "schema",
            "source",
        }
        or contract_document.get("schema") != "mfenx/ckodmk-browser-contract/v1"
        or contract_document.get("policy_profile")
        != "ckodmk/browser-wasm-f32-batch1-classification/v1"
    ):
        raise PCMError("PCM issuance requires the strict browser contract profile")
    for artifact_name, contract_section in (
        ("source", "source"),
        ("candidate", "candidate"),
        ("dataset", "dataset"),
    ):
        record = contract_document.get(contract_section)
        if (
            type(record) is not dict
            or record.get("sha256") != _sha256(payload_values[artifact_name])
        ):
            raise PCMError(
                f"PCM {artifact_name} does not match the behavioral contract"
            )
    artifacts: dict[str, Any] = {}
    payloads: dict[str, str] = {}
    for name in _ARTIFACT_NAMES:
        payload = payload_values[name]
        if not 0 < len(payload) <= _ARTIFACT_LIMITS[name]:
            raise PCMError(f"{name} artifact is empty or exceeds its byte limit")
        filename = names.get(name)
        if (
            type(filename) is not str
            or not filename.isascii()
            or not _ARTIFACT_FILENAME.fullmatch(filename)
        ):
            raise PCMError(f"{name} filename is not canonical")
        artifacts[name] = {
            "bytes": len(payload),
            "media_type": _MEDIA_TYPES[name],
            "name": filename,
            "sha256": _sha256(payload),
        }
        payloads[name] = _b64(payload)

    private_key = _load_private_key(private_key_pem)
    _, serialization, ec, decode_dss_signature, _ = _crypto()
    public_der = private_key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    issuer = {
        "algorithm": SIGNATURE_ALGORITHM,
        "key_id": _sha256(public_der),
        "name": issuer_name,
        "public_key_spki_der_base64": _b64(public_der),
    }
    statement = {
        "admission": {
            "candidate_artifact": "candidate",
            "required_evidence": [EVIDENCE_TYPE],
        },
        "artifacts": artifacts,
        "evidence": [
            {
                "candidate_artifact": "candidate",
                "contract_artifact": "contract",
                "dataset_artifact": "dataset",
                "runtime_profile": runtime_profile,
                "source_artifact": "source",
                "type": EVIDENCE_TYPE,
            }
        ],
        "expires_at": expires_at,
        "issued_at": issued_at,
        "schema": STATEMENT_SCHEMA,
        "serial": serial,
    }
    rootprint = _rootprint(statement)
    bundle: dict[str, Any] = {
        "issuer": issuer,
        "payloads": payloads,
        "rootprint": rootprint,
        "schema": PCM_SCHEMA,
        "signature": {"algorithm": SIGNATURE_ALGORITHM, "value_base64": ""},
        "statement": statement,
        "statement_root_id": rootprint["root_branch"],
    }
    hashes, _, _, _, _ = _crypto()
    der_signature = private_key.sign(
        canonical_bytes(_protected(bundle)), ec.ECDSA(hashes.SHA256())
    )
    r, s = decode_dss_signature(der_signature)
    if s > _P256_ORDER // 2:
        s = _P256_ORDER - s
    bundle["signature"]["value_base64"] = _b64(
        r.to_bytes(32, "big") + s.to_bytes(32, "big")
    )
    return canonical_bytes(bundle) + b"\n"


def verify_pcm(
    raw: bytes,
    *,
    trusted_public_key_der: bytes,
    now: datetime | None = None,
) -> VerifiedPCM:
    """Verify structure, artifact bindings, RootID, trust pin, signature and time."""

    bundle = _parse_json(raw)
    if set(bundle) != {
        "issuer",
        "payloads",
        "rootprint",
        "schema",
        "signature",
        "statement",
        "statement_root_id",
    } or bundle["schema"] != PCM_SCHEMA:
        raise PCMError("unsupported PCM envelope")
    statement = bundle["statement"]
    if type(statement) is not dict or set(statement) != {
        "admission",
        "artifacts",
        "evidence",
        "expires_at",
        "issued_at",
        "schema",
        "serial",
    } or statement.get("schema") != STATEMENT_SCHEMA:
        raise PCMError("unsupported PCM statement")
    if not _SERIAL.fullmatch(statement.get("serial", "")):
        raise PCMError("PCM serial is invalid")
    expected_rootprint = _rootprint(statement)
    if (
        not _ROOT_ID.fullmatch(bundle["statement_root_id"])
        or bundle["rootprint"] != expected_rootprint
        or bundle["statement_root_id"] != expected_rootprint["root_branch"]
    ):
        raise PCMError("PCM Power House Rootprint binding mismatch")
    issued = _timestamp(statement["issued_at"], "issued_at")
    expires = _timestamp(statement["expires_at"], "expires_at")
    observed_now = now or datetime.now(UTC)
    if observed_now.tzinfo is None:
        raise PCMError("verification time must be timezone-aware")
    if issued > observed_now or expires <= observed_now or expires <= issued:
        raise PCMError("PCM is not currently valid")

    admission = statement["admission"]
    if admission != {
        "candidate_artifact": "candidate",
        "required_evidence": [EVIDENCE_TYPE],
    }:
        raise PCMError("unsupported PCM admission policy")
    evidence = statement["evidence"]
    expected_evidence = {
        "candidate_artifact": "candidate",
        "contract_artifact": "contract",
        "dataset_artifact": "dataset",
        "runtime_profile": "ckodmk/browser-wasm-f32-batch1-classification/v1",
        "source_artifact": "source",
        "type": EVIDENCE_TYPE,
    }
    if type(evidence) is not list or len(evidence) != 1 or evidence[0] != expected_evidence:
        raise PCMError("unsupported PCM evidence profile")

    issuer = bundle["issuer"]
    if type(issuer) is not dict or set(issuer) != {
        "algorithm",
        "key_id",
        "name",
        "public_key_spki_der_base64",
    } or issuer.get("algorithm") != SIGNATURE_ALGORITHM:
        raise PCMError("unsupported PCM issuer record")
    trusted_key = _load_public_key(trusted_public_key_der)
    _, serialization, ec, _, encode_dss_signature = _crypto()
    canonical_trusted = trusted_key.public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    embedded_key = _decode_b64(
        issuer["public_key_spki_der_base64"], "issuer public key", MAX_KEY_BYTES
    )
    if embedded_key != canonical_trusted or issuer.get("key_id") != _sha256(
        canonical_trusted
    ):
        raise PCMError("PCM issuer is not the trusted key")
    signature = bundle["signature"]
    if type(signature) is not dict or signature.get("algorithm") != SIGNATURE_ALGORITHM or set(signature) != {"algorithm", "value_base64"}:
        raise PCMError("unsupported PCM signature record")
    raw_signature = _decode_b64(signature["value_base64"], "signature", 64)
    if len(raw_signature) != 64:
        raise PCMError("PCM signature must be 64-byte P1363 form")
    r = int.from_bytes(raw_signature[:32], "big")
    s = int.from_bytes(raw_signature[32:], "big")
    if not 1 <= r < _P256_ORDER or not 1 <= s <= _P256_ORDER // 2:
        raise PCMError("PCM signature is not canonical low-S P-256 form")
    der_signature = encode_dss_signature(
        r,
        s,
    )
    hashes, _, _, _, _ = _crypto()
    try:
        trusted_key.verify(
            der_signature,
            canonical_bytes(_protected(bundle)),
            ec.ECDSA(hashes.SHA256()),
        )
    except Exception as exc:
        raise PCMError("PCM signature verification failed") from exc

    artifacts = statement["artifacts"]
    payloads = bundle["payloads"]
    if type(artifacts) is not dict or tuple(sorted(artifacts)) != _ARTIFACT_NAMES:
        raise PCMError("PCM artifact set is invalid")
    if type(payloads) is not dict or tuple(sorted(payloads)) != _ARTIFACT_NAMES:
        raise PCMError("PCM payload set is invalid")
    decoded: dict[str, bytes] = {}
    for name in _ARTIFACT_NAMES:
        record = artifacts[name]
        if type(record) is not dict or set(record) != {
            "bytes",
            "media_type",
            "name",
            "sha256",
        }:
            raise PCMError(f"{name} artifact record is invalid")
        payload = _decode_b64(payloads[name], f"{name} payload", _ARTIFACT_LIMITS[name])
        if (
            type(record["bytes"]) is not int
            or record["bytes"] != len(payload)
            or record["media_type"] != _MEDIA_TYPES[name]
            or type(record["name"]) is not str
            or not _ARTIFACT_FILENAME.fullmatch(record["name"])
            or not _SHA256.fullmatch(record["sha256"])
            or record["sha256"] != _sha256(payload)
        ):
            raise PCMError(f"{name} artifact binding failed")
        decoded[name] = payload
    return VerifiedPCM(
        statement_root_id=bundle["statement_root_id"],
        candidate=decoded["candidate"],
        contract=decoded["contract"],
        dataset=decoded["dataset"],
        source=decoded["source"],
        issuer_key_id=issuer["key_id"],
        serial=statement["serial"],
        expires_at=statement["expires_at"],
    )


def read_bounded(path: Path, maximum: int, label: str) -> bytes:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise PCMError(f"{label} cannot be opened without following links") from exc
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or not 0 < before.st_size <= maximum
        ):
            raise PCMError(f"{label} must be one bounded regular file")
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(descriptor, min(1024 * 1024, maximum + 1 - observed))
            if not chunk:
                break
            observed += len(chunk)
            if observed > maximum:
                raise PCMError(f"{label} grew beyond its byte limit")
            chunks.append(chunk)
        after = os.fstat(descriptor)
        identity = lambda item: (
            item.st_dev,
            item.st_ino,
            item.st_mode,
            item.st_nlink,
            item.st_uid,
            item.st_gid,
            item.st_size,
            item.st_mtime_ns,
            item.st_ctime_ns,
        )
        if observed != before.st_size or identity(after) != identity(before):
            raise PCMError(f"{label} changed while being read")
        return b"".join(chunks)
    finally:
        os.close(descriptor)
