"""Deterministic adapter for ONNXScript's built-in MatMul+Add to Gemm rule."""

from __future__ import annotations

import hashlib
import importlib.metadata
from collections import Counter
from typing import Any

import onnx
import onnxscript
from onnx import external_data_helper
from onnxscript import rewriter
from onnxscript.rewriter.rules.common import matmul_add_to_gemm_rule


MAX_MODEL_BYTES = 64 * 1024 * 1024
PINNED_VERSIONS = {
    "onnx": "1.22.0",
    "onnx-ir": "0.2.1",
    "onnxscript": "0.7.1",
}


class TransformError(RuntimeError):
    """Raised when the external transformation cannot produce a valid candidate."""


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _validate_versions() -> None:
    observed = {name: importlib.metadata.version(name) for name in PINNED_VERSIONS}
    if observed != PINNED_VERSIONS:
        raise TransformError(
            f"toolchain versions differ from the pinned profile: {observed!r}"
        )


def _parse(payload: bytes, label: str) -> onnx.ModelProto:
    if not 0 < len(payload) <= MAX_MODEL_BYTES:
        raise TransformError(f"{label} violates the model byte limit")
    try:
        model = onnx.load_model_from_string(payload)
        onnx.checker.check_model(model, full_check=True)
    except (ValueError, onnx.checker.ValidationError) as error:
        raise TransformError(f"{label} is not a valid ONNX model") from error
    for initializer in model.graph.initializer:
        if external_data_helper.uses_external_data(initializer):
            raise TransformError(f"{label} uses unbound external tensor data")
    return model


def _node_counts(model: onnx.ModelProto) -> dict[str, int]:
    return dict(sorted(Counter(node.op_type for node in model.graph.node).items()))


def _transform_once(source: onnx.ModelProto) -> onnx.ModelProto:
    optimized = onnxscript.optimizer.optimize(
        source,
        num_iterations=2,
        onnx_shape_inference=True,
        stop_if_no_change=True,
        input_size_limit=8192,
        output_size_limit=262144,
        inline=True,
    )
    candidate = rewriter.rewrite(optimized, [matmul_add_to_gemm_rule])
    try:
        onnx.checker.check_model(candidate, full_check=True)
    except onnx.checker.ValidationError as error:
        raise TransformError("ONNXScript emitted an invalid candidate") from error
    return candidate


def transform(source_payload: bytes) -> tuple[bytes, dict[str, Any]]:
    """Transform one source model and return deterministic bytes plus provenance."""

    _validate_versions()
    source = _parse(source_payload, "source model")
    source_counts = _node_counts(source)
    candidate = _transform_once(source)
    candidate_payload = candidate.SerializeToString(deterministic=True)
    parsed_candidate = _parse(candidate_payload, "candidate model")
    candidate_counts = _node_counts(parsed_candidate)
    fused = candidate_counts.get("Gemm", 0) - source_counts.get("Gemm", 0)
    if fused <= 0:
        raise TransformError("the pinned ONNXScript rule performed no Gemm fusion")
    if candidate_payload == source_payload:
        raise TransformError("the transformation did not change the model bytes")

    repeated = _transform_once(parsed_candidate).SerializeToString(deterministic=True)
    if repeated != candidate_payload:
        raise TransformError("the transformation is not a one-pass fixed point")
    if len(candidate_payload) > MAX_MODEL_BYTES:
        raise TransformError("candidate model violates the model byte limit")
    return candidate_payload, {
        "schema": "mfenx/ckodmk-onnxscript-transform/v1",
        "authority": "untrusted candidate producer",
        "toolchain": {
            "name": "ONNXScript",
            "versions": PINNED_VERSIONS,
            "optimizer": {
                "num_iterations": 2,
                "onnx_shape_inference": True,
                "stop_if_no_change": True,
                "input_size_limit": 8192,
                "output_size_limit": 262144,
                "inline": True,
            },
            "rewrite_rule": "onnxscript.rewriter.rules.common.matmul_add_to_gemm_rule",
        },
        "source": {
            "bytes": len(source_payload),
            "sha256": _digest(source_payload),
            "node_counts": source_counts,
        },
        "candidate": {
            "bytes": len(candidate_payload),
            "sha256": _digest(candidate_payload),
            "node_counts": candidate_counts,
        },
        "gemm_fusions": fused,
        "fixed_point_reapplication_identical": True,
    }
