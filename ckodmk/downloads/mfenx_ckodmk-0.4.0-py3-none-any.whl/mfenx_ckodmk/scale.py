"""Independent ONNX tensor inventory and model-scale-v1 verification."""

from __future__ import annotations

import hashlib
import math
from typing import Any


SCALE_SCHEMA = "mfenx/model-scale/v1"
SCALE_DECISION = "SCALE_RECORDED"


class ScaleError(ValueError):
    """A scale attestation is malformed or disagrees with its bound models."""


_PARAMETER_SLOTS = {
    "Conv": (1, 2),
    "Gemm": (1, 2),
    "MatMul": (1,),
    "QLinearConv": (3, 8),
    "QGemm": (3, 6),
}
_NONPARAMETER_SLOTS = {
    "DequantizeLinear": (1, 2),
    "QGemm": (1, 2, 4, 5, 7, 8),
    "QLinearConv": (1, 2, 4, 5, 6, 7),
    "QuantizeLinear": (1, 2),
    "ReduceSum": (1,),
    "Reshape": (1,),
    "Squeeze": (1,),
    "Unsqueeze": (1,),
}


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _exact(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if type(value) is not dict or set(value) != keys:
        raise ScaleError(f"{label} fields are unsupported")
    return value


def _onnx_manifest(payload: bytes) -> dict[str, Any]:
    if not 0 < len(payload) <= 64 * 1024 * 1024:
        raise ScaleError("scale model is empty or exceeds its byte limit")
    try:
        import numpy as np
        import onnx
        from onnx import numpy_helper
    except ImportError as exc:
        raise ScaleError("model-scale verification requires the production dependencies") from exc
    try:
        model = onnx.load_model_from_string(payload)
        onnx.checker.check_model(model, full_check=True)
    except Exception as exc:
        raise ScaleError("scale model is not a valid self-contained ONNX model") from exc
    initializers = list(model.graph.initializer)
    if len(initializers) > 10_000:
        raise ScaleError("model tensor count exceeds the supported profile")
    names = [tensor.name for tensor in initializers]
    if not initializers or any(not name for name in names) or len(set(names)) != len(names):
        raise ScaleError("model tensors are empty, unnamed, or duplicated")
    referenced = {name for node in model.graph.node for name in node.input if name}
    if any(name not in referenced for name in names):
        raise ScaleError("model contains an unexpected unreferenced tensor")
    parameter_names: set[str] = set()
    for node in model.graph.node:
        for index in _PARAMETER_SLOTS.get(node.op_type, ()):
            if index < len(node.input) and node.input[index] in names:
                parameter_names.add(node.input[index])
    classified = set(parameter_names)
    for node in model.graph.node:
        for index in _NONPARAMETER_SLOTS.get(node.op_type, ()):
            if index < len(node.input) and node.input[index] in names:
                classified.add(node.input[index])
    if classified != set(names):
        raise ScaleError("model contains a tensor whose parameter role is unsupported")
    records: list[dict[str, Any]] = []
    total = 0
    parameter_count = 0
    parameter_bytes = 0
    for tensor in sorted(initializers, key=lambda item: item.name):
        if tensor.data_location == onnx.TensorProto.EXTERNAL or tensor.external_data:
            raise ScaleError("external tensor data is unsupported")
        if any(dimension < 0 for dimension in tensor.dims) or math.prod(tensor.dims) > 16_000_000:
            raise ScaleError("tensor shape exceeds the supported profile")
        try:
            array = np.ascontiguousarray(numpy_helper.to_array(tensor))
        except Exception as exc:
            raise ScaleError(f"tensor {tensor.name!r} cannot be decoded") from exc
        elements = int(array.size)
        if elements < 1 or elements > 2**63 - 1:
            raise ScaleError("tensor element count is invalid")
        raw = array.tobytes(order="C")
        is_parameter = tensor.name in parameter_names
        total += elements
        if is_parameter:
            parameter_count += elements
            parameter_bytes += len(raw)
        records.append(
            {
                "dtype": str(array.dtype),
                "elements": elements,
                "is_parameter": is_parameter,
                "name": tensor.name,
                "shape": list(array.shape),
                "value_bytes": len(raw),
                "value_sha256": _sha256(raw),
            }
        )
    return {
        "all_initializer_elements": total,
        "parameter_count": parameter_count,
        "parameter_value_bytes": parameter_bytes,
        "tensors": records,
    }


def _onnx_architecture(payload: bytes) -> dict[str, int | None]:
    try:
        import onnx
    except ImportError as exc:
        raise ScaleError("model-scale verification requires the production dependencies") from exc
    model = onnx.load_model_from_string(payload)
    tensors = {tensor.name: tuple(int(item) for item in tensor.dims) for tensor in model.graph.initializer}
    parameterized = [node for node in model.graph.node if node.op_type in _PARAMETER_SLOTS]
    if not parameterized:
        raise ScaleError("model architecture has no supported parameterized layer")
    first = parameterized[0]
    weight_index = _PARAMETER_SLOTS[first.op_type][0]
    if weight_index >= len(first.input) or first.input[weight_index] not in tensors:
        raise ScaleError("model architecture weight binding is invalid")
    shape = tensors[first.input[weight_index]]
    if not shape:
        raise ScaleError("model architecture weight shape is empty")
    hidden_width = shape[0] if first.op_type in {"Conv", "QLinearConv"} else shape[-1]
    return {
        "attention_heads": None,
        "context_length": None,
        "hidden_width": hidden_width,
        "layers": len(parameterized),
        "vocabulary_size": None,
    }


def reconstruct_scale(source: bytes, candidate: bytes) -> tuple[dict[str, Any], dict[str, Any]]:
    """Reconstruct complete tensor inventories without trusting an attestation."""

    return _onnx_manifest(source), _onnx_manifest(candidate)


def validate_scale(
    document: Any,
    *,
    source: bytes,
    candidate: bytes,
    lineage: dict[str, Any],
    lineage_sha256: str,
) -> dict[str, Any]:
    """Verify scale claims from model bytes and preserve derivative identity."""

    scale = _exact(
        document,
        {
            "architecture_dimensions",
            "checkpoint_bytes",
            "compression",
            "deployment",
            "inference_measurement",
            "lineage_sha256",
            "native_model",
            "scale_decision",
            "schema",
            "training_scale",
        },
        "model scale",
    )
    if scale["schema"] != SCALE_SCHEMA or scale["scale_decision"] != SCALE_DECISION:
        raise ScaleError("unsupported model scale decision")
    if scale["lineage_sha256"] != lineage_sha256:
        raise ScaleError("model scale does not bind the lineage artifact")
    architecture = _exact(
        scale["architecture_dimensions"],
        {"attention_heads", "context_length", "hidden_width", "layers", "vocabulary_size"},
        "architecture dimensions",
    )
    for name, value in architecture.items():
        if value is not None and (type(value) is not int or value < 1):
            raise ScaleError(f"architecture dimension {name} is invalid")
    if architecture != _onnx_architecture(source):
        raise ScaleError("claimed architecture does not match checkpoint tensors")
    native = _exact(
        scale["native_model"],
        {"model_sha256", "native_precision", "tensor_manifest", "theoretical_weight_bytes", "total_parameters", "trainable_parameters"},
        "native model scale",
    )
    deployment = _exact(
        scale["deployment"],
        {"artifact_bytes", "deployment_precision", "model_sha256", "original_parameter_count", "tensor_manifest"},
        "deployment scale",
    )
    source_manifest, candidate_manifest = reconstruct_scale(source, candidate)
    if native["model_sha256"] != _sha256(source) or native["tensor_manifest"] != source_manifest:
        raise ScaleError("native tensor inventory or identity mismatch")
    if deployment["model_sha256"] != _sha256(candidate) or deployment["tensor_manifest"] != candidate_manifest:
        raise ScaleError("deployment tensor inventory or identity mismatch")
    if native["total_parameters"] != source_manifest["parameter_count"] or native["trainable_parameters"] != source_manifest["parameter_count"]:
        raise ScaleError("native parameter count was not reconstructed from tensor shapes")
    if native["theoretical_weight_bytes"] != source_manifest["parameter_value_bytes"]:
        raise ScaleError("native theoretical weight bytes are invalid")
    if deployment["artifact_bytes"] != len(candidate) or deployment["original_parameter_count"] != native["total_parameters"]:
        raise ScaleError("deployment conversion changed or obscured original parameter identity")
    if lineage["final_model_sha256"] != deployment["model_sha256"]:
        raise ScaleError("deployment scale and lineage candidate disagree")
    checkpoint = _exact(scale["checkpoint_bytes"], {"model", "optimizer", "optimizer_status"}, "checkpoint bytes")
    if checkpoint["model"] != len(source) or type(checkpoint["optimizer"]) is not int or checkpoint["optimizer"] < 0:
        raise ScaleError("checkpoint byte accounting is invalid")
    if checkpoint["optimizer_status"] not in {"NOT_RETAINED", "NOT_APPLICABLE"} or checkpoint["optimizer"] != 0:
        raise ScaleError("optimizer-state accounting is contradictory")
    compression = _exact(scale["compression"], {"method", "ratio_denominator", "ratio_numerator"}, "compression")
    if type(compression["method"]) is not str or not compression["method"].isascii() or not compression["method"]:
        raise ScaleError("quantization method is invalid")
    if compression["ratio_numerator"] != len(source) or compression["ratio_denominator"] != len(candidate):
        raise ScaleError("compression ratio must be derived from bound artifact bytes")
    training = _exact(scale["training_scale"], {"tokens_per_parameter", "verified_training_tokens"}, "training scale")
    if training["verified_training_tokens"] != lineage["total_independently_verified_tokens"]:
        raise ScaleError("training token count disagrees with lineage")
    expected_ratio = None if native["total_parameters"] == 0 else {
        "denominator": native["total_parameters"],
        "numerator": training["verified_training_tokens"],
    }
    if training["tokens_per_parameter"] != expected_ratio:
        raise ScaleError("tokens-per-parameter ratio is invalid")
    measurement = _exact(scale["inference_measurement"], {"peak_ram_bytes", "peak_vram_bytes", "samples_per_second", "status"}, "inference measurement")
    measured = [measurement[name] for name in ("peak_ram_bytes", "peak_vram_bytes", "samples_per_second")]
    if measurement["status"] == "NOT_MEASURED":
        if any(value is not None for value in measured):
            raise ScaleError("unmeasured resource fields must be null")
    elif measurement["status"] == "MEASURED":
        if any(type(value) is not int or value < 0 for value in measured):
            raise ScaleError("measured resource fields are invalid")
    else:
        raise ScaleError("inference measurement status is invalid")
    return scale
