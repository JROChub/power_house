"""Strict model lineage and release authorization profiles."""

from __future__ import annotations

import re
from typing import Any

LINEAGE_SCHEMA = "mfenx/model-lineage/v1"
AUTHORIZATION_SCHEMA = "mfenx/release-authorization/v1"
LINEAGE_CLASSES = frozenset(
    {
        "NATIVE_TRAINED",
        "DERIVATIVE_FINE_TUNE",
        "QUANTIZED_DERIVATIVE",
        "EXTERNAL_UNMODIFIED",
    }
)
LIFECYCLE_STATES = (
    "SUBMITTED",
    "RUNNING",
    "OUTPUT_PUBLISHED",
    "ARTIFACT_VERIFIED",
    "RELOAD_VERIFIED",
    "CAPABILITY_MEASURED",
    "RELEASE_ELIGIBLE",
)
NOT_AUTHORIZED = "NOT_AUTHORIZED_FOR_ACTIVATION"
_SHA256 = re.compile(r"sha256:[0-9a-f]{64}\Z")
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/+-]{0,255}\Z")


class ProvenanceError(ValueError):
    """A lineage or release authorization profile is invalid."""


def _exact(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if type(value) is not dict or set(value) != keys:
        raise ProvenanceError(f"{label} fields are unsupported")
    return value


def _text(value: Any, label: str, maximum: int = 256) -> str:
    if (
        type(value) is not str
        or not value.isascii()
        or not 1 <= len(value) <= maximum
        or not _IDENTIFIER.fullmatch(value)
    ):
        raise ProvenanceError(f"{label} is not a canonical identifier")
    return value


def _digest(value: Any, label: str) -> str:
    if type(value) is not str or not _SHA256.fullmatch(value):
        raise ProvenanceError(f"{label} is not a canonical SHA-256 digest")
    return value


def _origin(value: Any, label: str) -> dict[str, Any]:
    record = _exact(value, {"kind", "name", "reference", "sha256"}, label)
    _text(record["kind"], f"{label}.kind", 64)
    _text(record["name"], f"{label}.name")
    _text(record["reference"], f"{label}.reference")
    _digest(record["sha256"], f"{label}.sha256")
    return record


def validate_lineage(
    document: Any,
    *,
    model_sha256: str,
    evidence_digests: set[str],
    verified_result_digests: set[str],
) -> dict[str, Any]:
    """Validate model-lineage-v1 and its classification-specific invariants."""

    lineage = _exact(
        document,
        {
            "accelerator_evidence",
            "architecture_origin",
            "classification",
            "final_model_sha256",
            "initial_weight_origin",
            "model_id",
            "parent_checkpoint_sha256",
            "schema",
            "tokenizer_origin",
            "total_independently_verified_tokens",
            "trainer_identity",
            "training_data_commitments",
            "training_implementation_sha256",
            "training_receipts",
        },
        "model lineage",
    )
    if lineage["schema"] != LINEAGE_SCHEMA:
        raise ProvenanceError("unsupported model lineage schema")
    _text(lineage["model_id"], "model_id")
    classification = lineage["classification"]
    if classification not in LINEAGE_CLASSES:
        raise ProvenanceError("unsupported model lineage classification")
    if _digest(lineage["final_model_sha256"], "final_model_sha256") != model_sha256:
        raise ProvenanceError("lineage final model does not match the candidate")
    architecture = _origin(lineage["architecture_origin"], "architecture_origin")
    initial = _origin(lineage["initial_weight_origin"], "initial_weight_origin")
    tokenizer = _origin(lineage["tokenizer_origin"], "tokenizer_origin")
    if architecture["kind"] == "NOT_APPLICABLE":
        raise ProvenanceError("architecture origin cannot be not applicable")
    trainer = _exact(
        lineage["trainer_identity"], {"identity_key_id", "name"}, "trainer_identity"
    )
    _text(trainer["name"], "trainer_identity.name")
    _digest(trainer["identity_key_id"], "trainer_identity.identity_key_id")
    implementation = _digest(
        lineage["training_implementation_sha256"], "training_implementation_sha256"
    )
    parent = lineage["parent_checkpoint_sha256"]
    if parent is not None:
        _digest(parent, "parent_checkpoint_sha256")
    required = {architecture["sha256"], initial["sha256"], implementation}
    if parent is not None:
        required.add(parent)
    if tokenizer["kind"] != "NOT_APPLICABLE":
        required.add(tokenizer["sha256"])
    if not required <= evidence_digests:
        raise ProvenanceError("lineage digest does not resolve to a signed artifact")
    commitments = lineage["training_data_commitments"]
    if type(commitments) is not list or not 1 <= len(commitments) <= 64:
        raise ProvenanceError(
            "training_data_commitments must be a bounded nonempty list"
        )
    if len(set(commitments)) != len(commitments):
        raise ProvenanceError("training_data_commitments contains duplicates")
    for index, commitment in enumerate(commitments):
        digest = _digest(commitment, f"training_data_commitments[{index}]")
        if digest not in evidence_digests:
            raise ProvenanceError("training data commitment is not a signed artifact")
    receipts = lineage["training_receipts"]
    if type(receipts) is not list or not 1 <= len(receipts) <= 32:
        raise ProvenanceError("training_receipts must be a bounded nonempty list")
    for index, item in enumerate(receipts):
        receipt = _exact(
            item,
            {"evidence_sha256", "provider", "receipt_id", "status"},
            f"training_receipts[{index}]",
        )
        _text(receipt["provider"], f"training_receipts[{index}].provider")
        _text(receipt["receipt_id"], f"training_receipts[{index}].receipt_id")
        digest = _digest(
            receipt["evidence_sha256"], f"training_receipts[{index}].evidence_sha256"
        )
        if receipt["status"] != "VERIFIED":
            raise ProvenanceError("every training receipt must be VERIFIED")
        if digest not in verified_result_digests:
            raise ProvenanceError(
                "training receipt result was not independently verified"
            )
    accelerators = lineage["accelerator_evidence"]
    if type(accelerators) is not list or not 1 <= len(accelerators) <= 32:
        raise ProvenanceError("accelerator_evidence must be a bounded nonempty list")
    for index, item in enumerate(accelerators):
        evidence = _exact(
            item,
            {"accelerator_class", "evidence_sha256", "provider", "status"},
            f"accelerator_evidence[{index}]",
        )
        _text(evidence["provider"], f"accelerator_evidence[{index}].provider")
        _text(
            evidence["accelerator_class"],
            f"accelerator_evidence[{index}].accelerator_class",
        )
        digest = _digest(
            evidence["evidence_sha256"],
            f"accelerator_evidence[{index}].evidence_sha256",
        )
        if evidence["status"] != "VERIFIED":
            raise ProvenanceError("every accelerator record must be VERIFIED")
        if digest not in verified_result_digests:
            raise ProvenanceError("accelerator result was not independently verified")
    tokens = lineage["total_independently_verified_tokens"]
    if type(tokens) is not int or not 0 <= tokens <= 2**63 - 1:
        raise ProvenanceError("total_independently_verified_tokens is invalid")
    if classification == "NATIVE_TRAINED":
        if initial["kind"] != "RANDOM_INITIALIZATION":
            raise ProvenanceError(
                "native training must originate from random initialization"
            )
    elif classification in {"DERIVATIVE_FINE_TUNE", "QUANTIZED_DERIVATIVE"}:
        if parent is None or initial["kind"] != "PRETRAINED_MODEL":
            raise ProvenanceError(
                "derivative lineage requires a pretrained origin and parent checkpoint"
            )
    elif (
        parent is not None
        or initial["kind"] != "EXTERNAL_MODEL"
        or initial["sha256"] != model_sha256
    ):
        raise ProvenanceError(
            "external-unmodified lineage must bind the external model directly"
        )
    return lineage


def _result(value: Any, label: str) -> dict[str, Any]:
    result = _exact(value, {"decision", "evidence_sha256"}, label)
    if result["decision"] != "PASS":
        raise ProvenanceError(f"{label} must be PASS")
    _digest(result["evidence_sha256"], f"{label}.evidence_sha256")
    return result


def validate_authorization(
    document: Any,
    *,
    lineage: dict[str, Any],
    lineage_sha256: str,
    model_sha256: str,
    contract_sha256: str,
    evidence_digests: set[str],
    verified_result_digests: set[str],
    evidence_qualifications: dict[str, dict[str, int]],
) -> dict[str, Any]:
    """Validate release-authorization-v1 and claim-to-evidence authorization."""

    authorization = _exact(
        document,
        {
            "capability_result",
            "claims",
            "contract_sha256",
            "lifecycle",
            "lineage_sha256",
            "model_sha256",
            "qualification",
            "release_id",
            "reload_result",
            "runtime_replay_result",
            "schema",
        },
        "release authorization",
    )
    if authorization["schema"] != AUTHORIZATION_SCHEMA:
        raise ProvenanceError("unsupported release authorization schema")
    _text(authorization["release_id"], "release_id")
    if authorization["model_sha256"] != model_sha256:
        raise ProvenanceError("authorization model does not match the candidate")
    if authorization["lineage_sha256"] != lineage_sha256:
        raise ProvenanceError("authorization does not bind the lineage artifact")
    if authorization["contract_sha256"] != contract_sha256:
        raise ProvenanceError("authorization does not bind the behavioral contract")
    qualification = _exact(
        authorization["qualification"],
        {
            "capability_accuracy_ppm",
            "comparative_delta_ppm",
            "evaluation_samples",
            "profile",
            "reliability_success_ppm",
            "safety_critical_failures",
        },
        "release qualification",
    )
    profile = qualification["profile"]
    if profile not in {"DEMONSTRATION", "PRODUCTION"}:
        raise ProvenanceError("unsupported release qualification profile")
    for field in ("capability_accuracy_ppm", "reliability_success_ppm"):
        if (
            type(qualification[field]) is not int
            or not 0 <= qualification[field] <= 1_000_000
        ):
            raise ProvenanceError(f"{field} is invalid")
    if (
        type(qualification["comparative_delta_ppm"]) is not int
        or not -1_000_000 <= qualification["comparative_delta_ppm"] <= 1_000_000
    ):
        raise ProvenanceError("comparative_delta_ppm is invalid")
    if (
        type(qualification["evaluation_samples"]) is not int
        or qualification["evaluation_samples"] < 1
    ):
        raise ProvenanceError("evaluation_samples is invalid")
    if (
        type(qualification["safety_critical_failures"]) is not int
        or qualification["safety_critical_failures"] < 0
    ):
        raise ProvenanceError("safety_critical_failures is invalid")
    production_qualified = (
        qualification["evaluation_samples"] >= 1_000
        and qualification["capability_accuracy_ppm"] >= 950_000
        and qualification["safety_critical_failures"] == 0
        and qualification["reliability_success_ppm"] >= 999_000
        and qualification["comparative_delta_ppm"] >= -10_000
    )
    if profile == "PRODUCTION" and not production_qualified:
        raise ProvenanceError("production qualification thresholds were not met")
    lifecycle = authorization["lifecycle"]
    if type(lifecycle) is not list or len(lifecycle) != len(LIFECYCLE_STATES):
        raise ProvenanceError("training lifecycle is incomplete")
    lifecycle_evidence: dict[str, str] = {}
    for expected_state, item in zip(LIFECYCLE_STATES, lifecycle, strict=True):
        record = _exact(
            item,
            {"evidence_class", "evidence_sha256", "state", "status"},
            f"lifecycle.{expected_state}",
        )
        if record["state"] != expected_state or record["status"] != "VERIFIED":
            raise ProvenanceError(
                "training lifecycle order or verification status is invalid"
            )
        _text(record["evidence_class"], f"lifecycle.{expected_state}.evidence_class")
        lifecycle_evidence[expected_state] = _digest(
            record["evidence_sha256"], f"lifecycle.{expected_state}.evidence_sha256"
        )
        if lifecycle_evidence[expected_state] not in evidence_digests:
            raise ProvenanceError("lifecycle evidence is not a signed artifact")
    reload_result = _result(authorization["reload_result"], "reload_result")
    capability_result = _result(authorization["capability_result"], "capability_result")
    replay_result = _result(
        authorization["runtime_replay_result"], "runtime_replay_result"
    )
    for label, result in (
        ("reload", reload_result),
        ("capability", capability_result),
        ("runtime replay", replay_result),
    ):
        if result["evidence_sha256"] not in verified_result_digests:
            raise ProvenanceError(f"{label} result was not independently verified")
    derived = evidence_qualifications.get(capability_result["evidence_sha256"])
    required_metrics = {
        "capability_accuracy_ppm",
        "comparative_delta_ppm",
        "evaluation_samples",
    }
    if derived is None or any(
        qualification[name] != derived.get(name) for name in required_metrics
    ):
        raise ProvenanceError(
            "release qualification disagrees with independently verified evidence"
        )
    if profile == "PRODUCTION" and any(
        qualification[name] != derived.get(name)
        for name in ("reliability_success_ppm", "safety_critical_failures")
    ):
        raise ProvenanceError(
            "production qualification lacks verified reliability or safety evidence"
        )
    if lifecycle_evidence["RELOAD_VERIFIED"] != reload_result["evidence_sha256"]:
        raise ProvenanceError("reload lifecycle evidence is contradictory")
    if (
        lifecycle_evidence["CAPABILITY_MEASURED"]
        != capability_result["evidence_sha256"]
    ):
        raise ProvenanceError("capability lifecycle evidence is contradictory")
    if lifecycle_evidence["RELEASE_ELIGIBLE"] != replay_result["evidence_sha256"]:
        raise ProvenanceError("release eligibility evidence is contradictory")
    claims = authorization["claims"]
    if type(claims) is not list or not 1 <= len(claims) <= 32:
        raise ProvenanceError("claims must be a bounded nonempty list")
    seen: set[str] = set()
    for index, item in enumerate(claims):
        claim = _exact(
            item,
            {"claim", "evidence_class", "evidence_sha256", "subject"},
            f"claims[{index}]",
        )
        name = _text(claim["claim"], f"claims[{index}].claim", 64)
        _text(claim["subject"], f"claims[{index}].subject")
        evidence_class = _text(
            claim["evidence_class"], f"claims[{index}].evidence_class"
        )
        evidence_digest = _digest(
            claim["evidence_sha256"], f"claims[{index}].evidence_sha256"
        )
        if evidence_digest not in evidence_digests:
            raise ProvenanceError("claim evidence is not a signed artifact")
        if name in seen:
            raise ProvenanceError("duplicate public claim")
        seen.add(name)
        if name == "TRAINED_BY":
            if (
                lineage["classification"] != "NATIVE_TRAINED"
                or claim["subject"] != lineage["trainer_identity"]["name"]
                or evidence_class != "native-lineage"
                or evidence_digest != lineage_sha256
            ):
                raise ProvenanceError("TRAINED_BY lacks native lineage evidence")
        elif name == "TRAINING_COMPLETE":
            if (
                evidence_class != "verified-final-training-receipt"
                or evidence_digest != lifecycle_evidence["OUTPUT_PUBLISHED"]
            ):
                raise ProvenanceError(
                    "TRAINING_COMPLETE lacks a verified final receipt"
                )
        elif name == "FUNCTIONAL":
            if (
                evidence_class != "reload-and-inference"
                or evidence_digest != reload_result["evidence_sha256"]
            ):
                raise ProvenanceError("FUNCTIONAL lacks reload and inference evidence")
        elif name == "PRODUCTION_GRADE":
            if (
                profile != "PRODUCTION"
                or not production_qualified
                or evidence_class != "production-qualification"
                or evidence_digest != capability_result["evidence_sha256"]
            ):
                raise ProvenanceError(
                    "PRODUCTION_GRADE lacks production qualification evidence"
                )
        elif name == "OUTPERFORMS_REFERENCE":
            if (
                evidence_class != "controlled-comparative-evaluation"
                or evidence_digest != capability_result["evidence_sha256"]
            ):
                raise ProvenanceError(
                    "OUTPERFORMS_REFERENCE lacks comparative evidence"
                )
        else:
            raise ProvenanceError(f"unsupported public claim: {name}")
    result = dict(authorization)
    result["activation_decision"] = NOT_AUTHORIZED
    result["activation_prerequisite"] = "VERIFIED_RUNTIME_REPLAY_REQUIRED"
    return result
