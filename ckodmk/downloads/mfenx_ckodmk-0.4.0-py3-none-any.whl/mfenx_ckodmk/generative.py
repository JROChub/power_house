"""Strict finite generative replay-trace adjudication without claim escalation."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

PROFILE = "ckodmk/generative-greedy-trace/v1"
CONTRACT_SCHEMA = "mfenx/ckodmk-generative-contract/v1"
TRACE_SCHEMA = "mfenx/ckodmk-generative-trace/v1"
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")


class GenerativeReplayError(ValueError): pass


def _strict(raw: bytes, label: str, maximum: int = 64 * 1024 * 1024) -> Any:
    if not 0 < len(raw) <= maximum: raise GenerativeReplayError(f"{label} is empty or oversized")
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result: raise GenerativeReplayError(f"duplicate {label} key")
            result[key] = value
        return result
    def reject(_): raise GenerativeReplayError(f"{label} floats are forbidden")
    try: return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_float=reject, parse_constant=reject)
    except GenerativeReplayError: raise
    except Exception as exc: raise GenerativeReplayError(f"invalid {label}: {exc}") from exc


def _digest(value: Any, domain: bytes) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return "sha256:" + hashlib.sha256(domain + raw).hexdigest()


def adjudicate_generative_trace(contract_raw: bytes, trace_raw: bytes) -> dict[str, Any]:
    contract, trace = _strict(contract_raw, "contract", 1024 * 1024), _strict(trace_raw, "trace")
    contract_keys = {"candidate_artifact_sha256", "claims", "contract_id", "decoding", "policy_profile",
                     "prompt_suite_sha256", "schema", "source_artifact_sha256", "tokenizer_sha256"}
    if type(contract) is not dict or set(contract) != contract_keys or contract.get("schema") != CONTRACT_SCHEMA \
            or contract.get("policy_profile") != PROFILE:
        raise GenerativeReplayError("unsupported generative contract")
    for key in ("candidate_artifact_sha256", "prompt_suite_sha256", "source_artifact_sha256", "tokenizer_sha256"):
        if not _DIGEST.fullmatch(contract.get(key, "")): raise GenerativeReplayError(f"invalid {key}")
    decoding = contract["decoding"]
    if type(decoding) is not dict or set(decoding) != {"algorithm", "maximum_generated_tokens", "stop_token_ids",
                                                       "temperature_micros", "top_k", "top_p_micros"} \
            or decoding["algorithm"] != "greedy" or decoding["temperature_micros"] != 0 \
            or decoding["top_k"] != 1 or decoding["top_p_micros"] != 1_000_000 \
            or type(decoding["maximum_generated_tokens"]) is not int \
            or not 1 <= decoding["maximum_generated_tokens"] <= 4096 \
            or type(decoding["stop_token_ids"]) is not list \
            or any(type(value) is not int or value < 0 for value in decoding["stop_token_ids"]):
        raise GenerativeReplayError("unsupported or nondeterministic decoding contract")
    claims = contract["claims"]
    if type(claims) is not dict or set(claims) != {"maximum_logit_deviation_micros", "minimum_next_token_agreement_micros",
                                                   "require_greedy_trajectory_equality"} \
            or type(claims["maximum_logit_deviation_micros"]) is not int or claims["maximum_logit_deviation_micros"] < 0 \
            or type(claims["minimum_next_token_agreement_micros"]) is not int \
            or not 0 <= claims["minimum_next_token_agreement_micros"] <= 1_000_000 \
            or type(claims["require_greedy_trajectory_equality"]) is not bool:
        raise GenerativeReplayError("invalid generative claims")
    trace_keys = {"candidate_artifact_sha256", "candidate_runtime", "contract_sha256", "execution_boundary",
                  "policy_profile", "prompt_suite_sha256", "records", "schema", "source_artifact_sha256",
                  "source_runtime", "tokenizer_sha256"}
    if type(trace) is not dict or set(trace) != trace_keys or trace.get("schema") != TRACE_SCHEMA \
            or trace.get("policy_profile") != PROFILE:
        raise GenerativeReplayError("unsupported generative trace")
    contract_sha = "sha256:" + hashlib.sha256(contract_raw).hexdigest()
    for key in ("candidate_artifact_sha256", "prompt_suite_sha256", "source_artifact_sha256", "tokenizer_sha256"):
        if trace.get(key) != contract[key]: raise GenerativeReplayError(f"trace detached from contract: {key}")
    if trace.get("contract_sha256") != contract_sha: raise GenerativeReplayError("trace detached from contract bytes")
    for label in ("source_runtime", "candidate_runtime", "execution_boundary"):
        if type(trace[label]) is not str or not trace[label].isascii() or not 1 <= len(trace[label]) <= 256:
            raise GenerativeReplayError(f"invalid {label}")
    records = trace["records"]
    if type(records) is not list or not records or len(records) > 100_000:
        raise GenerativeReplayError("invalid generative trace record count")
    total = agreement = maximum = trajectory_mismatches = 0
    prompt_digests = set()
    for record in records:
        if type(record) is not dict or set(record) != {"candidate_tokens", "positions", "prompt_sha256", "source_tokens"} \
                or not _DIGEST.fullmatch(record.get("prompt_sha256", "")) or record["prompt_sha256"] in prompt_digests:
            raise GenerativeReplayError("invalid or duplicate prompt trace")
        prompt_digests.add(record["prompt_sha256"])
        source, candidate, positions = record["source_tokens"], record["candidate_tokens"], record["positions"]
        for sequence in (source, candidate):
            if type(sequence) is not list or len(sequence) > decoding["maximum_generated_tokens"] \
                    or any(type(token) is not int or token < 0 for token in sequence):
                raise GenerativeReplayError("invalid generated token sequence")
        if source != candidate: trajectory_mismatches += 1
        if type(positions) is not list or not positions:
            raise GenerativeReplayError("trace has no compared positions")
        if len(positions) != len(source) or len(positions) != len(candidate):
            raise GenerativeReplayError("token trajectories and position evidence differ in length")
        stop_tokens = set(decoding["stop_token_ids"])
        for sequence in (source, candidate):
            if len(sequence) < decoding["maximum_generated_tokens"] and (
                not sequence or sequence[-1] not in stop_tokens
            ):
                raise GenerativeReplayError("short trajectory does not end in a declared stop token")
        for position in positions:
            if type(position) is not dict or set(position) != {"candidate_top_token", "maximum_abs_logit_deviation_micros",
                                                               "source_top_token"}:
                raise GenerativeReplayError("invalid generative position")
            values = (position["source_top_token"], position["candidate_top_token"],
                      position["maximum_abs_logit_deviation_micros"])
            if any(type(value) is not int or value < 0 for value in values):
                raise GenerativeReplayError("invalid generative position value")
            total += 1; agreement += position["source_top_token"] == position["candidate_top_token"]
            maximum = max(maximum, position["maximum_abs_logit_deviation_micros"])
    agreement_micros = agreement * 1_000_000 // total
    results = {
        "maximum_logit_deviation": maximum <= claims["maximum_logit_deviation_micros"],
        "next_token_agreement": agreement_micros >= claims["minimum_next_token_agreement_micros"],
        "greedy_trajectory_equality": (trajectory_mismatches == 0) if claims["require_greedy_trajectory_equality"] else True,
    }
    report = {
        "schema": "mfenx/ckodmk-generative-adjudication/v1", "policy_profile": PROFILE,
        "decision": "PASS" if all(results.values()) else "BLOCK", "contract_sha256": contract_sha,
        "trace_sha256": "sha256:" + hashlib.sha256(trace_raw).hexdigest(), "records": len(records),
        "compared_positions": total, "next_token_agreement_micros": agreement_micros,
        "maximum_abs_logit_deviation_micros": maximum, "trajectory_mismatches": trajectory_mismatches,
        "claim_results": results,
        "evidence_boundary": {
            "scope": "complete declared finite prompt trace",
            "runtime_observations": "producer-reported and digest-bound; not independently executed by adjudicator",
            "universal_equivalence": "NOT_ESTABLISHED", "capability": "NOT_EVALUATED",
        },
    }
    report["report_digest"] = _digest(report, b"mfenx:ckodmk:generative-adjudication:v1\0")
    return report
